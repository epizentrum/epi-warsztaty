const num1 = Number(prompt('Podaj pierwszą liczbę!'));
const num2 = Number(prompt('Podaj drugą liczbę!'));
if ((num1 === 0) && (num2 === 0)) {
    console.log('0 + 0 = 0')
}
if ((num1 === 0) && (num2 === 1)) {
    console.log('0 + 1 = 1')
}
if ((num1 === 0) && (num2 === 2)) {
    console.log('0 + 2 = 2')
}
if ((num1 === 0) && (num2 === 3)) {
    console.log('0 + 3 = 3')
}
if ((num1 === 0) && (num2 === 4)) {
    console.log('0 + 4 = 4')
}
if ((num1 === 0) && (num2 === 5)) {
    console.log('0 + 5 = 5')
}
if ((num1 === 0) && (num2 === 6)) {
    console.log('0 + 6 = 6')
}
if ((num1 === 0) && (num2 === 7)) {
    console.log('0 + 7 = 7')
}
if ((num1 === 0) && (num2 === 8)) {
    console.log('0 + 8 = 8')
}
if ((num1 === 0) && (num2 === 9)) {
    console.log('0 + 9 = 9')
}
if ((num1 === 0) && (num2 === 10)) {
    console.log('0 + 10 = 10')
}
if ((num1 === 0) && (num2 === 11)) {
    console.log('0 + 11 = 11')
}
if ((num1 === 0) && (num2 === 12)) {
    console.log('0 + 12 = 12')
}
if ((num1 === 0) && (num2 === 13)) {
    console.log('0 + 13 = 13')
}
if ((num1 === 0) && (num2 === 14)) {
    console.log('0 + 14 = 14')
}
if ((num1 === 0) && (num2 === 15)) {
    console.log('0 + 15 = 15')
}
if ((num1 === 0) && (num2 === 16)) {
    console.log('0 + 16 = 16')
}
if ((num1 === 0) && (num2 === 17)) {
    console.log('0 + 17 = 17')
}
if ((num1 === 0) && (num2 === 18)) {
    console.log('0 + 18 = 18')
}
if ((num1 === 0) && (num2 === 19)) {
    console.log('0 + 19 = 19')
}
if ((num1 === 0) && (num2 === 20)) {
    console.log('0 + 20 = 20')
}
if ((num1 === 0) && (num2 === 21)) {
    console.log('0 + 21 = 21')
}
if ((num1 === 0) && (num2 === 22)) {
    console.log('0 + 22 = 22')
}
if ((num1 === 0) && (num2 === 23)) {
    console.log('0 + 23 = 23')
}
if ((num1 === 0) && (num2 === 24)) {
    console.log('0 + 24 = 24')
}
if ((num1 === 0) && (num2 === 25)) {
    console.log('0 + 25 = 25')
}
if ((num1 === 0) && (num2 === 26)) {
    console.log('0 + 26 = 26')
}
if ((num1 === 0) && (num2 === 27)) {
    console.log('0 + 27 = 27')
}
if ((num1 === 0) && (num2 === 28)) {
    console.log('0 + 28 = 28')
}
if ((num1 === 0) && (num2 === 29)) {
    console.log('0 + 29 = 29')
}
if ((num1 === 0) && (num2 === 30)) {
    console.log('0 + 30 = 30')
}
if ((num1 === 0) && (num2 === 31)) {
    console.log('0 + 31 = 31')
}
if ((num1 === 0) && (num2 === 32)) {
    console.log('0 + 32 = 32')
}
if ((num1 === 0) && (num2 === 33)) {
    console.log('0 + 33 = 33')
}
if ((num1 === 0) && (num2 === 34)) {
    console.log('0 + 34 = 34')
}
if ((num1 === 0) && (num2 === 35)) {
    console.log('0 + 35 = 35')
}
if ((num1 === 0) && (num2 === 36)) {
    console.log('0 + 36 = 36')
}
if ((num1 === 0) && (num2 === 37)) {
    console.log('0 + 37 = 37')
}
if ((num1 === 0) && (num2 === 38)) {
    console.log('0 + 38 = 38')
}
if ((num1 === 0) && (num2 === 39)) {
    console.log('0 + 39 = 39')
}
if ((num1 === 0) && (num2 === 40)) {
    console.log('0 + 40 = 40')
}
if ((num1 === 0) && (num2 === 41)) {
    console.log('0 + 41 = 41')
}
if ((num1 === 0) && (num2 === 42)) {
    console.log('0 + 42 = 42')
}
if ((num1 === 0) && (num2 === 43)) {
    console.log('0 + 43 = 43')
}
if ((num1 === 0) && (num2 === 44)) {
    console.log('0 + 44 = 44')
}
if ((num1 === 0) && (num2 === 45)) {
    console.log('0 + 45 = 45')
}
if ((num1 === 0) && (num2 === 46)) {
    console.log('0 + 46 = 46')
}
if ((num1 === 0) && (num2 === 47)) {
    console.log('0 + 47 = 47')
}
if ((num1 === 0) && (num2 === 48)) {
    console.log('0 + 48 = 48')
}
if ((num1 === 0) && (num2 === 49)) {
    console.log('0 + 49 = 49')
}
if ((num1 === 0) && (num2 === 50)) {
    console.log('0 + 50 = 50')
}
if ((num1 === 1) && (num2 === 0)) {
    console.log('1 + 0 = 1')
}
if ((num1 === 1) && (num2 === 1)) {
    console.log('1 + 1 = 2')
}
if ((num1 === 1) && (num2 === 2)) {
    console.log('1 + 2 = 3')
}
if ((num1 === 1) && (num2 === 3)) {
    console.log('1 + 3 = 4')
}
if ((num1 === 1) && (num2 === 4)) {
    console.log('1 + 4 = 5')
}
if ((num1 === 1) && (num2 === 5)) {
    console.log('1 + 5 = 6')
}
if ((num1 === 1) && (num2 === 6)) {
    console.log('1 + 6 = 7')
}
if ((num1 === 1) && (num2 === 7)) {
    console.log('1 + 7 = 8')
}
if ((num1 === 1) && (num2 === 8)) {
    console.log('1 + 8 = 9')
}
if ((num1 === 1) && (num2 === 9)) {
    console.log('1 + 9 = 10')
}
if ((num1 === 1) && (num2 === 10)) {
    console.log('1 + 10 = 11')
}
if ((num1 === 1) && (num2 === 11)) {
    console.log('1 + 11 = 12')
}
if ((num1 === 1) && (num2 === 12)) {
    console.log('1 + 12 = 13')
}
if ((num1 === 1) && (num2 === 13)) {
    console.log('1 + 13 = 14')
}
if ((num1 === 1) && (num2 === 14)) {
    console.log('1 + 14 = 15')
}
if ((num1 === 1) && (num2 === 15)) {
    console.log('1 + 15 = 16')
}
if ((num1 === 1) && (num2 === 16)) {
    console.log('1 + 16 = 17')
}
if ((num1 === 1) && (num2 === 17)) {
    console.log('1 + 17 = 18')
}
if ((num1 === 1) && (num2 === 18)) {
    console.log('1 + 18 = 19')
}
if ((num1 === 1) && (num2 === 19)) {
    console.log('1 + 19 = 20')
}
if ((num1 === 1) && (num2 === 20)) {
    console.log('1 + 20 = 21')
}
if ((num1 === 1) && (num2 === 21)) {
    console.log('1 + 21 = 22')
}
if ((num1 === 1) && (num2 === 22)) {
    console.log('1 + 22 = 23')
}
if ((num1 === 1) && (num2 === 23)) {
    console.log('1 + 23 = 24')
}
if ((num1 === 1) && (num2 === 24)) {
    console.log('1 + 24 = 25')
}
if ((num1 === 1) && (num2 === 25)) {
    console.log('1 + 25 = 26')
}
if ((num1 === 1) && (num2 === 26)) {
    console.log('1 + 26 = 27')
}
if ((num1 === 1) && (num2 === 27)) {
    console.log('1 + 27 = 28')
}
if ((num1 === 1) && (num2 === 28)) {
    console.log('1 + 28 = 29')
}
if ((num1 === 1) && (num2 === 29)) {
    console.log('1 + 29 = 30')
}
if ((num1 === 1) && (num2 === 30)) {
    console.log('1 + 30 = 31')
}
if ((num1 === 1) && (num2 === 31)) {
    console.log('1 + 31 = 32')
}
if ((num1 === 1) && (num2 === 32)) {
    console.log('1 + 32 = 33')
}
if ((num1 === 1) && (num2 === 33)) {
    console.log('1 + 33 = 34')
}
if ((num1 === 1) && (num2 === 34)) {
    console.log('1 + 34 = 35')
}
if ((num1 === 1) && (num2 === 35)) {
    console.log('1 + 35 = 36')
}
if ((num1 === 1) && (num2 === 36)) {
    console.log('1 + 36 = 37')
}
if ((num1 === 1) && (num2 === 37)) {
    console.log('1 + 37 = 38')
}
if ((num1 === 1) && (num2 === 38)) {
    console.log('1 + 38 = 39')
}
if ((num1 === 1) && (num2 === 39)) {
    console.log('1 + 39 = 40')
}
if ((num1 === 1) && (num2 === 40)) {
    console.log('1 + 40 = 41')
}
if ((num1 === 1) && (num2 === 41)) {
    console.log('1 + 41 = 42')
}
if ((num1 === 1) && (num2 === 42)) {
    console.log('1 + 42 = 43')
}
if ((num1 === 1) && (num2 === 43)) {
    console.log('1 + 43 = 44')
}
if ((num1 === 1) && (num2 === 44)) {
    console.log('1 + 44 = 45')
}
if ((num1 === 1) && (num2 === 45)) {
    console.log('1 + 45 = 46')
}
if ((num1 === 1) && (num2 === 46)) {
    console.log('1 + 46 = 47')
}
if ((num1 === 1) && (num2 === 47)) {
    console.log('1 + 47 = 48')
}
if ((num1 === 1) && (num2 === 48)) {
    console.log('1 + 48 = 49')
}
if ((num1 === 1) && (num2 === 49)) {
    console.log('1 + 49 = 50')
}
if ((num1 === 1) && (num2 === 50)) {
    console.log('1 + 50 = 51')
}
if ((num1 === 2) && (num2 === 0)) {
    console.log('2 + 0 = 2')
}
if ((num1 === 2) && (num2 === 1)) {
    console.log('2 + 1 = 3')
}
if ((num1 === 2) && (num2 === 2)) {
    console.log('2 + 2 = 4')
}
if ((num1 === 2) && (num2 === 3)) {
    console.log('2 + 3 = 5')
}
if ((num1 === 2) && (num2 === 4)) {
    console.log('2 + 4 = 6')
}
if ((num1 === 2) && (num2 === 5)) {
    console.log('2 + 5 = 7')
}
if ((num1 === 2) && (num2 === 6)) {
    console.log('2 + 6 = 8')
}
if ((num1 === 2) && (num2 === 7)) {
    console.log('2 + 7 = 9')
}
if ((num1 === 2) && (num2 === 8)) {
    console.log('2 + 8 = 10')
}
if ((num1 === 2) && (num2 === 9)) {
    console.log('2 + 9 = 11')
}
if ((num1 === 2) && (num2 === 10)) {
    console.log('2 + 10 = 12')
}
if ((num1 === 2) && (num2 === 11)) {
    console.log('2 + 11 = 13')
}
if ((num1 === 2) && (num2 === 12)) {
    console.log('2 + 12 = 14')
}
if ((num1 === 2) && (num2 === 13)) {
    console.log('2 + 13 = 15')
}
if ((num1 === 2) && (num2 === 14)) {
    console.log('2 + 14 = 16')
}
if ((num1 === 2) && (num2 === 15)) {
    console.log('2 + 15 = 17')
}
if ((num1 === 2) && (num2 === 16)) {
    console.log('2 + 16 = 18')
}
if ((num1 === 2) && (num2 === 17)) {
    console.log('2 + 17 = 19')
}
if ((num1 === 2) && (num2 === 18)) {
    console.log('2 + 18 = 20')
}
if ((num1 === 2) && (num2 === 19)) {
    console.log('2 + 19 = 21')
}
if ((num1 === 2) && (num2 === 20)) {
    console.log('2 + 20 = 22')
}
if ((num1 === 2) && (num2 === 21)) {
    console.log('2 + 21 = 23')
}
if ((num1 === 2) && (num2 === 22)) {
    console.log('2 + 22 = 24')
}
if ((num1 === 2) && (num2 === 23)) {
    console.log('2 + 23 = 25')
}
if ((num1 === 2) && (num2 === 24)) {
    console.log('2 + 24 = 26')
}
if ((num1 === 2) && (num2 === 25)) {
    console.log('2 + 25 = 27')
}
if ((num1 === 2) && (num2 === 26)) {
    console.log('2 + 26 = 28')
}
if ((num1 === 2) && (num2 === 27)) {
    console.log('2 + 27 = 29')
}
if ((num1 === 2) && (num2 === 28)) {
    console.log('2 + 28 = 30')
}
if ((num1 === 2) && (num2 === 29)) {
    console.log('2 + 29 = 31')
}
if ((num1 === 2) && (num2 === 30)) {
    console.log('2 + 30 = 32')
}
if ((num1 === 2) && (num2 === 31)) {
    console.log('2 + 31 = 33')
}
if ((num1 === 2) && (num2 === 32)) {
    console.log('2 + 32 = 34')
}
if ((num1 === 2) && (num2 === 33)) {
    console.log('2 + 33 = 35')
}
if ((num1 === 2) && (num2 === 34)) {
    console.log('2 + 34 = 36')
}
if ((num1 === 2) && (num2 === 35)) {
    console.log('2 + 35 = 37')
}
if ((num1 === 2) && (num2 === 36)) {
    console.log('2 + 36 = 38')
}
if ((num1 === 2) && (num2 === 37)) {
    console.log('2 + 37 = 39')
}
if ((num1 === 2) && (num2 === 38)) {
    console.log('2 + 38 = 40')
}
if ((num1 === 2) && (num2 === 39)) {
    console.log('2 + 39 = 41')
}
if ((num1 === 2) && (num2 === 40)) {
    console.log('2 + 40 = 42')
}
if ((num1 === 2) && (num2 === 41)) {
    console.log('2 + 41 = 43')
}
if ((num1 === 2) && (num2 === 42)) {
    console.log('2 + 42 = 44')
}
if ((num1 === 2) && (num2 === 43)) {
    console.log('2 + 43 = 45')
}
if ((num1 === 2) && (num2 === 44)) {
    console.log('2 + 44 = 46')
}
if ((num1 === 2) && (num2 === 45)) {
    console.log('2 + 45 = 47')
}
if ((num1 === 2) && (num2 === 46)) {
    console.log('2 + 46 = 48')
}
if ((num1 === 2) && (num2 === 47)) {
    console.log('2 + 47 = 49')
}
if ((num1 === 2) && (num2 === 48)) {
    console.log('2 + 48 = 50')
}
if ((num1 === 2) && (num2 === 49)) {
    console.log('2 + 49 = 51')
}
if ((num1 === 2) && (num2 === 50)) {
    console.log('2 + 50 = 52')
}
if ((num1 === 3) && (num2 === 0)) {
    console.log('3 + 0 = 3')
}
if ((num1 === 3) && (num2 === 1)) {
    console.log('3 + 1 = 4')
}
if ((num1 === 3) && (num2 === 2)) {
    console.log('3 + 2 = 5')
}
if ((num1 === 3) && (num2 === 3)) {
    console.log('3 + 3 = 6')
}
if ((num1 === 3) && (num2 === 4)) {
    console.log('3 + 4 = 7')
}
if ((num1 === 3) && (num2 === 5)) {
    console.log('3 + 5 = 8')
}
if ((num1 === 3) && (num2 === 6)) {
    console.log('3 + 6 = 9')
}
if ((num1 === 3) && (num2 === 7)) {
    console.log('3 + 7 = 10')
}
if ((num1 === 3) && (num2 === 8)) {
    console.log('3 + 8 = 11')
}
if ((num1 === 3) && (num2 === 9)) {
    console.log('3 + 9 = 12')
}
if ((num1 === 3) && (num2 === 10)) {
    console.log('3 + 10 = 13')
}
if ((num1 === 3) && (num2 === 11)) {
    console.log('3 + 11 = 14')
}
if ((num1 === 3) && (num2 === 12)) {
    console.log('3 + 12 = 15')
}
if ((num1 === 3) && (num2 === 13)) {
    console.log('3 + 13 = 16')
}
if ((num1 === 3) && (num2 === 14)) {
    console.log('3 + 14 = 17')
}
if ((num1 === 3) && (num2 === 15)) {
    console.log('3 + 15 = 18')
}
if ((num1 === 3) && (num2 === 16)) {
    console.log('3 + 16 = 19')
}
if ((num1 === 3) && (num2 === 17)) {
    console.log('3 + 17 = 20')
}
if ((num1 === 3) && (num2 === 18)) {
    console.log('3 + 18 = 21')
}
if ((num1 === 3) && (num2 === 19)) {
    console.log('3 + 19 = 22')
}
if ((num1 === 3) && (num2 === 20)) {
    console.log('3 + 20 = 23')
}
if ((num1 === 3) && (num2 === 21)) {
    console.log('3 + 21 = 24')
}
if ((num1 === 3) && (num2 === 22)) {
    console.log('3 + 22 = 25')
}
if ((num1 === 3) && (num2 === 23)) {
    console.log('3 + 23 = 26')
}
if ((num1 === 3) && (num2 === 24)) {
    console.log('3 + 24 = 27')
}
if ((num1 === 3) && (num2 === 25)) {
    console.log('3 + 25 = 28')
}
if ((num1 === 3) && (num2 === 26)) {
    console.log('3 + 26 = 29')
}
if ((num1 === 3) && (num2 === 27)) {
    console.log('3 + 27 = 30')
}
if ((num1 === 3) && (num2 === 28)) {
    console.log('3 + 28 = 31')
}
if ((num1 === 3) && (num2 === 29)) {
    console.log('3 + 29 = 32')
}
if ((num1 === 3) && (num2 === 30)) {
    console.log('3 + 30 = 33')
}
if ((num1 === 3) && (num2 === 31)) {
    console.log('3 + 31 = 34')
}
if ((num1 === 3) && (num2 === 32)) {
    console.log('3 + 32 = 35')
}
if ((num1 === 3) && (num2 === 33)) {
    console.log('3 + 33 = 36')
}
if ((num1 === 3) && (num2 === 34)) {
    console.log('3 + 34 = 37')
}
if ((num1 === 3) && (num2 === 35)) {
    console.log('3 + 35 = 38')
}
if ((num1 === 3) && (num2 === 36)) {
    console.log('3 + 36 = 39')
}
if ((num1 === 3) && (num2 === 37)) {
    console.log('3 + 37 = 40')
}
if ((num1 === 3) && (num2 === 38)) {
    console.log('3 + 38 = 41')
}
if ((num1 === 3) && (num2 === 39)) {
    console.log('3 + 39 = 42')
}
if ((num1 === 3) && (num2 === 40)) {
    console.log('3 + 40 = 43')
}
if ((num1 === 3) && (num2 === 41)) {
    console.log('3 + 41 = 44')
}
if ((num1 === 3) && (num2 === 42)) {
    console.log('3 + 42 = 45')
}
if ((num1 === 3) && (num2 === 43)) {
    console.log('3 + 43 = 46')
}
if ((num1 === 3) && (num2 === 44)) {
    console.log('3 + 44 = 47')
}
if ((num1 === 3) && (num2 === 45)) {
    console.log('3 + 45 = 48')
}
if ((num1 === 3) && (num2 === 46)) {
    console.log('3 + 46 = 49')
}
if ((num1 === 3) && (num2 === 47)) {
    console.log('3 + 47 = 50')
}
if ((num1 === 3) && (num2 === 48)) {
    console.log('3 + 48 = 51')
}
if ((num1 === 3) && (num2 === 49)) {
    console.log('3 + 49 = 52')
}
if ((num1 === 3) && (num2 === 50)) {
    console.log('3 + 50 = 53')
}
if ((num1 === 4) && (num2 === 0)) {
    console.log('4 + 0 = 4')
}
if ((num1 === 4) && (num2 === 1)) {
    console.log('4 + 1 = 5')
}
if ((num1 === 4) && (num2 === 2)) {
    console.log('4 + 2 = 6')
}
if ((num1 === 4) && (num2 === 3)) {
    console.log('4 + 3 = 7')
}
if ((num1 === 4) && (num2 === 4)) {
    console.log('4 + 4 = 8')
}
if ((num1 === 4) && (num2 === 5)) {
    console.log('4 + 5 = 9')
}
if ((num1 === 4) && (num2 === 6)) {
    console.log('4 + 6 = 10')
}
if ((num1 === 4) && (num2 === 7)) {
    console.log('4 + 7 = 11')
}
if ((num1 === 4) && (num2 === 8)) {
    console.log('4 + 8 = 12')
}
if ((num1 === 4) && (num2 === 9)) {
    console.log('4 + 9 = 13')
}
if ((num1 === 4) && (num2 === 10)) {
    console.log('4 + 10 = 14')
}
if ((num1 === 4) && (num2 === 11)) {
    console.log('4 + 11 = 15')
}
if ((num1 === 4) && (num2 === 12)) {
    console.log('4 + 12 = 16')
}
if ((num1 === 4) && (num2 === 13)) {
    console.log('4 + 13 = 17')
}
if ((num1 === 4) && (num2 === 14)) {
    console.log('4 + 14 = 18')
}
if ((num1 === 4) && (num2 === 15)) {
    console.log('4 + 15 = 19')
}
if ((num1 === 4) && (num2 === 16)) {
    console.log('4 + 16 = 20')
}
if ((num1 === 4) && (num2 === 17)) {
    console.log('4 + 17 = 21')
}
if ((num1 === 4) && (num2 === 18)) {
    console.log('4 + 18 = 22')
}
if ((num1 === 4) && (num2 === 19)) {
    console.log('4 + 19 = 23')
}
if ((num1 === 4) && (num2 === 20)) {
    console.log('4 + 20 = 24')
}
if ((num1 === 4) && (num2 === 21)) {
    console.log('4 + 21 = 25')
}
if ((num1 === 4) && (num2 === 22)) {
    console.log('4 + 22 = 26')
}
if ((num1 === 4) && (num2 === 23)) {
    console.log('4 + 23 = 27')
}
if ((num1 === 4) && (num2 === 24)) {
    console.log('4 + 24 = 28')
}
if ((num1 === 4) && (num2 === 25)) {
    console.log('4 + 25 = 29')
}
if ((num1 === 4) && (num2 === 26)) {
    console.log('4 + 26 = 30')
}
if ((num1 === 4) && (num2 === 27)) {
    console.log('4 + 27 = 31')
}
if ((num1 === 4) && (num2 === 28)) {
    console.log('4 + 28 = 32')
}
if ((num1 === 4) && (num2 === 29)) {
    console.log('4 + 29 = 33')
}
if ((num1 === 4) && (num2 === 30)) {
    console.log('4 + 30 = 34')
}
if ((num1 === 4) && (num2 === 31)) {
    console.log('4 + 31 = 35')
}
if ((num1 === 4) && (num2 === 32)) {
    console.log('4 + 32 = 36')
}
if ((num1 === 4) && (num2 === 33)) {
    console.log('4 + 33 = 37')
}
if ((num1 === 4) && (num2 === 34)) {
    console.log('4 + 34 = 38')
}
if ((num1 === 4) && (num2 === 35)) {
    console.log('4 + 35 = 39')
}
if ((num1 === 4) && (num2 === 36)) {
    console.log('4 + 36 = 40')
}
if ((num1 === 4) && (num2 === 37)) {
    console.log('4 + 37 = 41')
}
if ((num1 === 4) && (num2 === 38)) {
    console.log('4 + 38 = 42')
}
if ((num1 === 4) && (num2 === 39)) {
    console.log('4 + 39 = 43')
}
if ((num1 === 4) && (num2 === 40)) {
    console.log('4 + 40 = 44')
}
if ((num1 === 4) && (num2 === 41)) {
    console.log('4 + 41 = 45')
}
if ((num1 === 4) && (num2 === 42)) {
    console.log('4 + 42 = 46')
}
if ((num1 === 4) && (num2 === 43)) {
    console.log('4 + 43 = 47')
}
if ((num1 === 4) && (num2 === 44)) {
    console.log('4 + 44 = 48')
}
if ((num1 === 4) && (num2 === 45)) {
    console.log('4 + 45 = 49')
}
if ((num1 === 4) && (num2 === 46)) {
    console.log('4 + 46 = 50')
}
if ((num1 === 4) && (num2 === 47)) {
    console.log('4 + 47 = 51')
}
if ((num1 === 4) && (num2 === 48)) {
    console.log('4 + 48 = 52')
}
if ((num1 === 4) && (num2 === 49)) {
    console.log('4 + 49 = 53')
}
if ((num1 === 4) && (num2 === 50)) {
    console.log('4 + 50 = 54')
}
if ((num1 === 5) && (num2 === 0)) {
    console.log('5 + 0 = 5')
}
if ((num1 === 5) && (num2 === 1)) {
    console.log('5 + 1 = 6')
}
if ((num1 === 5) && (num2 === 2)) {
    console.log('5 + 2 = 7')
}
if ((num1 === 5) && (num2 === 3)) {
    console.log('5 + 3 = 8')
}
if ((num1 === 5) && (num2 === 4)) {
    console.log('5 + 4 = 9')
}
if ((num1 === 5) && (num2 === 5)) {
    console.log('5 + 5 = 10')
}
if ((num1 === 5) && (num2 === 6)) {
    console.log('5 + 6 = 11')
}
if ((num1 === 5) && (num2 === 7)) {
    console.log('5 + 7 = 12')
}
if ((num1 === 5) && (num2 === 8)) {
    console.log('5 + 8 = 13')
}
if ((num1 === 5) && (num2 === 9)) {
    console.log('5 + 9 = 14')
}
if ((num1 === 5) && (num2 === 10)) {
    console.log('5 + 10 = 15')
}
if ((num1 === 5) && (num2 === 11)) {
    console.log('5 + 11 = 16')
}
if ((num1 === 5) && (num2 === 12)) {
    console.log('5 + 12 = 17')
}
if ((num1 === 5) && (num2 === 13)) {
    console.log('5 + 13 = 18')
}
if ((num1 === 5) && (num2 === 14)) {
    console.log('5 + 14 = 19')
}
if ((num1 === 5) && (num2 === 15)) {
    console.log('5 + 15 = 20')
}
if ((num1 === 5) && (num2 === 16)) {
    console.log('5 + 16 = 21')
}
if ((num1 === 5) && (num2 === 17)) {
    console.log('5 + 17 = 22')
}
if ((num1 === 5) && (num2 === 18)) {
    console.log('5 + 18 = 23')
}
if ((num1 === 5) && (num2 === 19)) {
    console.log('5 + 19 = 24')
}
if ((num1 === 5) && (num2 === 20)) {
    console.log('5 + 20 = 25')
}
if ((num1 === 5) && (num2 === 21)) {
    console.log('5 + 21 = 26')
}
if ((num1 === 5) && (num2 === 22)) {
    console.log('5 + 22 = 27')
}
if ((num1 === 5) && (num2 === 23)) {
    console.log('5 + 23 = 28')
}
if ((num1 === 5) && (num2 === 24)) {
    console.log('5 + 24 = 29')
}
if ((num1 === 5) && (num2 === 25)) {
    console.log('5 + 25 = 30')
}
if ((num1 === 5) && (num2 === 26)) {
    console.log('5 + 26 = 31')
}
if ((num1 === 5) && (num2 === 27)) {
    console.log('5 + 27 = 32')
}
if ((num1 === 5) && (num2 === 28)) {
    console.log('5 + 28 = 33')
}
if ((num1 === 5) && (num2 === 29)) {
    console.log('5 + 29 = 34')
}
if ((num1 === 5) && (num2 === 30)) {
    console.log('5 + 30 = 35')
}
if ((num1 === 5) && (num2 === 31)) {
    console.log('5 + 31 = 36')
}
if ((num1 === 5) && (num2 === 32)) {
    console.log('5 + 32 = 37')
}
if ((num1 === 5) && (num2 === 33)) {
    console.log('5 + 33 = 38')
}
if ((num1 === 5) && (num2 === 34)) {
    console.log('5 + 34 = 39')
}
if ((num1 === 5) && (num2 === 35)) {
    console.log('5 + 35 = 40')
}
if ((num1 === 5) && (num2 === 36)) {
    console.log('5 + 36 = 41')
}
if ((num1 === 5) && (num2 === 37)) {
    console.log('5 + 37 = 42')
}
if ((num1 === 5) && (num2 === 38)) {
    console.log('5 + 38 = 43')
}
if ((num1 === 5) && (num2 === 39)) {
    console.log('5 + 39 = 44')
}
if ((num1 === 5) && (num2 === 40)) {
    console.log('5 + 40 = 45')
}
if ((num1 === 5) && (num2 === 41)) {
    console.log('5 + 41 = 46')
}
if ((num1 === 5) && (num2 === 42)) {
    console.log('5 + 42 = 47')
}
if ((num1 === 5) && (num2 === 43)) {
    console.log('5 + 43 = 48')
}
if ((num1 === 5) && (num2 === 44)) {
    console.log('5 + 44 = 49')
}
if ((num1 === 5) && (num2 === 45)) {
    console.log('5 + 45 = 50')
}
if ((num1 === 5) && (num2 === 46)) {
    console.log('5 + 46 = 51')
}
if ((num1 === 5) && (num2 === 47)) {
    console.log('5 + 47 = 52')
}
if ((num1 === 5) && (num2 === 48)) {
    console.log('5 + 48 = 53')
}
if ((num1 === 5) && (num2 === 49)) {
    console.log('5 + 49 = 54')
}
if ((num1 === 5) && (num2 === 50)) {
    console.log('5 + 50 = 55')
}
if ((num1 === 6) && (num2 === 0)) {
    console.log('6 + 0 = 6')
}
if ((num1 === 6) && (num2 === 1)) {
    console.log('6 + 1 = 7')
}
if ((num1 === 6) && (num2 === 2)) {
    console.log('6 + 2 = 8')
}
if ((num1 === 6) && (num2 === 3)) {
    console.log('6 + 3 = 9')
}
if ((num1 === 6) && (num2 === 4)) {
    console.log('6 + 4 = 10')
}
if ((num1 === 6) && (num2 === 5)) {
    console.log('6 + 5 = 11')
}
if ((num1 === 6) && (num2 === 6)) {
    console.log('6 + 6 = 12')
}
if ((num1 === 6) && (num2 === 7)) {
    console.log('6 + 7 = 13')
}
if ((num1 === 6) && (num2 === 8)) {
    console.log('6 + 8 = 14')
}
if ((num1 === 6) && (num2 === 9)) {
    console.log('6 + 9 = 15')
}
if ((num1 === 6) && (num2 === 10)) {
    console.log('6 + 10 = 16')
}
if ((num1 === 6) && (num2 === 11)) {
    console.log('6 + 11 = 17')
}
if ((num1 === 6) && (num2 === 12)) {
    console.log('6 + 12 = 18')
}
if ((num1 === 6) && (num2 === 13)) {
    console.log('6 + 13 = 19')
}
if ((num1 === 6) && (num2 === 14)) {
    console.log('6 + 14 = 20')
}
if ((num1 === 6) && (num2 === 15)) {
    console.log('6 + 15 = 21')
}
if ((num1 === 6) && (num2 === 16)) {
    console.log('6 + 16 = 22')
}
if ((num1 === 6) && (num2 === 17)) {
    console.log('6 + 17 = 23')
}
if ((num1 === 6) && (num2 === 18)) {
    console.log('6 + 18 = 24')
}
if ((num1 === 6) && (num2 === 19)) {
    console.log('6 + 19 = 25')
}
if ((num1 === 6) && (num2 === 20)) {
    console.log('6 + 20 = 26')
}
if ((num1 === 6) && (num2 === 21)) {
    console.log('6 + 21 = 27')
}
if ((num1 === 6) && (num2 === 22)) {
    console.log('6 + 22 = 28')
}
if ((num1 === 6) && (num2 === 23)) {
    console.log('6 + 23 = 29')
}
if ((num1 === 6) && (num2 === 24)) {
    console.log('6 + 24 = 30')
}
if ((num1 === 6) && (num2 === 25)) {
    console.log('6 + 25 = 31')
}
if ((num1 === 6) && (num2 === 26)) {
    console.log('6 + 26 = 32')
}
if ((num1 === 6) && (num2 === 27)) {
    console.log('6 + 27 = 33')
}
if ((num1 === 6) && (num2 === 28)) {
    console.log('6 + 28 = 34')
}
if ((num1 === 6) && (num2 === 29)) {
    console.log('6 + 29 = 35')
}
if ((num1 === 6) && (num2 === 30)) {
    console.log('6 + 30 = 36')
}
if ((num1 === 6) && (num2 === 31)) {
    console.log('6 + 31 = 37')
}
if ((num1 === 6) && (num2 === 32)) {
    console.log('6 + 32 = 38')
}
if ((num1 === 6) && (num2 === 33)) {
    console.log('6 + 33 = 39')
}
if ((num1 === 6) && (num2 === 34)) {
    console.log('6 + 34 = 40')
}
if ((num1 === 6) && (num2 === 35)) {
    console.log('6 + 35 = 41')
}
if ((num1 === 6) && (num2 === 36)) {
    console.log('6 + 36 = 42')
}
if ((num1 === 6) && (num2 === 37)) {
    console.log('6 + 37 = 43')
}
if ((num1 === 6) && (num2 === 38)) {
    console.log('6 + 38 = 44')
}
if ((num1 === 6) && (num2 === 39)) {
    console.log('6 + 39 = 45')
}
if ((num1 === 6) && (num2 === 40)) {
    console.log('6 + 40 = 46')
}
if ((num1 === 6) && (num2 === 41)) {
    console.log('6 + 41 = 47')
}
if ((num1 === 6) && (num2 === 42)) {
    console.log('6 + 42 = 48')
}
if ((num1 === 6) && (num2 === 43)) {
    console.log('6 + 43 = 49')
}
if ((num1 === 6) && (num2 === 44)) {
    console.log('6 + 44 = 50')
}
if ((num1 === 6) && (num2 === 45)) {
    console.log('6 + 45 = 51')
}
if ((num1 === 6) && (num2 === 46)) {
    console.log('6 + 46 = 52')
}
if ((num1 === 6) && (num2 === 47)) {
    console.log('6 + 47 = 53')
}
if ((num1 === 6) && (num2 === 48)) {
    console.log('6 + 48 = 54')
}
if ((num1 === 6) && (num2 === 49)) {
    console.log('6 + 49 = 55')
}
if ((num1 === 6) && (num2 === 50)) {
    console.log('6 + 50 = 56')
}
if ((num1 === 7) && (num2 === 0)) {
    console.log('7 + 0 = 7')
}
if ((num1 === 7) && (num2 === 1)) {
    console.log('7 + 1 = 8')
}
if ((num1 === 7) && (num2 === 2)) {
    console.log('7 + 2 = 9')
}
if ((num1 === 7) && (num2 === 3)) {
    console.log('7 + 3 = 10')
}
if ((num1 === 7) && (num2 === 4)) {
    console.log('7 + 4 = 11')
}
if ((num1 === 7) && (num2 === 5)) {
    console.log('7 + 5 = 12')
}
if ((num1 === 7) && (num2 === 6)) {
    console.log('7 + 6 = 13')
}
if ((num1 === 7) && (num2 === 7)) {
    console.log('7 + 7 = 14')
}
if ((num1 === 7) && (num2 === 8)) {
    console.log('7 + 8 = 15')
}
if ((num1 === 7) && (num2 === 9)) {
    console.log('7 + 9 = 16')
}
if ((num1 === 7) && (num2 === 10)) {
    console.log('7 + 10 = 17')
}
if ((num1 === 7) && (num2 === 11)) {
    console.log('7 + 11 = 18')
}
if ((num1 === 7) && (num2 === 12)) {
    console.log('7 + 12 = 19')
}
if ((num1 === 7) && (num2 === 13)) {
    console.log('7 + 13 = 20')
}
if ((num1 === 7) && (num2 === 14)) {
    console.log('7 + 14 = 21')
}
if ((num1 === 7) && (num2 === 15)) {
    console.log('7 + 15 = 22')
}
if ((num1 === 7) && (num2 === 16)) {
    console.log('7 + 16 = 23')
}
if ((num1 === 7) && (num2 === 17)) {
    console.log('7 + 17 = 24')
}
if ((num1 === 7) && (num2 === 18)) {
    console.log('7 + 18 = 25')
}
if ((num1 === 7) && (num2 === 19)) {
    console.log('7 + 19 = 26')
}
if ((num1 === 7) && (num2 === 20)) {
    console.log('7 + 20 = 27')
}
if ((num1 === 7) && (num2 === 21)) {
    console.log('7 + 21 = 28')
}
if ((num1 === 7) && (num2 === 22)) {
    console.log('7 + 22 = 29')
}
if ((num1 === 7) && (num2 === 23)) {
    console.log('7 + 23 = 30')
}
if ((num1 === 7) && (num2 === 24)) {
    console.log('7 + 24 = 31')
}
if ((num1 === 7) && (num2 === 25)) {
    console.log('7 + 25 = 32')
}
if ((num1 === 7) && (num2 === 26)) {
    console.log('7 + 26 = 33')
}
if ((num1 === 7) && (num2 === 27)) {
    console.log('7 + 27 = 34')
}
if ((num1 === 7) && (num2 === 28)) {
    console.log('7 + 28 = 35')
}
if ((num1 === 7) && (num2 === 29)) {
    console.log('7 + 29 = 36')
}
if ((num1 === 7) && (num2 === 30)) {
    console.log('7 + 30 = 37')
}
if ((num1 === 7) && (num2 === 31)) {
    console.log('7 + 31 = 38')
}
if ((num1 === 7) && (num2 === 32)) {
    console.log('7 + 32 = 39')
}
if ((num1 === 7) && (num2 === 33)) {
    console.log('7 + 33 = 40')
}
if ((num1 === 7) && (num2 === 34)) {
    console.log('7 + 34 = 41')
}
if ((num1 === 7) && (num2 === 35)) {
    console.log('7 + 35 = 42')
}
if ((num1 === 7) && (num2 === 36)) {
    console.log('7 + 36 = 43')
}
if ((num1 === 7) && (num2 === 37)) {
    console.log('7 + 37 = 44')
}
if ((num1 === 7) && (num2 === 38)) {
    console.log('7 + 38 = 45')
}
if ((num1 === 7) && (num2 === 39)) {
    console.log('7 + 39 = 46')
}
if ((num1 === 7) && (num2 === 40)) {
    console.log('7 + 40 = 47')
}
if ((num1 === 7) && (num2 === 41)) {
    console.log('7 + 41 = 48')
}
if ((num1 === 7) && (num2 === 42)) {
    console.log('7 + 42 = 49')
}
if ((num1 === 7) && (num2 === 43)) {
    console.log('7 + 43 = 50')
}
if ((num1 === 7) && (num2 === 44)) {
    console.log('7 + 44 = 51')
}
if ((num1 === 7) && (num2 === 45)) {
    console.log('7 + 45 = 52')
}
if ((num1 === 7) && (num2 === 46)) {
    console.log('7 + 46 = 53')
}
if ((num1 === 7) && (num2 === 47)) {
    console.log('7 + 47 = 54')
}
if ((num1 === 7) && (num2 === 48)) {
    console.log('7 + 48 = 55')
}
if ((num1 === 7) && (num2 === 49)) {
    console.log('7 + 49 = 56')
}
if ((num1 === 7) && (num2 === 50)) {
    console.log('7 + 50 = 57')
}
if ((num1 === 8) && (num2 === 0)) {
    console.log('8 + 0 = 8')
}
if ((num1 === 8) && (num2 === 1)) {
    console.log('8 + 1 = 9')
}
if ((num1 === 8) && (num2 === 2)) {
    console.log('8 + 2 = 10')
}
if ((num1 === 8) && (num2 === 3)) {
    console.log('8 + 3 = 11')
}
if ((num1 === 8) && (num2 === 4)) {
    console.log('8 + 4 = 12')
}
if ((num1 === 8) && (num2 === 5)) {
    console.log('8 + 5 = 13')
}
if ((num1 === 8) && (num2 === 6)) {
    console.log('8 + 6 = 14')
}
if ((num1 === 8) && (num2 === 7)) {
    console.log('8 + 7 = 15')
}
if ((num1 === 8) && (num2 === 8)) {
    console.log('8 + 8 = 16')
}
if ((num1 === 8) && (num2 === 9)) {
    console.log('8 + 9 = 17')
}
if ((num1 === 8) && (num2 === 10)) {
    console.log('8 + 10 = 18')
}
if ((num1 === 8) && (num2 === 11)) {
    console.log('8 + 11 = 19')
}
if ((num1 === 8) && (num2 === 12)) {
    console.log('8 + 12 = 20')
}
if ((num1 === 8) && (num2 === 13)) {
    console.log('8 + 13 = 21')
}
if ((num1 === 8) && (num2 === 14)) {
    console.log('8 + 14 = 22')
}
if ((num1 === 8) && (num2 === 15)) {
    console.log('8 + 15 = 23')
}
if ((num1 === 8) && (num2 === 16)) {
    console.log('8 + 16 = 24')
}
if ((num1 === 8) && (num2 === 17)) {
    console.log('8 + 17 = 25')
}
if ((num1 === 8) && (num2 === 18)) {
    console.log('8 + 18 = 26')
}
if ((num1 === 8) && (num2 === 19)) {
    console.log('8 + 19 = 27')
}
if ((num1 === 8) && (num2 === 20)) {
    console.log('8 + 20 = 28')
}
if ((num1 === 8) && (num2 === 21)) {
    console.log('8 + 21 = 29')
}
if ((num1 === 8) && (num2 === 22)) {
    console.log('8 + 22 = 30')
}
if ((num1 === 8) && (num2 === 23)) {
    console.log('8 + 23 = 31')
}
if ((num1 === 8) && (num2 === 24)) {
    console.log('8 + 24 = 32')
}
if ((num1 === 8) && (num2 === 25)) {
    console.log('8 + 25 = 33')
}
if ((num1 === 8) && (num2 === 26)) {
    console.log('8 + 26 = 34')
}
if ((num1 === 8) && (num2 === 27)) {
    console.log('8 + 27 = 35')
}
if ((num1 === 8) && (num2 === 28)) {
    console.log('8 + 28 = 36')
}
if ((num1 === 8) && (num2 === 29)) {
    console.log('8 + 29 = 37')
}
if ((num1 === 8) && (num2 === 30)) {
    console.log('8 + 30 = 38')
}
if ((num1 === 8) && (num2 === 31)) {
    console.log('8 + 31 = 39')
}
if ((num1 === 8) && (num2 === 32)) {
    console.log('8 + 32 = 40')
}
if ((num1 === 8) && (num2 === 33)) {
    console.log('8 + 33 = 41')
}
if ((num1 === 8) && (num2 === 34)) {
    console.log('8 + 34 = 42')
}
if ((num1 === 8) && (num2 === 35)) {
    console.log('8 + 35 = 43')
}
if ((num1 === 8) && (num2 === 36)) {
    console.log('8 + 36 = 44')
}
if ((num1 === 8) && (num2 === 37)) {
    console.log('8 + 37 = 45')
}
if ((num1 === 8) && (num2 === 38)) {
    console.log('8 + 38 = 46')
}
if ((num1 === 8) && (num2 === 39)) {
    console.log('8 + 39 = 47')
}
if ((num1 === 8) && (num2 === 40)) {
    console.log('8 + 40 = 48')
}
if ((num1 === 8) && (num2 === 41)) {
    console.log('8 + 41 = 49')
}
if ((num1 === 8) && (num2 === 42)) {
    console.log('8 + 42 = 50')
}
if ((num1 === 8) && (num2 === 43)) {
    console.log('8 + 43 = 51')
}
if ((num1 === 8) && (num2 === 44)) {
    console.log('8 + 44 = 52')
}
if ((num1 === 8) && (num2 === 45)) {
    console.log('8 + 45 = 53')
}
if ((num1 === 8) && (num2 === 46)) {
    console.log('8 + 46 = 54')
}
if ((num1 === 8) && (num2 === 47)) {
    console.log('8 + 47 = 55')
}
if ((num1 === 8) && (num2 === 48)) {
    console.log('8 + 48 = 56')
}
if ((num1 === 8) && (num2 === 49)) {
    console.log('8 + 49 = 57')
}
if ((num1 === 8) && (num2 === 50)) {
    console.log('8 + 50 = 58')
}
if ((num1 === 9) && (num2 === 0)) {
    console.log('9 + 0 = 9')
}
if ((num1 === 9) && (num2 === 1)) {
    console.log('9 + 1 = 10')
}
if ((num1 === 9) && (num2 === 2)) {
    console.log('9 + 2 = 11')
}
if ((num1 === 9) && (num2 === 3)) {
    console.log('9 + 3 = 12')
}
if ((num1 === 9) && (num2 === 4)) {
    console.log('9 + 4 = 13')
}
if ((num1 === 9) && (num2 === 5)) {
    console.log('9 + 5 = 14')
}
if ((num1 === 9) && (num2 === 6)) {
    console.log('9 + 6 = 15')
}
if ((num1 === 9) && (num2 === 7)) {
    console.log('9 + 7 = 16')
}
if ((num1 === 9) && (num2 === 8)) {
    console.log('9 + 8 = 17')
}
if ((num1 === 9) && (num2 === 9)) {
    console.log('9 + 9 = 18')
}
if ((num1 === 9) && (num2 === 10)) {
    console.log('9 + 10 = 19')
}
if ((num1 === 9) && (num2 === 11)) {
    console.log('9 + 11 = 20')
}
if ((num1 === 9) && (num2 === 12)) {
    console.log('9 + 12 = 21')
}
if ((num1 === 9) && (num2 === 13)) {
    console.log('9 + 13 = 22')
}
if ((num1 === 9) && (num2 === 14)) {
    console.log('9 + 14 = 23')
}
if ((num1 === 9) && (num2 === 15)) {
    console.log('9 + 15 = 24')
}
if ((num1 === 9) && (num2 === 16)) {
    console.log('9 + 16 = 25')
}
if ((num1 === 9) && (num2 === 17)) {
    console.log('9 + 17 = 26')
}
if ((num1 === 9) && (num2 === 18)) {
    console.log('9 + 18 = 27')
}
if ((num1 === 9) && (num2 === 19)) {
    console.log('9 + 19 = 28')
}
if ((num1 === 9) && (num2 === 20)) {
    console.log('9 + 20 = 29')
}
if ((num1 === 9) && (num2 === 21)) {
    console.log('9 + 21 = 30')
}
if ((num1 === 9) && (num2 === 22)) {
    console.log('9 + 22 = 31')
}
if ((num1 === 9) && (num2 === 23)) {
    console.log('9 + 23 = 32')
}
if ((num1 === 9) && (num2 === 24)) {
    console.log('9 + 24 = 33')
}
if ((num1 === 9) && (num2 === 25)) {
    console.log('9 + 25 = 34')
}
if ((num1 === 9) && (num2 === 26)) {
    console.log('9 + 26 = 35')
}
if ((num1 === 9) && (num2 === 27)) {
    console.log('9 + 27 = 36')
}
if ((num1 === 9) && (num2 === 28)) {
    console.log('9 + 28 = 37')
}
if ((num1 === 9) && (num2 === 29)) {
    console.log('9 + 29 = 38')
}
if ((num1 === 9) && (num2 === 30)) {
    console.log('9 + 30 = 39')
}
if ((num1 === 9) && (num2 === 31)) {
    console.log('9 + 31 = 40')
}
if ((num1 === 9) && (num2 === 32)) {
    console.log('9 + 32 = 41')
}
if ((num1 === 9) && (num2 === 33)) {
    console.log('9 + 33 = 42')
}
if ((num1 === 9) && (num2 === 34)) {
    console.log('9 + 34 = 43')
}
if ((num1 === 9) && (num2 === 35)) {
    console.log('9 + 35 = 44')
}
if ((num1 === 9) && (num2 === 36)) {
    console.log('9 + 36 = 45')
}
if ((num1 === 9) && (num2 === 37)) {
    console.log('9 + 37 = 46')
}
if ((num1 === 9) && (num2 === 38)) {
    console.log('9 + 38 = 47')
}
if ((num1 === 9) && (num2 === 39)) {
    console.log('9 + 39 = 48')
}
if ((num1 === 9) && (num2 === 40)) {
    console.log('9 + 40 = 49')
}
if ((num1 === 9) && (num2 === 41)) {
    console.log('9 + 41 = 50')
}
if ((num1 === 9) && (num2 === 42)) {
    console.log('9 + 42 = 51')
}
if ((num1 === 9) && (num2 === 43)) {
    console.log('9 + 43 = 52')
}
if ((num1 === 9) && (num2 === 44)) {
    console.log('9 + 44 = 53')
}
if ((num1 === 9) && (num2 === 45)) {
    console.log('9 + 45 = 54')
}
if ((num1 === 9) && (num2 === 46)) {
    console.log('9 + 46 = 55')
}
if ((num1 === 9) && (num2 === 47)) {
    console.log('9 + 47 = 56')
}
if ((num1 === 9) && (num2 === 48)) {
    console.log('9 + 48 = 57')
}
if ((num1 === 9) && (num2 === 49)) {
    console.log('9 + 49 = 58')
}
if ((num1 === 9) && (num2 === 50)) {
    console.log('9 + 50 = 59')
}
if ((num1 === 10) && (num2 === 0)) {
    console.log('10 + 0 = 10')
}
if ((num1 === 10) && (num2 === 1)) {
    console.log('10 + 1 = 11')
}
if ((num1 === 10) && (num2 === 2)) {
    console.log('10 + 2 = 12')
}
if ((num1 === 10) && (num2 === 3)) {
    console.log('10 + 3 = 13')
}
if ((num1 === 10) && (num2 === 4)) {
    console.log('10 + 4 = 14')
}
if ((num1 === 10) && (num2 === 5)) {
    console.log('10 + 5 = 15')
}
if ((num1 === 10) && (num2 === 6)) {
    console.log('10 + 6 = 16')
}
if ((num1 === 10) && (num2 === 7)) {
    console.log('10 + 7 = 17')
}
if ((num1 === 10) && (num2 === 8)) {
    console.log('10 + 8 = 18')
}
if ((num1 === 10) && (num2 === 9)) {
    console.log('10 + 9 = 19')
}
if ((num1 === 10) && (num2 === 10)) {
    console.log('10 + 10 = 20')
}
if ((num1 === 10) && (num2 === 11)) {
    console.log('10 + 11 = 21')
}
if ((num1 === 10) && (num2 === 12)) {
    console.log('10 + 12 = 22')
}
if ((num1 === 10) && (num2 === 13)) {
    console.log('10 + 13 = 23')
}
if ((num1 === 10) && (num2 === 14)) {
    console.log('10 + 14 = 24')
}
if ((num1 === 10) && (num2 === 15)) {
    console.log('10 + 15 = 25')
}
if ((num1 === 10) && (num2 === 16)) {
    console.log('10 + 16 = 26')
}
if ((num1 === 10) && (num2 === 17)) {
    console.log('10 + 17 = 27')
}
if ((num1 === 10) && (num2 === 18)) {
    console.log('10 + 18 = 28')
}
if ((num1 === 10) && (num2 === 19)) {
    console.log('10 + 19 = 29')
}
if ((num1 === 10) && (num2 === 20)) {
    console.log('10 + 20 = 30')
}
if ((num1 === 10) && (num2 === 21)) {
    console.log('10 + 21 = 31')
}
if ((num1 === 10) && (num2 === 22)) {
    console.log('10 + 22 = 32')
}
if ((num1 === 10) && (num2 === 23)) {
    console.log('10 + 23 = 33')
}
if ((num1 === 10) && (num2 === 24)) {
    console.log('10 + 24 = 34')
}
if ((num1 === 10) && (num2 === 25)) {
    console.log('10 + 25 = 35')
}
if ((num1 === 10) && (num2 === 26)) {
    console.log('10 + 26 = 36')
}
if ((num1 === 10) && (num2 === 27)) {
    console.log('10 + 27 = 37')
}
if ((num1 === 10) && (num2 === 28)) {
    console.log('10 + 28 = 38')
}
if ((num1 === 10) && (num2 === 29)) {
    console.log('10 + 29 = 39')
}
if ((num1 === 10) && (num2 === 30)) {
    console.log('10 + 30 = 40')
}
if ((num1 === 10) && (num2 === 31)) {
    console.log('10 + 31 = 41')
}
if ((num1 === 10) && (num2 === 32)) {
    console.log('10 + 32 = 42')
}
if ((num1 === 10) && (num2 === 33)) {
    console.log('10 + 33 = 43')
}
if ((num1 === 10) && (num2 === 34)) {
    console.log('10 + 34 = 44')
}
if ((num1 === 10) && (num2 === 35)) {
    console.log('10 + 35 = 45')
}
if ((num1 === 10) && (num2 === 36)) {
    console.log('10 + 36 = 46')
}
if ((num1 === 10) && (num2 === 37)) {
    console.log('10 + 37 = 47')
}
if ((num1 === 10) && (num2 === 38)) {
    console.log('10 + 38 = 48')
}
if ((num1 === 10) && (num2 === 39)) {
    console.log('10 + 39 = 49')
}
if ((num1 === 10) && (num2 === 40)) {
    console.log('10 + 40 = 50')
}
if ((num1 === 10) && (num2 === 41)) {
    console.log('10 + 41 = 51')
}
if ((num1 === 10) && (num2 === 42)) {
    console.log('10 + 42 = 52')
}
if ((num1 === 10) && (num2 === 43)) {
    console.log('10 + 43 = 53')
}
if ((num1 === 10) && (num2 === 44)) {
    console.log('10 + 44 = 54')
}
if ((num1 === 10) && (num2 === 45)) {
    console.log('10 + 45 = 55')
}
if ((num1 === 10) && (num2 === 46)) {
    console.log('10 + 46 = 56')
}
if ((num1 === 10) && (num2 === 47)) {
    console.log('10 + 47 = 57')
}
if ((num1 === 10) && (num2 === 48)) {
    console.log('10 + 48 = 58')
}
if ((num1 === 10) && (num2 === 49)) {
    console.log('10 + 49 = 59')
}
if ((num1 === 10) && (num2 === 50)) {
    console.log('10 + 50 = 60')
}
if ((num1 === 11) && (num2 === 0)) {
    console.log('11 + 0 = 11')
}
if ((num1 === 11) && (num2 === 1)) {
    console.log('11 + 1 = 12')
}
if ((num1 === 11) && (num2 === 2)) {
    console.log('11 + 2 = 13')
}
if ((num1 === 11) && (num2 === 3)) {
    console.log('11 + 3 = 14')
}
if ((num1 === 11) && (num2 === 4)) {
    console.log('11 + 4 = 15')
}
if ((num1 === 11) && (num2 === 5)) {
    console.log('11 + 5 = 16')
}
if ((num1 === 11) && (num2 === 6)) {
    console.log('11 + 6 = 17')
}
if ((num1 === 11) && (num2 === 7)) {
    console.log('11 + 7 = 18')
}
if ((num1 === 11) && (num2 === 8)) {
    console.log('11 + 8 = 19')
}
if ((num1 === 11) && (num2 === 9)) {
    console.log('11 + 9 = 20')
}
if ((num1 === 11) && (num2 === 10)) {
    console.log('11 + 10 = 21')
}
if ((num1 === 11) && (num2 === 11)) {
    console.log('11 + 11 = 22')
}
if ((num1 === 11) && (num2 === 12)) {
    console.log('11 + 12 = 23')
}
if ((num1 === 11) && (num2 === 13)) {
    console.log('11 + 13 = 24')
}
if ((num1 === 11) && (num2 === 14)) {
    console.log('11 + 14 = 25')
}
if ((num1 === 11) && (num2 === 15)) {
    console.log('11 + 15 = 26')
}
if ((num1 === 11) && (num2 === 16)) {
    console.log('11 + 16 = 27')
}
if ((num1 === 11) && (num2 === 17)) {
    console.log('11 + 17 = 28')
}
if ((num1 === 11) && (num2 === 18)) {
    console.log('11 + 18 = 29')
}
if ((num1 === 11) && (num2 === 19)) {
    console.log('11 + 19 = 30')
}
if ((num1 === 11) && (num2 === 20)) {
    console.log('11 + 20 = 31')
}
if ((num1 === 11) && (num2 === 21)) {
    console.log('11 + 21 = 32')
}
if ((num1 === 11) && (num2 === 22)) {
    console.log('11 + 22 = 33')
}
if ((num1 === 11) && (num2 === 23)) {
    console.log('11 + 23 = 34')
}
if ((num1 === 11) && (num2 === 24)) {
    console.log('11 + 24 = 35')
}
if ((num1 === 11) && (num2 === 25)) {
    console.log('11 + 25 = 36')
}
if ((num1 === 11) && (num2 === 26)) {
    console.log('11 + 26 = 37')
}
if ((num1 === 11) && (num2 === 27)) {
    console.log('11 + 27 = 38')
}
if ((num1 === 11) && (num2 === 28)) {
    console.log('11 + 28 = 39')
}
if ((num1 === 11) && (num2 === 29)) {
    console.log('11 + 29 = 40')
}
if ((num1 === 11) && (num2 === 30)) {
    console.log('11 + 30 = 41')
}
if ((num1 === 11) && (num2 === 31)) {
    console.log('11 + 31 = 42')
}
if ((num1 === 11) && (num2 === 32)) {
    console.log('11 + 32 = 43')
}
if ((num1 === 11) && (num2 === 33)) {
    console.log('11 + 33 = 44')
}
if ((num1 === 11) && (num2 === 34)) {
    console.log('11 + 34 = 45')
}
if ((num1 === 11) && (num2 === 35)) {
    console.log('11 + 35 = 46')
}
if ((num1 === 11) && (num2 === 36)) {
    console.log('11 + 36 = 47')
}
if ((num1 === 11) && (num2 === 37)) {
    console.log('11 + 37 = 48')
}
if ((num1 === 11) && (num2 === 38)) {
    console.log('11 + 38 = 49')
}
if ((num1 === 11) && (num2 === 39)) {
    console.log('11 + 39 = 50')
}
if ((num1 === 11) && (num2 === 40)) {
    console.log('11 + 40 = 51')
}
if ((num1 === 11) && (num2 === 41)) {
    console.log('11 + 41 = 52')
}
if ((num1 === 11) && (num2 === 42)) {
    console.log('11 + 42 = 53')
}
if ((num1 === 11) && (num2 === 43)) {
    console.log('11 + 43 = 54')
}
if ((num1 === 11) && (num2 === 44)) {
    console.log('11 + 44 = 55')
}
if ((num1 === 11) && (num2 === 45)) {
    console.log('11 + 45 = 56')
}
if ((num1 === 11) && (num2 === 46)) {
    console.log('11 + 46 = 57')
}
if ((num1 === 11) && (num2 === 47)) {
    console.log('11 + 47 = 58')
}
if ((num1 === 11) && (num2 === 48)) {
    console.log('11 + 48 = 59')
}
if ((num1 === 11) && (num2 === 49)) {
    console.log('11 + 49 = 60')
}
if ((num1 === 11) && (num2 === 50)) {
    console.log('11 + 50 = 61')
}
if ((num1 === 12) && (num2 === 0)) {
    console.log('12 + 0 = 12')
}
if ((num1 === 12) && (num2 === 1)) {
    console.log('12 + 1 = 13')
}
if ((num1 === 12) && (num2 === 2)) {
    console.log('12 + 2 = 14')
}
if ((num1 === 12) && (num2 === 3)) {
    console.log('12 + 3 = 15')
}
if ((num1 === 12) && (num2 === 4)) {
    console.log('12 + 4 = 16')
}
if ((num1 === 12) && (num2 === 5)) {
    console.log('12 + 5 = 17')
}
if ((num1 === 12) && (num2 === 6)) {
    console.log('12 + 6 = 18')
}
if ((num1 === 12) && (num2 === 7)) {
    console.log('12 + 7 = 19')
}
if ((num1 === 12) && (num2 === 8)) {
    console.log('12 + 8 = 20')
}
if ((num1 === 12) && (num2 === 9)) {
    console.log('12 + 9 = 21')
}
if ((num1 === 12) && (num2 === 10)) {
    console.log('12 + 10 = 22')
}
if ((num1 === 12) && (num2 === 11)) {
    console.log('12 + 11 = 23')
}
if ((num1 === 12) && (num2 === 12)) {
    console.log('12 + 12 = 24')
}
if ((num1 === 12) && (num2 === 13)) {
    console.log('12 + 13 = 25')
}
if ((num1 === 12) && (num2 === 14)) {
    console.log('12 + 14 = 26')
}
if ((num1 === 12) && (num2 === 15)) {
    console.log('12 + 15 = 27')
}
if ((num1 === 12) && (num2 === 16)) {
    console.log('12 + 16 = 28')
}
if ((num1 === 12) && (num2 === 17)) {
    console.log('12 + 17 = 29')
}
if ((num1 === 12) && (num2 === 18)) {
    console.log('12 + 18 = 30')
}
if ((num1 === 12) && (num2 === 19)) {
    console.log('12 + 19 = 31')
}
if ((num1 === 12) && (num2 === 20)) {
    console.log('12 + 20 = 32')
}
if ((num1 === 12) && (num2 === 21)) {
    console.log('12 + 21 = 33')
}
if ((num1 === 12) && (num2 === 22)) {
    console.log('12 + 22 = 34')
}
if ((num1 === 12) && (num2 === 23)) {
    console.log('12 + 23 = 35')
}
if ((num1 === 12) && (num2 === 24)) {
    console.log('12 + 24 = 36')
}
if ((num1 === 12) && (num2 === 25)) {
    console.log('12 + 25 = 37')
}
if ((num1 === 12) && (num2 === 26)) {
    console.log('12 + 26 = 38')
}
if ((num1 === 12) && (num2 === 27)) {
    console.log('12 + 27 = 39')
}
if ((num1 === 12) && (num2 === 28)) {
    console.log('12 + 28 = 40')
}
if ((num1 === 12) && (num2 === 29)) {
    console.log('12 + 29 = 41')
}
if ((num1 === 12) && (num2 === 30)) {
    console.log('12 + 30 = 42')
}
if ((num1 === 12) && (num2 === 31)) {
    console.log('12 + 31 = 43')
}
if ((num1 === 12) && (num2 === 32)) {
    console.log('12 + 32 = 44')
}
if ((num1 === 12) && (num2 === 33)) {
    console.log('12 + 33 = 45')
}
if ((num1 === 12) && (num2 === 34)) {
    console.log('12 + 34 = 46')
}
if ((num1 === 12) && (num2 === 35)) {
    console.log('12 + 35 = 47')
}
if ((num1 === 12) && (num2 === 36)) {
    console.log('12 + 36 = 48')
}
if ((num1 === 12) && (num2 === 37)) {
    console.log('12 + 37 = 49')
}
if ((num1 === 12) && (num2 === 38)) {
    console.log('12 + 38 = 50')
}
if ((num1 === 12) && (num2 === 39)) {
    console.log('12 + 39 = 51')
}
if ((num1 === 12) && (num2 === 40)) {
    console.log('12 + 40 = 52')
}
if ((num1 === 12) && (num2 === 41)) {
    console.log('12 + 41 = 53')
}
if ((num1 === 12) && (num2 === 42)) {
    console.log('12 + 42 = 54')
}
if ((num1 === 12) && (num2 === 43)) {
    console.log('12 + 43 = 55')
}
if ((num1 === 12) && (num2 === 44)) {
    console.log('12 + 44 = 56')
}
if ((num1 === 12) && (num2 === 45)) {
    console.log('12 + 45 = 57')
}
if ((num1 === 12) && (num2 === 46)) {
    console.log('12 + 46 = 58')
}
if ((num1 === 12) && (num2 === 47)) {
    console.log('12 + 47 = 59')
}
if ((num1 === 12) && (num2 === 48)) {
    console.log('12 + 48 = 60')
}
if ((num1 === 12) && (num2 === 49)) {
    console.log('12 + 49 = 61')
}
if ((num1 === 12) && (num2 === 50)) {
    console.log('12 + 50 = 62')
}
if ((num1 === 13) && (num2 === 0)) {
    console.log('13 + 0 = 13')
}
if ((num1 === 13) && (num2 === 1)) {
    console.log('13 + 1 = 14')
}
if ((num1 === 13) && (num2 === 2)) {
    console.log('13 + 2 = 15')
}
if ((num1 === 13) && (num2 === 3)) {
    console.log('13 + 3 = 16')
}
if ((num1 === 13) && (num2 === 4)) {
    console.log('13 + 4 = 17')
}
if ((num1 === 13) && (num2 === 5)) {
    console.log('13 + 5 = 18')
}
if ((num1 === 13) && (num2 === 6)) {
    console.log('13 + 6 = 19')
}
if ((num1 === 13) && (num2 === 7)) {
    console.log('13 + 7 = 20')
}
if ((num1 === 13) && (num2 === 8)) {
    console.log('13 + 8 = 21')
}
if ((num1 === 13) && (num2 === 9)) {
    console.log('13 + 9 = 22')
}
if ((num1 === 13) && (num2 === 10)) {
    console.log('13 + 10 = 23')
}
if ((num1 === 13) && (num2 === 11)) {
    console.log('13 + 11 = 24')
}
if ((num1 === 13) && (num2 === 12)) {
    console.log('13 + 12 = 25')
}
if ((num1 === 13) && (num2 === 13)) {
    console.log('13 + 13 = 26')
}
if ((num1 === 13) && (num2 === 14)) {
    console.log('13 + 14 = 27')
}
if ((num1 === 13) && (num2 === 15)) {
    console.log('13 + 15 = 28')
}
if ((num1 === 13) && (num2 === 16)) {
    console.log('13 + 16 = 29')
}
if ((num1 === 13) && (num2 === 17)) {
    console.log('13 + 17 = 30')
}
if ((num1 === 13) && (num2 === 18)) {
    console.log('13 + 18 = 31')
}
if ((num1 === 13) && (num2 === 19)) {
    console.log('13 + 19 = 32')
}
if ((num1 === 13) && (num2 === 20)) {
    console.log('13 + 20 = 33')
}
if ((num1 === 13) && (num2 === 21)) {
    console.log('13 + 21 = 34')
}
if ((num1 === 13) && (num2 === 22)) {
    console.log('13 + 22 = 35')
}
if ((num1 === 13) && (num2 === 23)) {
    console.log('13 + 23 = 36')
}
if ((num1 === 13) && (num2 === 24)) {
    console.log('13 + 24 = 37')
}
if ((num1 === 13) && (num2 === 25)) {
    console.log('13 + 25 = 38')
}
if ((num1 === 13) && (num2 === 26)) {
    console.log('13 + 26 = 39')
}
if ((num1 === 13) && (num2 === 27)) {
    console.log('13 + 27 = 40')
}
if ((num1 === 13) && (num2 === 28)) {
    console.log('13 + 28 = 41')
}
if ((num1 === 13) && (num2 === 29)) {
    console.log('13 + 29 = 42')
}
if ((num1 === 13) && (num2 === 30)) {
    console.log('13 + 30 = 43')
}
if ((num1 === 13) && (num2 === 31)) {
    console.log('13 + 31 = 44')
}
if ((num1 === 13) && (num2 === 32)) {
    console.log('13 + 32 = 45')
}
if ((num1 === 13) && (num2 === 33)) {
    console.log('13 + 33 = 46')
}
if ((num1 === 13) && (num2 === 34)) {
    console.log('13 + 34 = 47')
}
if ((num1 === 13) && (num2 === 35)) {
    console.log('13 + 35 = 48')
}
if ((num1 === 13) && (num2 === 36)) {
    console.log('13 + 36 = 49')
}
if ((num1 === 13) && (num2 === 37)) {
    console.log('13 + 37 = 50')
}
if ((num1 === 13) && (num2 === 38)) {
    console.log('13 + 38 = 51')
}
if ((num1 === 13) && (num2 === 39)) {
    console.log('13 + 39 = 52')
}
if ((num1 === 13) && (num2 === 40)) {
    console.log('13 + 40 = 53')
}
if ((num1 === 13) && (num2 === 41)) {
    console.log('13 + 41 = 54')
}
if ((num1 === 13) && (num2 === 42)) {
    console.log('13 + 42 = 55')
}
if ((num1 === 13) && (num2 === 43)) {
    console.log('13 + 43 = 56')
}
if ((num1 === 13) && (num2 === 44)) {
    console.log('13 + 44 = 57')
}
if ((num1 === 13) && (num2 === 45)) {
    console.log('13 + 45 = 58')
}
if ((num1 === 13) && (num2 === 46)) {
    console.log('13 + 46 = 59')
}
if ((num1 === 13) && (num2 === 47)) {
    console.log('13 + 47 = 60')
}
if ((num1 === 13) && (num2 === 48)) {
    console.log('13 + 48 = 61')
}
if ((num1 === 13) && (num2 === 49)) {
    console.log('13 + 49 = 62')
}
if ((num1 === 13) && (num2 === 50)) {
    console.log('13 + 50 = 63')
}
if ((num1 === 14) && (num2 === 0)) {
    console.log('14 + 0 = 14')
}
if ((num1 === 14) && (num2 === 1)) {
    console.log('14 + 1 = 15')
}
if ((num1 === 14) && (num2 === 2)) {
    console.log('14 + 2 = 16')
}
if ((num1 === 14) && (num2 === 3)) {
    console.log('14 + 3 = 17')
}
if ((num1 === 14) && (num2 === 4)) {
    console.log('14 + 4 = 18')
}
if ((num1 === 14) && (num2 === 5)) {
    console.log('14 + 5 = 19')
}
if ((num1 === 14) && (num2 === 6)) {
    console.log('14 + 6 = 20')
}
if ((num1 === 14) && (num2 === 7)) {
    console.log('14 + 7 = 21')
}
if ((num1 === 14) && (num2 === 8)) {
    console.log('14 + 8 = 22')
}
if ((num1 === 14) && (num2 === 9)) {
    console.log('14 + 9 = 23')
}
if ((num1 === 14) && (num2 === 10)) {
    console.log('14 + 10 = 24')
}
if ((num1 === 14) && (num2 === 11)) {
    console.log('14 + 11 = 25')
}
if ((num1 === 14) && (num2 === 12)) {
    console.log('14 + 12 = 26')
}
if ((num1 === 14) && (num2 === 13)) {
    console.log('14 + 13 = 27')
}
if ((num1 === 14) && (num2 === 14)) {
    console.log('14 + 14 = 28')
}
if ((num1 === 14) && (num2 === 15)) {
    console.log('14 + 15 = 29')
}
if ((num1 === 14) && (num2 === 16)) {
    console.log('14 + 16 = 30')
}
if ((num1 === 14) && (num2 === 17)) {
    console.log('14 + 17 = 31')
}
if ((num1 === 14) && (num2 === 18)) {
    console.log('14 + 18 = 32')
}
if ((num1 === 14) && (num2 === 19)) {
    console.log('14 + 19 = 33')
}
if ((num1 === 14) && (num2 === 20)) {
    console.log('14 + 20 = 34')
}
if ((num1 === 14) && (num2 === 21)) {
    console.log('14 + 21 = 35')
}
if ((num1 === 14) && (num2 === 22)) {
    console.log('14 + 22 = 36')
}
if ((num1 === 14) && (num2 === 23)) {
    console.log('14 + 23 = 37')
}
if ((num1 === 14) && (num2 === 24)) {
    console.log('14 + 24 = 38')
}
if ((num1 === 14) && (num2 === 25)) {
    console.log('14 + 25 = 39')
}
if ((num1 === 14) && (num2 === 26)) {
    console.log('14 + 26 = 40')
}
if ((num1 === 14) && (num2 === 27)) {
    console.log('14 + 27 = 41')
}
if ((num1 === 14) && (num2 === 28)) {
    console.log('14 + 28 = 42')
}
if ((num1 === 14) && (num2 === 29)) {
    console.log('14 + 29 = 43')
}
if ((num1 === 14) && (num2 === 30)) {
    console.log('14 + 30 = 44')
}
if ((num1 === 14) && (num2 === 31)) {
    console.log('14 + 31 = 45')
}
if ((num1 === 14) && (num2 === 32)) {
    console.log('14 + 32 = 46')
}
if ((num1 === 14) && (num2 === 33)) {
    console.log('14 + 33 = 47')
}
if ((num1 === 14) && (num2 === 34)) {
    console.log('14 + 34 = 48')
}
if ((num1 === 14) && (num2 === 35)) {
    console.log('14 + 35 = 49')
}
if ((num1 === 14) && (num2 === 36)) {
    console.log('14 + 36 = 50')
}
if ((num1 === 14) && (num2 === 37)) {
    console.log('14 + 37 = 51')
}
if ((num1 === 14) && (num2 === 38)) {
    console.log('14 + 38 = 52')
}
if ((num1 === 14) && (num2 === 39)) {
    console.log('14 + 39 = 53')
}
if ((num1 === 14) && (num2 === 40)) {
    console.log('14 + 40 = 54')
}
if ((num1 === 14) && (num2 === 41)) {
    console.log('14 + 41 = 55')
}
if ((num1 === 14) && (num2 === 42)) {
    console.log('14 + 42 = 56')
}
if ((num1 === 14) && (num2 === 43)) {
    console.log('14 + 43 = 57')
}
if ((num1 === 14) && (num2 === 44)) {
    console.log('14 + 44 = 58')
}
if ((num1 === 14) && (num2 === 45)) {
    console.log('14 + 45 = 59')
}
if ((num1 === 14) && (num2 === 46)) {
    console.log('14 + 46 = 60')
}
if ((num1 === 14) && (num2 === 47)) {
    console.log('14 + 47 = 61')
}
if ((num1 === 14) && (num2 === 48)) {
    console.log('14 + 48 = 62')
}
if ((num1 === 14) && (num2 === 49)) {
    console.log('14 + 49 = 63')
}
if ((num1 === 14) && (num2 === 50)) {
    console.log('14 + 50 = 64')
}
if ((num1 === 15) && (num2 === 0)) {
    console.log('15 + 0 = 15')
}
if ((num1 === 15) && (num2 === 1)) {
    console.log('15 + 1 = 16')
}
if ((num1 === 15) && (num2 === 2)) {
    console.log('15 + 2 = 17')
}
if ((num1 === 15) && (num2 === 3)) {
    console.log('15 + 3 = 18')
}
if ((num1 === 15) && (num2 === 4)) {
    console.log('15 + 4 = 19')
}
if ((num1 === 15) && (num2 === 5)) {
    console.log('15 + 5 = 20')
}
if ((num1 === 15) && (num2 === 6)) {
    console.log('15 + 6 = 21')
}
if ((num1 === 15) && (num2 === 7)) {
    console.log('15 + 7 = 22')
}
if ((num1 === 15) && (num2 === 8)) {
    console.log('15 + 8 = 23')
}
if ((num1 === 15) && (num2 === 9)) {
    console.log('15 + 9 = 24')
}
if ((num1 === 15) && (num2 === 10)) {
    console.log('15 + 10 = 25')
}
if ((num1 === 15) && (num2 === 11)) {
    console.log('15 + 11 = 26')
}
if ((num1 === 15) && (num2 === 12)) {
    console.log('15 + 12 = 27')
}
if ((num1 === 15) && (num2 === 13)) {
    console.log('15 + 13 = 28')
}
if ((num1 === 15) && (num2 === 14)) {
    console.log('15 + 14 = 29')
}
if ((num1 === 15) && (num2 === 15)) {
    console.log('15 + 15 = 30')
}
if ((num1 === 15) && (num2 === 16)) {
    console.log('15 + 16 = 31')
}
if ((num1 === 15) && (num2 === 17)) {
    console.log('15 + 17 = 32')
}
if ((num1 === 15) && (num2 === 18)) {
    console.log('15 + 18 = 33')
}
if ((num1 === 15) && (num2 === 19)) {
    console.log('15 + 19 = 34')
}
if ((num1 === 15) && (num2 === 20)) {
    console.log('15 + 20 = 35')
}
if ((num1 === 15) && (num2 === 21)) {
    console.log('15 + 21 = 36')
}
if ((num1 === 15) && (num2 === 22)) {
    console.log('15 + 22 = 37')
}
if ((num1 === 15) && (num2 === 23)) {
    console.log('15 + 23 = 38')
}
if ((num1 === 15) && (num2 === 24)) {
    console.log('15 + 24 = 39')
}
if ((num1 === 15) && (num2 === 25)) {
    console.log('15 + 25 = 40')
}
if ((num1 === 15) && (num2 === 26)) {
    console.log('15 + 26 = 41')
}
if ((num1 === 15) && (num2 === 27)) {
    console.log('15 + 27 = 42')
}
if ((num1 === 15) && (num2 === 28)) {
    console.log('15 + 28 = 43')
}
if ((num1 === 15) && (num2 === 29)) {
    console.log('15 + 29 = 44')
}
if ((num1 === 15) && (num2 === 30)) {
    console.log('15 + 30 = 45')
}
if ((num1 === 15) && (num2 === 31)) {
    console.log('15 + 31 = 46')
}
if ((num1 === 15) && (num2 === 32)) {
    console.log('15 + 32 = 47')
}
if ((num1 === 15) && (num2 === 33)) {
    console.log('15 + 33 = 48')
}
if ((num1 === 15) && (num2 === 34)) {
    console.log('15 + 34 = 49')
}
if ((num1 === 15) && (num2 === 35)) {
    console.log('15 + 35 = 50')
}
if ((num1 === 15) && (num2 === 36)) {
    console.log('15 + 36 = 51')
}
if ((num1 === 15) && (num2 === 37)) {
    console.log('15 + 37 = 52')
}
if ((num1 === 15) && (num2 === 38)) {
    console.log('15 + 38 = 53')
}
if ((num1 === 15) && (num2 === 39)) {
    console.log('15 + 39 = 54')
}
if ((num1 === 15) && (num2 === 40)) {
    console.log('15 + 40 = 55')
}
if ((num1 === 15) && (num2 === 41)) {
    console.log('15 + 41 = 56')
}
if ((num1 === 15) && (num2 === 42)) {
    console.log('15 + 42 = 57')
}
if ((num1 === 15) && (num2 === 43)) {
    console.log('15 + 43 = 58')
}
if ((num1 === 15) && (num2 === 44)) {
    console.log('15 + 44 = 59')
}
if ((num1 === 15) && (num2 === 45)) {
    console.log('15 + 45 = 60')
}
if ((num1 === 15) && (num2 === 46)) {
    console.log('15 + 46 = 61')
}
if ((num1 === 15) && (num2 === 47)) {
    console.log('15 + 47 = 62')
}
if ((num1 === 15) && (num2 === 48)) {
    console.log('15 + 48 = 63')
}
if ((num1 === 15) && (num2 === 49)) {
    console.log('15 + 49 = 64')
}
if ((num1 === 15) && (num2 === 50)) {
    console.log('15 + 50 = 65')
}
if ((num1 === 16) && (num2 === 0)) {
    console.log('16 + 0 = 16')
}
if ((num1 === 16) && (num2 === 1)) {
    console.log('16 + 1 = 17')
}
if ((num1 === 16) && (num2 === 2)) {
    console.log('16 + 2 = 18')
}
if ((num1 === 16) && (num2 === 3)) {
    console.log('16 + 3 = 19')
}
if ((num1 === 16) && (num2 === 4)) {
    console.log('16 + 4 = 20')
}
if ((num1 === 16) && (num2 === 5)) {
    console.log('16 + 5 = 21')
}
if ((num1 === 16) && (num2 === 6)) {
    console.log('16 + 6 = 22')
}
if ((num1 === 16) && (num2 === 7)) {
    console.log('16 + 7 = 23')
}
if ((num1 === 16) && (num2 === 8)) {
    console.log('16 + 8 = 24')
}
if ((num1 === 16) && (num2 === 9)) {
    console.log('16 + 9 = 25')
}
if ((num1 === 16) && (num2 === 10)) {
    console.log('16 + 10 = 26')
}
if ((num1 === 16) && (num2 === 11)) {
    console.log('16 + 11 = 27')
}
if ((num1 === 16) && (num2 === 12)) {
    console.log('16 + 12 = 28')
}
if ((num1 === 16) && (num2 === 13)) {
    console.log('16 + 13 = 29')
}
if ((num1 === 16) && (num2 === 14)) {
    console.log('16 + 14 = 30')
}
if ((num1 === 16) && (num2 === 15)) {
    console.log('16 + 15 = 31')
}
if ((num1 === 16) && (num2 === 16)) {
    console.log('16 + 16 = 32')
}
if ((num1 === 16) && (num2 === 17)) {
    console.log('16 + 17 = 33')
}
if ((num1 === 16) && (num2 === 18)) {
    console.log('16 + 18 = 34')
}
if ((num1 === 16) && (num2 === 19)) {
    console.log('16 + 19 = 35')
}
if ((num1 === 16) && (num2 === 20)) {
    console.log('16 + 20 = 36')
}
if ((num1 === 16) && (num2 === 21)) {
    console.log('16 + 21 = 37')
}
if ((num1 === 16) && (num2 === 22)) {
    console.log('16 + 22 = 38')
}
if ((num1 === 16) && (num2 === 23)) {
    console.log('16 + 23 = 39')
}
if ((num1 === 16) && (num2 === 24)) {
    console.log('16 + 24 = 40')
}
if ((num1 === 16) && (num2 === 25)) {
    console.log('16 + 25 = 41')
}
if ((num1 === 16) && (num2 === 26)) {
    console.log('16 + 26 = 42')
}
if ((num1 === 16) && (num2 === 27)) {
    console.log('16 + 27 = 43')
}
if ((num1 === 16) && (num2 === 28)) {
    console.log('16 + 28 = 44')
}
if ((num1 === 16) && (num2 === 29)) {
    console.log('16 + 29 = 45')
}
if ((num1 === 16) && (num2 === 30)) {
    console.log('16 + 30 = 46')
}
if ((num1 === 16) && (num2 === 31)) {
    console.log('16 + 31 = 47')
}
if ((num1 === 16) && (num2 === 32)) {
    console.log('16 + 32 = 48')
}
if ((num1 === 16) && (num2 === 33)) {
    console.log('16 + 33 = 49')
}
if ((num1 === 16) && (num2 === 34)) {
    console.log('16 + 34 = 50')
}
if ((num1 === 16) && (num2 === 35)) {
    console.log('16 + 35 = 51')
}
if ((num1 === 16) && (num2 === 36)) {
    console.log('16 + 36 = 52')
}
if ((num1 === 16) && (num2 === 37)) {
    console.log('16 + 37 = 53')
}
if ((num1 === 16) && (num2 === 38)) {
    console.log('16 + 38 = 54')
}
if ((num1 === 16) && (num2 === 39)) {
    console.log('16 + 39 = 55')
}
if ((num1 === 16) && (num2 === 40)) {
    console.log('16 + 40 = 56')
}
if ((num1 === 16) && (num2 === 41)) {
    console.log('16 + 41 = 57')
}
if ((num1 === 16) && (num2 === 42)) {
    console.log('16 + 42 = 58')
}
if ((num1 === 16) && (num2 === 43)) {
    console.log('16 + 43 = 59')
}
if ((num1 === 16) && (num2 === 44)) {
    console.log('16 + 44 = 60')
}
if ((num1 === 16) && (num2 === 45)) {
    console.log('16 + 45 = 61')
}
if ((num1 === 16) && (num2 === 46)) {
    console.log('16 + 46 = 62')
}
if ((num1 === 16) && (num2 === 47)) {
    console.log('16 + 47 = 63')
}
if ((num1 === 16) && (num2 === 48)) {
    console.log('16 + 48 = 64')
}
if ((num1 === 16) && (num2 === 49)) {
    console.log('16 + 49 = 65')
}
if ((num1 === 16) && (num2 === 50)) {
    console.log('16 + 50 = 66')
}
if ((num1 === 17) && (num2 === 0)) {
    console.log('17 + 0 = 17')
}
if ((num1 === 17) && (num2 === 1)) {
    console.log('17 + 1 = 18')
}
if ((num1 === 17) && (num2 === 2)) {
    console.log('17 + 2 = 19')
}
if ((num1 === 17) && (num2 === 3)) {
    console.log('17 + 3 = 20')
}
if ((num1 === 17) && (num2 === 4)) {
    console.log('17 + 4 = 21')
}
if ((num1 === 17) && (num2 === 5)) {
    console.log('17 + 5 = 22')
}
if ((num1 === 17) && (num2 === 6)) {
    console.log('17 + 6 = 23')
}
if ((num1 === 17) && (num2 === 7)) {
    console.log('17 + 7 = 24')
}
if ((num1 === 17) && (num2 === 8)) {
    console.log('17 + 8 = 25')
}
if ((num1 === 17) && (num2 === 9)) {
    console.log('17 + 9 = 26')
}
if ((num1 === 17) && (num2 === 10)) {
    console.log('17 + 10 = 27')
}
if ((num1 === 17) && (num2 === 11)) {
    console.log('17 + 11 = 28')
}
if ((num1 === 17) && (num2 === 12)) {
    console.log('17 + 12 = 29')
}
if ((num1 === 17) && (num2 === 13)) {
    console.log('17 + 13 = 30')
}
if ((num1 === 17) && (num2 === 14)) {
    console.log('17 + 14 = 31')
}
if ((num1 === 17) && (num2 === 15)) {
    console.log('17 + 15 = 32')
}
if ((num1 === 17) && (num2 === 16)) {
    console.log('17 + 16 = 33')
}
if ((num1 === 17) && (num2 === 17)) {
    console.log('17 + 17 = 34')
}
if ((num1 === 17) && (num2 === 18)) {
    console.log('17 + 18 = 35')
}
if ((num1 === 17) && (num2 === 19)) {
    console.log('17 + 19 = 36')
}
if ((num1 === 17) && (num2 === 20)) {
    console.log('17 + 20 = 37')
}
if ((num1 === 17) && (num2 === 21)) {
    console.log('17 + 21 = 38')
}
if ((num1 === 17) && (num2 === 22)) {
    console.log('17 + 22 = 39')
}
if ((num1 === 17) && (num2 === 23)) {
    console.log('17 + 23 = 40')
}
if ((num1 === 17) && (num2 === 24)) {
    console.log('17 + 24 = 41')
}
if ((num1 === 17) && (num2 === 25)) {
    console.log('17 + 25 = 42')
}
if ((num1 === 17) && (num2 === 26)) {
    console.log('17 + 26 = 43')
}
if ((num1 === 17) && (num2 === 27)) {
    console.log('17 + 27 = 44')
}
if ((num1 === 17) && (num2 === 28)) {
    console.log('17 + 28 = 45')
}
if ((num1 === 17) && (num2 === 29)) {
    console.log('17 + 29 = 46')
}
if ((num1 === 17) && (num2 === 30)) {
    console.log('17 + 30 = 47')
}
if ((num1 === 17) && (num2 === 31)) {
    console.log('17 + 31 = 48')
}
if ((num1 === 17) && (num2 === 32)) {
    console.log('17 + 32 = 49')
}
if ((num1 === 17) && (num2 === 33)) {
    console.log('17 + 33 = 50')
}
if ((num1 === 17) && (num2 === 34)) {
    console.log('17 + 34 = 51')
}
if ((num1 === 17) && (num2 === 35)) {
    console.log('17 + 35 = 52')
}
if ((num1 === 17) && (num2 === 36)) {
    console.log('17 + 36 = 53')
}
if ((num1 === 17) && (num2 === 37)) {
    console.log('17 + 37 = 54')
}
if ((num1 === 17) && (num2 === 38)) {
    console.log('17 + 38 = 55')
}
if ((num1 === 17) && (num2 === 39)) {
    console.log('17 + 39 = 56')
}
if ((num1 === 17) && (num2 === 40)) {
    console.log('17 + 40 = 57')
}
if ((num1 === 17) && (num2 === 41)) {
    console.log('17 + 41 = 58')
}
if ((num1 === 17) && (num2 === 42)) {
    console.log('17 + 42 = 59')
}
if ((num1 === 17) && (num2 === 43)) {
    console.log('17 + 43 = 60')
}
if ((num1 === 17) && (num2 === 44)) {
    console.log('17 + 44 = 61')
}
if ((num1 === 17) && (num2 === 45)) {
    console.log('17 + 45 = 62')
}
if ((num1 === 17) && (num2 === 46)) {
    console.log('17 + 46 = 63')
}
if ((num1 === 17) && (num2 === 47)) {
    console.log('17 + 47 = 64')
}
if ((num1 === 17) && (num2 === 48)) {
    console.log('17 + 48 = 65')
}
if ((num1 === 17) && (num2 === 49)) {
    console.log('17 + 49 = 66')
}
if ((num1 === 17) && (num2 === 50)) {
    console.log('17 + 50 = 67')
}
if ((num1 === 18) && (num2 === 0)) {
    console.log('18 + 0 = 18')
}
if ((num1 === 18) && (num2 === 1)) {
    console.log('18 + 1 = 19')
}
if ((num1 === 18) && (num2 === 2)) {
    console.log('18 + 2 = 20')
}
if ((num1 === 18) && (num2 === 3)) {
    console.log('18 + 3 = 21')
}
if ((num1 === 18) && (num2 === 4)) {
    console.log('18 + 4 = 22')
}
if ((num1 === 18) && (num2 === 5)) {
    console.log('18 + 5 = 23')
}
if ((num1 === 18) && (num2 === 6)) {
    console.log('18 + 6 = 24')
}
if ((num1 === 18) && (num2 === 7)) {
    console.log('18 + 7 = 25')
}
if ((num1 === 18) && (num2 === 8)) {
    console.log('18 + 8 = 26')
}
if ((num1 === 18) && (num2 === 9)) {
    console.log('18 + 9 = 27')
}
if ((num1 === 18) && (num2 === 10)) {
    console.log('18 + 10 = 28')
}
if ((num1 === 18) && (num2 === 11)) {
    console.log('18 + 11 = 29')
}
if ((num1 === 18) && (num2 === 12)) {
    console.log('18 + 12 = 30')
}
if ((num1 === 18) && (num2 === 13)) {
    console.log('18 + 13 = 31')
}
if ((num1 === 18) && (num2 === 14)) {
    console.log('18 + 14 = 32')
}
if ((num1 === 18) && (num2 === 15)) {
    console.log('18 + 15 = 33')
}
if ((num1 === 18) && (num2 === 16)) {
    console.log('18 + 16 = 34')
}
if ((num1 === 18) && (num2 === 17)) {
    console.log('18 + 17 = 35')
}
if ((num1 === 18) && (num2 === 18)) {
    console.log('18 + 18 = 36')
}
if ((num1 === 18) && (num2 === 19)) {
    console.log('18 + 19 = 37')
}
if ((num1 === 18) && (num2 === 20)) {
    console.log('18 + 20 = 38')
}
if ((num1 === 18) && (num2 === 21)) {
    console.log('18 + 21 = 39')
}
if ((num1 === 18) && (num2 === 22)) {
    console.log('18 + 22 = 40')
}
if ((num1 === 18) && (num2 === 23)) {
    console.log('18 + 23 = 41')
}
if ((num1 === 18) && (num2 === 24)) {
    console.log('18 + 24 = 42')
}
if ((num1 === 18) && (num2 === 25)) {
    console.log('18 + 25 = 43')
}
if ((num1 === 18) && (num2 === 26)) {
    console.log('18 + 26 = 44')
}
if ((num1 === 18) && (num2 === 27)) {
    console.log('18 + 27 = 45')
}
if ((num1 === 18) && (num2 === 28)) {
    console.log('18 + 28 = 46')
}
if ((num1 === 18) && (num2 === 29)) {
    console.log('18 + 29 = 47')
}
if ((num1 === 18) && (num2 === 30)) {
    console.log('18 + 30 = 48')
}
if ((num1 === 18) && (num2 === 31)) {
    console.log('18 + 31 = 49')
}
if ((num1 === 18) && (num2 === 32)) {
    console.log('18 + 32 = 50')
}
if ((num1 === 18) && (num2 === 33)) {
    console.log('18 + 33 = 51')
}
if ((num1 === 18) && (num2 === 34)) {
    console.log('18 + 34 = 52')
}
if ((num1 === 18) && (num2 === 35)) {
    console.log('18 + 35 = 53')
}
if ((num1 === 18) && (num2 === 36)) {
    console.log('18 + 36 = 54')
}
if ((num1 === 18) && (num2 === 37)) {
    console.log('18 + 37 = 55')
}
if ((num1 === 18) && (num2 === 38)) {
    console.log('18 + 38 = 56')
}
if ((num1 === 18) && (num2 === 39)) {
    console.log('18 + 39 = 57')
}
if ((num1 === 18) && (num2 === 40)) {
    console.log('18 + 40 = 58')
}
if ((num1 === 18) && (num2 === 41)) {
    console.log('18 + 41 = 59')
}
if ((num1 === 18) && (num2 === 42)) {
    console.log('18 + 42 = 60')
}
if ((num1 === 18) && (num2 === 43)) {
    console.log('18 + 43 = 61')
}
if ((num1 === 18) && (num2 === 44)) {
    console.log('18 + 44 = 62')
}
if ((num1 === 18) && (num2 === 45)) {
    console.log('18 + 45 = 63')
}
if ((num1 === 18) && (num2 === 46)) {
    console.log('18 + 46 = 64')
}
if ((num1 === 18) && (num2 === 47)) {
    console.log('18 + 47 = 65')
}
if ((num1 === 18) && (num2 === 48)) {
    console.log('18 + 48 = 66')
}
if ((num1 === 18) && (num2 === 49)) {
    console.log('18 + 49 = 67')
}
if ((num1 === 18) && (num2 === 50)) {
    console.log('18 + 50 = 68')
}
if ((num1 === 19) && (num2 === 0)) {
    console.log('19 + 0 = 19')
}
if ((num1 === 19) && (num2 === 1)) {
    console.log('19 + 1 = 20')
}
if ((num1 === 19) && (num2 === 2)) {
    console.log('19 + 2 = 21')
}
if ((num1 === 19) && (num2 === 3)) {
    console.log('19 + 3 = 22')
}
if ((num1 === 19) && (num2 === 4)) {
    console.log('19 + 4 = 23')
}
if ((num1 === 19) && (num2 === 5)) {
    console.log('19 + 5 = 24')
}
if ((num1 === 19) && (num2 === 6)) {
    console.log('19 + 6 = 25')
}
if ((num1 === 19) && (num2 === 7)) {
    console.log('19 + 7 = 26')
}
if ((num1 === 19) && (num2 === 8)) {
    console.log('19 + 8 = 27')
}
if ((num1 === 19) && (num2 === 9)) {
    console.log('19 + 9 = 28')
}
if ((num1 === 19) && (num2 === 10)) {
    console.log('19 + 10 = 29')
}
if ((num1 === 19) && (num2 === 11)) {
    console.log('19 + 11 = 30')
}
if ((num1 === 19) && (num2 === 12)) {
    console.log('19 + 12 = 31')
}
if ((num1 === 19) && (num2 === 13)) {
    console.log('19 + 13 = 32')
}
if ((num1 === 19) && (num2 === 14)) {
    console.log('19 + 14 = 33')
}
if ((num1 === 19) && (num2 === 15)) {
    console.log('19 + 15 = 34')
}
if ((num1 === 19) && (num2 === 16)) {
    console.log('19 + 16 = 35')
}
if ((num1 === 19) && (num2 === 17)) {
    console.log('19 + 17 = 36')
}
if ((num1 === 19) && (num2 === 18)) {
    console.log('19 + 18 = 37')
}
if ((num1 === 19) && (num2 === 19)) {
    console.log('19 + 19 = 38')
}
if ((num1 === 19) && (num2 === 20)) {
    console.log('19 + 20 = 39')
}
if ((num1 === 19) && (num2 === 21)) {
    console.log('19 + 21 = 40')
}
if ((num1 === 19) && (num2 === 22)) {
    console.log('19 + 22 = 41')
}
if ((num1 === 19) && (num2 === 23)) {
    console.log('19 + 23 = 42')
}
if ((num1 === 19) && (num2 === 24)) {
    console.log('19 + 24 = 43')
}
if ((num1 === 19) && (num2 === 25)) {
    console.log('19 + 25 = 44')
}
if ((num1 === 19) && (num2 === 26)) {
    console.log('19 + 26 = 45')
}
if ((num1 === 19) && (num2 === 27)) {
    console.log('19 + 27 = 46')
}
if ((num1 === 19) && (num2 === 28)) {
    console.log('19 + 28 = 47')
}
if ((num1 === 19) && (num2 === 29)) {
    console.log('19 + 29 = 48')
}
if ((num1 === 19) && (num2 === 30)) {
    console.log('19 + 30 = 49')
}
if ((num1 === 19) && (num2 === 31)) {
    console.log('19 + 31 = 50')
}
if ((num1 === 19) && (num2 === 32)) {
    console.log('19 + 32 = 51')
}
if ((num1 === 19) && (num2 === 33)) {
    console.log('19 + 33 = 52')
}
if ((num1 === 19) && (num2 === 34)) {
    console.log('19 + 34 = 53')
}
if ((num1 === 19) && (num2 === 35)) {
    console.log('19 + 35 = 54')
}
if ((num1 === 19) && (num2 === 36)) {
    console.log('19 + 36 = 55')
}
if ((num1 === 19) && (num2 === 37)) {
    console.log('19 + 37 = 56')
}
if ((num1 === 19) && (num2 === 38)) {
    console.log('19 + 38 = 57')
}
if ((num1 === 19) && (num2 === 39)) {
    console.log('19 + 39 = 58')
}
if ((num1 === 19) && (num2 === 40)) {
    console.log('19 + 40 = 59')
}
if ((num1 === 19) && (num2 === 41)) {
    console.log('19 + 41 = 60')
}
if ((num1 === 19) && (num2 === 42)) {
    console.log('19 + 42 = 61')
}
if ((num1 === 19) && (num2 === 43)) {
    console.log('19 + 43 = 62')
}
if ((num1 === 19) && (num2 === 44)) {
    console.log('19 + 44 = 63')
}
if ((num1 === 19) && (num2 === 45)) {
    console.log('19 + 45 = 64')
}
if ((num1 === 19) && (num2 === 46)) {
    console.log('19 + 46 = 65')
}
if ((num1 === 19) && (num2 === 47)) {
    console.log('19 + 47 = 66')
}
if ((num1 === 19) && (num2 === 48)) {
    console.log('19 + 48 = 67')
}
if ((num1 === 19) && (num2 === 49)) {
    console.log('19 + 49 = 68')
}
if ((num1 === 19) && (num2 === 50)) {
    console.log('19 + 50 = 69')
}
if ((num1 === 20) && (num2 === 0)) {
    console.log('20 + 0 = 20')
}
if ((num1 === 20) && (num2 === 1)) {
    console.log('20 + 1 = 21')
}
if ((num1 === 20) && (num2 === 2)) {
    console.log('20 + 2 = 22')
}
if ((num1 === 20) && (num2 === 3)) {
    console.log('20 + 3 = 23')
}
if ((num1 === 20) && (num2 === 4)) {
    console.log('20 + 4 = 24')
}
if ((num1 === 20) && (num2 === 5)) {
    console.log('20 + 5 = 25')
}
if ((num1 === 20) && (num2 === 6)) {
    console.log('20 + 6 = 26')
}
if ((num1 === 20) && (num2 === 7)) {
    console.log('20 + 7 = 27')
}
if ((num1 === 20) && (num2 === 8)) {
    console.log('20 + 8 = 28')
}
if ((num1 === 20) && (num2 === 9)) {
    console.log('20 + 9 = 29')
}
if ((num1 === 20) && (num2 === 10)) {
    console.log('20 + 10 = 30')
}
if ((num1 === 20) && (num2 === 11)) {
    console.log('20 + 11 = 31')
}
if ((num1 === 20) && (num2 === 12)) {
    console.log('20 + 12 = 32')
}
if ((num1 === 20) && (num2 === 13)) {
    console.log('20 + 13 = 33')
}
if ((num1 === 20) && (num2 === 14)) {
    console.log('20 + 14 = 34')
}
if ((num1 === 20) && (num2 === 15)) {
    console.log('20 + 15 = 35')
}
if ((num1 === 20) && (num2 === 16)) {
    console.log('20 + 16 = 36')
}
if ((num1 === 20) && (num2 === 17)) {
    console.log('20 + 17 = 37')
}
if ((num1 === 20) && (num2 === 18)) {
    console.log('20 + 18 = 38')
}
if ((num1 === 20) && (num2 === 19)) {
    console.log('20 + 19 = 39')
}
if ((num1 === 20) && (num2 === 20)) {
    console.log('20 + 20 = 40')
}
if ((num1 === 20) && (num2 === 21)) {
    console.log('20 + 21 = 41')
}
if ((num1 === 20) && (num2 === 22)) {
    console.log('20 + 22 = 42')
}
if ((num1 === 20) && (num2 === 23)) {
    console.log('20 + 23 = 43')
}
if ((num1 === 20) && (num2 === 24)) {
    console.log('20 + 24 = 44')
}
if ((num1 === 20) && (num2 === 25)) {
    console.log('20 + 25 = 45')
}
if ((num1 === 20) && (num2 === 26)) {
    console.log('20 + 26 = 46')
}
if ((num1 === 20) && (num2 === 27)) {
    console.log('20 + 27 = 47')
}
if ((num1 === 20) && (num2 === 28)) {
    console.log('20 + 28 = 48')
}
if ((num1 === 20) && (num2 === 29)) {
    console.log('20 + 29 = 49')
}
if ((num1 === 20) && (num2 === 30)) {
    console.log('20 + 30 = 50')
}
if ((num1 === 20) && (num2 === 31)) {
    console.log('20 + 31 = 51')
}
if ((num1 === 20) && (num2 === 32)) {
    console.log('20 + 32 = 52')
}
if ((num1 === 20) && (num2 === 33)) {
    console.log('20 + 33 = 53')
}
if ((num1 === 20) && (num2 === 34)) {
    console.log('20 + 34 = 54')
}
if ((num1 === 20) && (num2 === 35)) {
    console.log('20 + 35 = 55')
}
if ((num1 === 20) && (num2 === 36)) {
    console.log('20 + 36 = 56')
}
if ((num1 === 20) && (num2 === 37)) {
    console.log('20 + 37 = 57')
}
if ((num1 === 20) && (num2 === 38)) {
    console.log('20 + 38 = 58')
}
if ((num1 === 20) && (num2 === 39)) {
    console.log('20 + 39 = 59')
}
if ((num1 === 20) && (num2 === 40)) {
    console.log('20 + 40 = 60')
}
if ((num1 === 20) && (num2 === 41)) {
    console.log('20 + 41 = 61')
}
if ((num1 === 20) && (num2 === 42)) {
    console.log('20 + 42 = 62')
}
if ((num1 === 20) && (num2 === 43)) {
    console.log('20 + 43 = 63')
}
if ((num1 === 20) && (num2 === 44)) {
    console.log('20 + 44 = 64')
}
if ((num1 === 20) && (num2 === 45)) {
    console.log('20 + 45 = 65')
}
if ((num1 === 20) && (num2 === 46)) {
    console.log('20 + 46 = 66')
}
if ((num1 === 20) && (num2 === 47)) {
    console.log('20 + 47 = 67')
}
if ((num1 === 20) && (num2 === 48)) {
    console.log('20 + 48 = 68')
}
if ((num1 === 20) && (num2 === 49)) {
    console.log('20 + 49 = 69')
}
if ((num1 === 20) && (num2 === 50)) {
    console.log('20 + 50 = 70')
}
if ((num1 === 21) && (num2 === 0)) {
    console.log('21 + 0 = 21')
}
if ((num1 === 21) && (num2 === 1)) {
    console.log('21 + 1 = 22')
}
if ((num1 === 21) && (num2 === 2)) {
    console.log('21 + 2 = 23')
}
if ((num1 === 21) && (num2 === 3)) {
    console.log('21 + 3 = 24')
}
if ((num1 === 21) && (num2 === 4)) {
    console.log('21 + 4 = 25')
}
if ((num1 === 21) && (num2 === 5)) {
    console.log('21 + 5 = 26')
}
if ((num1 === 21) && (num2 === 6)) {
    console.log('21 + 6 = 27')
}
if ((num1 === 21) && (num2 === 7)) {
    console.log('21 + 7 = 28')
}
if ((num1 === 21) && (num2 === 8)) {
    console.log('21 + 8 = 29')
}
if ((num1 === 21) && (num2 === 9)) {
    console.log('21 + 9 = 30')
}
if ((num1 === 21) && (num2 === 10)) {
    console.log('21 + 10 = 31')
}
if ((num1 === 21) && (num2 === 11)) {
    console.log('21 + 11 = 32')
}
if ((num1 === 21) && (num2 === 12)) {
    console.log('21 + 12 = 33')
}
if ((num1 === 21) && (num2 === 13)) {
    console.log('21 + 13 = 34')
}
if ((num1 === 21) && (num2 === 14)) {
    console.log('21 + 14 = 35')
}
if ((num1 === 21) && (num2 === 15)) {
    console.log('21 + 15 = 36')
}
if ((num1 === 21) && (num2 === 16)) {
    console.log('21 + 16 = 37')
}
if ((num1 === 21) && (num2 === 17)) {
    console.log('21 + 17 = 38')
}
if ((num1 === 21) && (num2 === 18)) {
    console.log('21 + 18 = 39')
}
if ((num1 === 21) && (num2 === 19)) {
    console.log('21 + 19 = 40')
}
if ((num1 === 21) && (num2 === 20)) {
    console.log('21 + 20 = 41')
}
if ((num1 === 21) && (num2 === 21)) {
    console.log('21 + 21 = 42')
}
if ((num1 === 21) && (num2 === 22)) {
    console.log('21 + 22 = 43')
}
if ((num1 === 21) && (num2 === 23)) {
    console.log('21 + 23 = 44')
}
if ((num1 === 21) && (num2 === 24)) {
    console.log('21 + 24 = 45')
}
if ((num1 === 21) && (num2 === 25)) {
    console.log('21 + 25 = 46')
}
if ((num1 === 21) && (num2 === 26)) {
    console.log('21 + 26 = 47')
}
if ((num1 === 21) && (num2 === 27)) {
    console.log('21 + 27 = 48')
}
if ((num1 === 21) && (num2 === 28)) {
    console.log('21 + 28 = 49')
}
if ((num1 === 21) && (num2 === 29)) {
    console.log('21 + 29 = 50')
}
if ((num1 === 21) && (num2 === 30)) {
    console.log('21 + 30 = 51')
}
if ((num1 === 21) && (num2 === 31)) {
    console.log('21 + 31 = 52')
}
if ((num1 === 21) && (num2 === 32)) {
    console.log('21 + 32 = 53')
}
if ((num1 === 21) && (num2 === 33)) {
    console.log('21 + 33 = 54')
}
if ((num1 === 21) && (num2 === 34)) {
    console.log('21 + 34 = 55')
}
if ((num1 === 21) && (num2 === 35)) {
    console.log('21 + 35 = 56')
}
if ((num1 === 21) && (num2 === 36)) {
    console.log('21 + 36 = 57')
}
if ((num1 === 21) && (num2 === 37)) {
    console.log('21 + 37 = 58')
}
if ((num1 === 21) && (num2 === 38)) {
    console.log('21 + 38 = 59')
}
if ((num1 === 21) && (num2 === 39)) {
    console.log('21 + 39 = 60')
}
if ((num1 === 21) && (num2 === 40)) {
    console.log('21 + 40 = 61')
}
if ((num1 === 21) && (num2 === 41)) {
    console.log('21 + 41 = 62')
}
if ((num1 === 21) && (num2 === 42)) {
    console.log('21 + 42 = 63')
}
if ((num1 === 21) && (num2 === 43)) {
    console.log('21 + 43 = 64')
}
if ((num1 === 21) && (num2 === 44)) {
    console.log('21 + 44 = 65')
}
if ((num1 === 21) && (num2 === 45)) {
    console.log('21 + 45 = 66')
}
if ((num1 === 21) && (num2 === 46)) {
    console.log('21 + 46 = 67')
}
if ((num1 === 21) && (num2 === 47)) {
    console.log('21 + 47 = 68')
}
if ((num1 === 21) && (num2 === 48)) {
    console.log('21 + 48 = 69')
}
if ((num1 === 21) && (num2 === 49)) {
    console.log('21 + 49 = 70')
}
if ((num1 === 21) && (num2 === 50)) {
    console.log('21 + 50 = 71')
}
if ((num1 === 22) && (num2 === 0)) {
    console.log('22 + 0 = 22')
}
if ((num1 === 22) && (num2 === 1)) {
    console.log('22 + 1 = 23')
}
if ((num1 === 22) && (num2 === 2)) {
    console.log('22 + 2 = 24')
}
if ((num1 === 22) && (num2 === 3)) {
    console.log('22 + 3 = 25')
}
if ((num1 === 22) && (num2 === 4)) {
    console.log('22 + 4 = 26')
}
if ((num1 === 22) && (num2 === 5)) {
    console.log('22 + 5 = 27')
}
if ((num1 === 22) && (num2 === 6)) {
    console.log('22 + 6 = 28')
}
if ((num1 === 22) && (num2 === 7)) {
    console.log('22 + 7 = 29')
}
if ((num1 === 22) && (num2 === 8)) {
    console.log('22 + 8 = 30')
}
if ((num1 === 22) && (num2 === 9)) {
    console.log('22 + 9 = 31')
}
if ((num1 === 22) && (num2 === 10)) {
    console.log('22 + 10 = 32')
}
if ((num1 === 22) && (num2 === 11)) {
    console.log('22 + 11 = 33')
}
if ((num1 === 22) && (num2 === 12)) {
    console.log('22 + 12 = 34')
}
if ((num1 === 22) && (num2 === 13)) {
    console.log('22 + 13 = 35')
}
if ((num1 === 22) && (num2 === 14)) {
    console.log('22 + 14 = 36')
}
if ((num1 === 22) && (num2 === 15)) {
    console.log('22 + 15 = 37')
}
if ((num1 === 22) && (num2 === 16)) {
    console.log('22 + 16 = 38')
}
if ((num1 === 22) && (num2 === 17)) {
    console.log('22 + 17 = 39')
}
if ((num1 === 22) && (num2 === 18)) {
    console.log('22 + 18 = 40')
}
if ((num1 === 22) && (num2 === 19)) {
    console.log('22 + 19 = 41')
}
if ((num1 === 22) && (num2 === 20)) {
    console.log('22 + 20 = 42')
}
if ((num1 === 22) && (num2 === 21)) {
    console.log('22 + 21 = 43')
}
if ((num1 === 22) && (num2 === 22)) {
    console.log('22 + 22 = 44')
}
if ((num1 === 22) && (num2 === 23)) {
    console.log('22 + 23 = 45')
}
if ((num1 === 22) && (num2 === 24)) {
    console.log('22 + 24 = 46')
}
if ((num1 === 22) && (num2 === 25)) {
    console.log('22 + 25 = 47')
}
if ((num1 === 22) && (num2 === 26)) {
    console.log('22 + 26 = 48')
}
if ((num1 === 22) && (num2 === 27)) {
    console.log('22 + 27 = 49')
}
if ((num1 === 22) && (num2 === 28)) {
    console.log('22 + 28 = 50')
}
if ((num1 === 22) && (num2 === 29)) {
    console.log('22 + 29 = 51')
}
if ((num1 === 22) && (num2 === 30)) {
    console.log('22 + 30 = 52')
}
if ((num1 === 22) && (num2 === 31)) {
    console.log('22 + 31 = 53')
}
if ((num1 === 22) && (num2 === 32)) {
    console.log('22 + 32 = 54')
}
if ((num1 === 22) && (num2 === 33)) {
    console.log('22 + 33 = 55')
}
if ((num1 === 22) && (num2 === 34)) {
    console.log('22 + 34 = 56')
}
if ((num1 === 22) && (num2 === 35)) {
    console.log('22 + 35 = 57')
}
if ((num1 === 22) && (num2 === 36)) {
    console.log('22 + 36 = 58')
}
if ((num1 === 22) && (num2 === 37)) {
    console.log('22 + 37 = 59')
}
if ((num1 === 22) && (num2 === 38)) {
    console.log('22 + 38 = 60')
}
if ((num1 === 22) && (num2 === 39)) {
    console.log('22 + 39 = 61')
}
if ((num1 === 22) && (num2 === 40)) {
    console.log('22 + 40 = 62')
}
if ((num1 === 22) && (num2 === 41)) {
    console.log('22 + 41 = 63')
}
if ((num1 === 22) && (num2 === 42)) {
    console.log('22 + 42 = 64')
}
if ((num1 === 22) && (num2 === 43)) {
    console.log('22 + 43 = 65')
}
if ((num1 === 22) && (num2 === 44)) {
    console.log('22 + 44 = 66')
}
if ((num1 === 22) && (num2 === 45)) {
    console.log('22 + 45 = 67')
}
if ((num1 === 22) && (num2 === 46)) {
    console.log('22 + 46 = 68')
}
if ((num1 === 22) && (num2 === 47)) {
    console.log('22 + 47 = 69')
}
if ((num1 === 22) && (num2 === 48)) {
    console.log('22 + 48 = 70')
}
if ((num1 === 22) && (num2 === 49)) {
    console.log('22 + 49 = 71')
}
if ((num1 === 22) && (num2 === 50)) {
    console.log('22 + 50 = 72')
}
if ((num1 === 23) && (num2 === 0)) {
    console.log('23 + 0 = 23')
}
if ((num1 === 23) && (num2 === 1)) {
    console.log('23 + 1 = 24')
}
if ((num1 === 23) && (num2 === 2)) {
    console.log('23 + 2 = 25')
}
if ((num1 === 23) && (num2 === 3)) {
    console.log('23 + 3 = 26')
}
if ((num1 === 23) && (num2 === 4)) {
    console.log('23 + 4 = 27')
}
if ((num1 === 23) && (num2 === 5)) {
    console.log('23 + 5 = 28')
}
if ((num1 === 23) && (num2 === 6)) {
    console.log('23 + 6 = 29')
}
if ((num1 === 23) && (num2 === 7)) {
    console.log('23 + 7 = 30')
}
if ((num1 === 23) && (num2 === 8)) {
    console.log('23 + 8 = 31')
}
if ((num1 === 23) && (num2 === 9)) {
    console.log('23 + 9 = 32')
}
if ((num1 === 23) && (num2 === 10)) {
    console.log('23 + 10 = 33')
}
if ((num1 === 23) && (num2 === 11)) {
    console.log('23 + 11 = 34')
}
if ((num1 === 23) && (num2 === 12)) {
    console.log('23 + 12 = 35')
}
if ((num1 === 23) && (num2 === 13)) {
    console.log('23 + 13 = 36')
}
if ((num1 === 23) && (num2 === 14)) {
    console.log('23 + 14 = 37')
}
if ((num1 === 23) && (num2 === 15)) {
    console.log('23 + 15 = 38')
}
if ((num1 === 23) && (num2 === 16)) {
    console.log('23 + 16 = 39')
}
if ((num1 === 23) && (num2 === 17)) {
    console.log('23 + 17 = 40')
}
if ((num1 === 23) && (num2 === 18)) {
    console.log('23 + 18 = 41')
}
if ((num1 === 23) && (num2 === 19)) {
    console.log('23 + 19 = 42')
}
if ((num1 === 23) && (num2 === 20)) {
    console.log('23 + 20 = 43')
}
if ((num1 === 23) && (num2 === 21)) {
    console.log('23 + 21 = 44')
}
if ((num1 === 23) && (num2 === 22)) {
    console.log('23 + 22 = 45')
}
if ((num1 === 23) && (num2 === 23)) {
    console.log('23 + 23 = 46')
}
if ((num1 === 23) && (num2 === 24)) {
    console.log('23 + 24 = 47')
}
if ((num1 === 23) && (num2 === 25)) {
    console.log('23 + 25 = 48')
}
if ((num1 === 23) && (num2 === 26)) {
    console.log('23 + 26 = 49')
}
if ((num1 === 23) && (num2 === 27)) {
    console.log('23 + 27 = 50')
}
if ((num1 === 23) && (num2 === 28)) {
    console.log('23 + 28 = 51')
}
if ((num1 === 23) && (num2 === 29)) {
    console.log('23 + 29 = 52')
}
if ((num1 === 23) && (num2 === 30)) {
    console.log('23 + 30 = 53')
}
if ((num1 === 23) && (num2 === 31)) {
    console.log('23 + 31 = 54')
}
if ((num1 === 23) && (num2 === 32)) {
    console.log('23 + 32 = 55')
}
if ((num1 === 23) && (num2 === 33)) {
    console.log('23 + 33 = 56')
}
if ((num1 === 23) && (num2 === 34)) {
    console.log('23 + 34 = 57')
}
if ((num1 === 23) && (num2 === 35)) {
    console.log('23 + 35 = 58')
}
if ((num1 === 23) && (num2 === 36)) {
    console.log('23 + 36 = 59')
}
if ((num1 === 23) && (num2 === 37)) {
    console.log('23 + 37 = 60')
}
if ((num1 === 23) && (num2 === 38)) {
    console.log('23 + 38 = 61')
}
if ((num1 === 23) && (num2 === 39)) {
    console.log('23 + 39 = 62')
}
if ((num1 === 23) && (num2 === 40)) {
    console.log('23 + 40 = 63')
}
if ((num1 === 23) && (num2 === 41)) {
    console.log('23 + 41 = 64')
}
if ((num1 === 23) && (num2 === 42)) {
    console.log('23 + 42 = 65')
}
if ((num1 === 23) && (num2 === 43)) {
    console.log('23 + 43 = 66')
}
if ((num1 === 23) && (num2 === 44)) {
    console.log('23 + 44 = 67')
}
if ((num1 === 23) && (num2 === 45)) {
    console.log('23 + 45 = 68')
}
if ((num1 === 23) && (num2 === 46)) {
    console.log('23 + 46 = 69')
}
if ((num1 === 23) && (num2 === 47)) {
    console.log('23 + 47 = 70')
}
if ((num1 === 23) && (num2 === 48)) {
    console.log('23 + 48 = 71')
}
if ((num1 === 23) && (num2 === 49)) {
    console.log('23 + 49 = 72')
}
if ((num1 === 23) && (num2 === 50)) {
    console.log('23 + 50 = 73')
}
if ((num1 === 24) && (num2 === 0)) {
    console.log('24 + 0 = 24')
}
if ((num1 === 24) && (num2 === 1)) {
    console.log('24 + 1 = 25')
}
if ((num1 === 24) && (num2 === 2)) {
    console.log('24 + 2 = 26')
}
if ((num1 === 24) && (num2 === 3)) {
    console.log('24 + 3 = 27')
}
if ((num1 === 24) && (num2 === 4)) {
    console.log('24 + 4 = 28')
}
if ((num1 === 24) && (num2 === 5)) {
    console.log('24 + 5 = 29')
}
if ((num1 === 24) && (num2 === 6)) {
    console.log('24 + 6 = 30')
}
if ((num1 === 24) && (num2 === 7)) {
    console.log('24 + 7 = 31')
}
if ((num1 === 24) && (num2 === 8)) {
    console.log('24 + 8 = 32')
}
if ((num1 === 24) && (num2 === 9)) {
    console.log('24 + 9 = 33')
}
if ((num1 === 24) && (num2 === 10)) {
    console.log('24 + 10 = 34')
}
if ((num1 === 24) && (num2 === 11)) {
    console.log('24 + 11 = 35')
}
if ((num1 === 24) && (num2 === 12)) {
    console.log('24 + 12 = 36')
}
if ((num1 === 24) && (num2 === 13)) {
    console.log('24 + 13 = 37')
}
if ((num1 === 24) && (num2 === 14)) {
    console.log('24 + 14 = 38')
}
if ((num1 === 24) && (num2 === 15)) {
    console.log('24 + 15 = 39')
}
if ((num1 === 24) && (num2 === 16)) {
    console.log('24 + 16 = 40')
}
if ((num1 === 24) && (num2 === 17)) {
    console.log('24 + 17 = 41')
}
if ((num1 === 24) && (num2 === 18)) {
    console.log('24 + 18 = 42')
}
if ((num1 === 24) && (num2 === 19)) {
    console.log('24 + 19 = 43')
}
if ((num1 === 24) && (num2 === 20)) {
    console.log('24 + 20 = 44')
}
if ((num1 === 24) && (num2 === 21)) {
    console.log('24 + 21 = 45')
}
if ((num1 === 24) && (num2 === 22)) {
    console.log('24 + 22 = 46')
}
if ((num1 === 24) && (num2 === 23)) {
    console.log('24 + 23 = 47')
}
if ((num1 === 24) && (num2 === 24)) {
    console.log('24 + 24 = 48')
}
if ((num1 === 24) && (num2 === 25)) {
    console.log('24 + 25 = 49')
}
if ((num1 === 24) && (num2 === 26)) {
    console.log('24 + 26 = 50')
}
if ((num1 === 24) && (num2 === 27)) {
    console.log('24 + 27 = 51')
}
if ((num1 === 24) && (num2 === 28)) {
    console.log('24 + 28 = 52')
}
if ((num1 === 24) && (num2 === 29)) {
    console.log('24 + 29 = 53')
}
if ((num1 === 24) && (num2 === 30)) {
    console.log('24 + 30 = 54')
}
if ((num1 === 24) && (num2 === 31)) {
    console.log('24 + 31 = 55')
}
if ((num1 === 24) && (num2 === 32)) {
    console.log('24 + 32 = 56')
}
if ((num1 === 24) && (num2 === 33)) {
    console.log('24 + 33 = 57')
}
if ((num1 === 24) && (num2 === 34)) {
    console.log('24 + 34 = 58')
}
if ((num1 === 24) && (num2 === 35)) {
    console.log('24 + 35 = 59')
}
if ((num1 === 24) && (num2 === 36)) {
    console.log('24 + 36 = 60')
}
if ((num1 === 24) && (num2 === 37)) {
    console.log('24 + 37 = 61')
}
if ((num1 === 24) && (num2 === 38)) {
    console.log('24 + 38 = 62')
}
if ((num1 === 24) && (num2 === 39)) {
    console.log('24 + 39 = 63')
}
if ((num1 === 24) && (num2 === 40)) {
    console.log('24 + 40 = 64')
}
if ((num1 === 24) && (num2 === 41)) {
    console.log('24 + 41 = 65')
}
if ((num1 === 24) && (num2 === 42)) {
    console.log('24 + 42 = 66')
}
if ((num1 === 24) && (num2 === 43)) {
    console.log('24 + 43 = 67')
}
if ((num1 === 24) && (num2 === 44)) {
    console.log('24 + 44 = 68')
}
if ((num1 === 24) && (num2 === 45)) {
    console.log('24 + 45 = 69')
}
if ((num1 === 24) && (num2 === 46)) {
    console.log('24 + 46 = 70')
}
if ((num1 === 24) && (num2 === 47)) {
    console.log('24 + 47 = 71')
}
if ((num1 === 24) && (num2 === 48)) {
    console.log('24 + 48 = 72')
}
if ((num1 === 24) && (num2 === 49)) {
    console.log('24 + 49 = 73')
}
if ((num1 === 24) && (num2 === 50)) {
    console.log('24 + 50 = 74')
}
if ((num1 === 25) && (num2 === 0)) {
    console.log('25 + 0 = 25')
}
if ((num1 === 25) && (num2 === 1)) {
    console.log('25 + 1 = 26')
}
if ((num1 === 25) && (num2 === 2)) {
    console.log('25 + 2 = 27')
}
if ((num1 === 25) && (num2 === 3)) {
    console.log('25 + 3 = 28')
}
if ((num1 === 25) && (num2 === 4)) {
    console.log('25 + 4 = 29')
}
if ((num1 === 25) && (num2 === 5)) {
    console.log('25 + 5 = 30')
}
if ((num1 === 25) && (num2 === 6)) {
    console.log('25 + 6 = 31')
}
if ((num1 === 25) && (num2 === 7)) {
    console.log('25 + 7 = 32')
}
if ((num1 === 25) && (num2 === 8)) {
    console.log('25 + 8 = 33')
}
if ((num1 === 25) && (num2 === 9)) {
    console.log('25 + 9 = 34')
}
if ((num1 === 25) && (num2 === 10)) {
    console.log('25 + 10 = 35')
}
if ((num1 === 25) && (num2 === 11)) {
    console.log('25 + 11 = 36')
}
if ((num1 === 25) && (num2 === 12)) {
    console.log('25 + 12 = 37')
}
if ((num1 === 25) && (num2 === 13)) {
    console.log('25 + 13 = 38')
}
if ((num1 === 25) && (num2 === 14)) {
    console.log('25 + 14 = 39')
}
if ((num1 === 25) && (num2 === 15)) {
    console.log('25 + 15 = 40')
}
if ((num1 === 25) && (num2 === 16)) {
    console.log('25 + 16 = 41')
}
if ((num1 === 25) && (num2 === 17)) {
    console.log('25 + 17 = 42')
}
if ((num1 === 25) && (num2 === 18)) {
    console.log('25 + 18 = 43')
}
if ((num1 === 25) && (num2 === 19)) {
    console.log('25 + 19 = 44')
}
if ((num1 === 25) && (num2 === 20)) {
    console.log('25 + 20 = 45')
}
if ((num1 === 25) && (num2 === 21)) {
    console.log('25 + 21 = 46')
}
if ((num1 === 25) && (num2 === 22)) {
    console.log('25 + 22 = 47')
}
if ((num1 === 25) && (num2 === 23)) {
    console.log('25 + 23 = 48')
}
if ((num1 === 25) && (num2 === 24)) {
    console.log('25 + 24 = 49')
}
if ((num1 === 25) && (num2 === 25)) {
    console.log('25 + 25 = 50')
}
if ((num1 === 25) && (num2 === 26)) {
    console.log('25 + 26 = 51')
}
if ((num1 === 25) && (num2 === 27)) {
    console.log('25 + 27 = 52')
}
if ((num1 === 25) && (num2 === 28)) {
    console.log('25 + 28 = 53')
}
if ((num1 === 25) && (num2 === 29)) {
    console.log('25 + 29 = 54')
}
if ((num1 === 25) && (num2 === 30)) {
    console.log('25 + 30 = 55')
}
if ((num1 === 25) && (num2 === 31)) {
    console.log('25 + 31 = 56')
}
if ((num1 === 25) && (num2 === 32)) {
    console.log('25 + 32 = 57')
}
if ((num1 === 25) && (num2 === 33)) {
    console.log('25 + 33 = 58')
}
if ((num1 === 25) && (num2 === 34)) {
    console.log('25 + 34 = 59')
}
if ((num1 === 25) && (num2 === 35)) {
    console.log('25 + 35 = 60')
}
if ((num1 === 25) && (num2 === 36)) {
    console.log('25 + 36 = 61')
}
if ((num1 === 25) && (num2 === 37)) {
    console.log('25 + 37 = 62')
}
if ((num1 === 25) && (num2 === 38)) {
    console.log('25 + 38 = 63')
}
if ((num1 === 25) && (num2 === 39)) {
    console.log('25 + 39 = 64')
}
if ((num1 === 25) && (num2 === 40)) {
    console.log('25 + 40 = 65')
}
if ((num1 === 25) && (num2 === 41)) {
    console.log('25 + 41 = 66')
}
if ((num1 === 25) && (num2 === 42)) {
    console.log('25 + 42 = 67')
}
if ((num1 === 25) && (num2 === 43)) {
    console.log('25 + 43 = 68')
}
if ((num1 === 25) && (num2 === 44)) {
    console.log('25 + 44 = 69')
}
if ((num1 === 25) && (num2 === 45)) {
    console.log('25 + 45 = 70')
}
if ((num1 === 25) && (num2 === 46)) {
    console.log('25 + 46 = 71')
}
if ((num1 === 25) && (num2 === 47)) {
    console.log('25 + 47 = 72')
}
if ((num1 === 25) && (num2 === 48)) {
    console.log('25 + 48 = 73')
}
if ((num1 === 25) && (num2 === 49)) {
    console.log('25 + 49 = 74')
}
if ((num1 === 25) && (num2 === 50)) {
    console.log('25 + 50 = 75')
}
if ((num1 === 26) && (num2 === 0)) {
    console.log('26 + 0 = 26')
}
if ((num1 === 26) && (num2 === 1)) {
    console.log('26 + 1 = 27')
}
if ((num1 === 26) && (num2 === 2)) {
    console.log('26 + 2 = 28')
}
if ((num1 === 26) && (num2 === 3)) {
    console.log('26 + 3 = 29')
}
if ((num1 === 26) && (num2 === 4)) {
    console.log('26 + 4 = 30')
}
if ((num1 === 26) && (num2 === 5)) {
    console.log('26 + 5 = 31')
}
if ((num1 === 26) && (num2 === 6)) {
    console.log('26 + 6 = 32')
}
if ((num1 === 26) && (num2 === 7)) {
    console.log('26 + 7 = 33')
}
if ((num1 === 26) && (num2 === 8)) {
    console.log('26 + 8 = 34')
}
if ((num1 === 26) && (num2 === 9)) {
    console.log('26 + 9 = 35')
}
if ((num1 === 26) && (num2 === 10)) {
    console.log('26 + 10 = 36')
}
if ((num1 === 26) && (num2 === 11)) {
    console.log('26 + 11 = 37')
}
if ((num1 === 26) && (num2 === 12)) {
    console.log('26 + 12 = 38')
}
if ((num1 === 26) && (num2 === 13)) {
    console.log('26 + 13 = 39')
}
if ((num1 === 26) && (num2 === 14)) {
    console.log('26 + 14 = 40')
}
if ((num1 === 26) && (num2 === 15)) {
    console.log('26 + 15 = 41')
}
if ((num1 === 26) && (num2 === 16)) {
    console.log('26 + 16 = 42')
}
if ((num1 === 26) && (num2 === 17)) {
    console.log('26 + 17 = 43')
}
if ((num1 === 26) && (num2 === 18)) {
    console.log('26 + 18 = 44')
}
if ((num1 === 26) && (num2 === 19)) {
    console.log('26 + 19 = 45')
}
if ((num1 === 26) && (num2 === 20)) {
    console.log('26 + 20 = 46')
}
if ((num1 === 26) && (num2 === 21)) {
    console.log('26 + 21 = 47')
}
if ((num1 === 26) && (num2 === 22)) {
    console.log('26 + 22 = 48')
}
if ((num1 === 26) && (num2 === 23)) {
    console.log('26 + 23 = 49')
}
if ((num1 === 26) && (num2 === 24)) {
    console.log('26 + 24 = 50')
}
if ((num1 === 26) && (num2 === 25)) {
    console.log('26 + 25 = 51')
}
if ((num1 === 26) && (num2 === 26)) {
    console.log('26 + 26 = 52')
}
if ((num1 === 26) && (num2 === 27)) {
    console.log('26 + 27 = 53')
}
if ((num1 === 26) && (num2 === 28)) {
    console.log('26 + 28 = 54')
}
if ((num1 === 26) && (num2 === 29)) {
    console.log('26 + 29 = 55')
}
if ((num1 === 26) && (num2 === 30)) {
    console.log('26 + 30 = 56')
}
if ((num1 === 26) && (num2 === 31)) {
    console.log('26 + 31 = 57')
}
if ((num1 === 26) && (num2 === 32)) {
    console.log('26 + 32 = 58')
}
if ((num1 === 26) && (num2 === 33)) {
    console.log('26 + 33 = 59')
}
if ((num1 === 26) && (num2 === 34)) {
    console.log('26 + 34 = 60')
}
if ((num1 === 26) && (num2 === 35)) {
    console.log('26 + 35 = 61')
}
if ((num1 === 26) && (num2 === 36)) {
    console.log('26 + 36 = 62')
}
if ((num1 === 26) && (num2 === 37)) {
    console.log('26 + 37 = 63')
}
if ((num1 === 26) && (num2 === 38)) {
    console.log('26 + 38 = 64')
}
if ((num1 === 26) && (num2 === 39)) {
    console.log('26 + 39 = 65')
}
if ((num1 === 26) && (num2 === 40)) {
    console.log('26 + 40 = 66')
}
if ((num1 === 26) && (num2 === 41)) {
    console.log('26 + 41 = 67')
}
if ((num1 === 26) && (num2 === 42)) {
    console.log('26 + 42 = 68')
}
if ((num1 === 26) && (num2 === 43)) {
    console.log('26 + 43 = 69')
}
if ((num1 === 26) && (num2 === 44)) {
    console.log('26 + 44 = 70')
}
if ((num1 === 26) && (num2 === 45)) {
    console.log('26 + 45 = 71')
}
if ((num1 === 26) && (num2 === 46)) {
    console.log('26 + 46 = 72')
}
if ((num1 === 26) && (num2 === 47)) {
    console.log('26 + 47 = 73')
}
if ((num1 === 26) && (num2 === 48)) {
    console.log('26 + 48 = 74')
}
if ((num1 === 26) && (num2 === 49)) {
    console.log('26 + 49 = 75')
}
if ((num1 === 26) && (num2 === 50)) {
    console.log('26 + 50 = 76')
}
if ((num1 === 27) && (num2 === 0)) {
    console.log('27 + 0 = 27')
}
if ((num1 === 27) && (num2 === 1)) {
    console.log('27 + 1 = 28')
}
if ((num1 === 27) && (num2 === 2)) {
    console.log('27 + 2 = 29')
}
if ((num1 === 27) && (num2 === 3)) {
    console.log('27 + 3 = 30')
}
if ((num1 === 27) && (num2 === 4)) {
    console.log('27 + 4 = 31')
}
if ((num1 === 27) && (num2 === 5)) {
    console.log('27 + 5 = 32')
}
if ((num1 === 27) && (num2 === 6)) {
    console.log('27 + 6 = 33')
}
if ((num1 === 27) && (num2 === 7)) {
    console.log('27 + 7 = 34')
}
if ((num1 === 27) && (num2 === 8)) {
    console.log('27 + 8 = 35')
}
if ((num1 === 27) && (num2 === 9)) {
    console.log('27 + 9 = 36')
}
if ((num1 === 27) && (num2 === 10)) {
    console.log('27 + 10 = 37')
}
if ((num1 === 27) && (num2 === 11)) {
    console.log('27 + 11 = 38')
}
if ((num1 === 27) && (num2 === 12)) {
    console.log('27 + 12 = 39')
}
if ((num1 === 27) && (num2 === 13)) {
    console.log('27 + 13 = 40')
}
if ((num1 === 27) && (num2 === 14)) {
    console.log('27 + 14 = 41')
}
if ((num1 === 27) && (num2 === 15)) {
    console.log('27 + 15 = 42')
}
if ((num1 === 27) && (num2 === 16)) {
    console.log('27 + 16 = 43')
}
if ((num1 === 27) && (num2 === 17)) {
    console.log('27 + 17 = 44')
}
if ((num1 === 27) && (num2 === 18)) {
    console.log('27 + 18 = 45')
}
if ((num1 === 27) && (num2 === 19)) {
    console.log('27 + 19 = 46')
}
if ((num1 === 27) && (num2 === 20)) {
    console.log('27 + 20 = 47')
}
if ((num1 === 27) && (num2 === 21)) {
    console.log('27 + 21 = 48')
}
if ((num1 === 27) && (num2 === 22)) {
    console.log('27 + 22 = 49')
}
if ((num1 === 27) && (num2 === 23)) {
    console.log('27 + 23 = 50')
}
if ((num1 === 27) && (num2 === 24)) {
    console.log('27 + 24 = 51')
}
if ((num1 === 27) && (num2 === 25)) {
    console.log('27 + 25 = 52')
}
if ((num1 === 27) && (num2 === 26)) {
    console.log('27 + 26 = 53')
}
if ((num1 === 27) && (num2 === 27)) {
    console.log('27 + 27 = 54')
}
if ((num1 === 27) && (num2 === 28)) {
    console.log('27 + 28 = 55')
}
if ((num1 === 27) && (num2 === 29)) {
    console.log('27 + 29 = 56')
}
if ((num1 === 27) && (num2 === 30)) {
    console.log('27 + 30 = 57')
}
if ((num1 === 27) && (num2 === 31)) {
    console.log('27 + 31 = 58')
}
if ((num1 === 27) && (num2 === 32)) {
    console.log('27 + 32 = 59')
}
if ((num1 === 27) && (num2 === 33)) {
    console.log('27 + 33 = 60')
}
if ((num1 === 27) && (num2 === 34)) {
    console.log('27 + 34 = 61')
}
if ((num1 === 27) && (num2 === 35)) {
    console.log('27 + 35 = 62')
}
if ((num1 === 27) && (num2 === 36)) {
    console.log('27 + 36 = 63')
}
if ((num1 === 27) && (num2 === 37)) {
    console.log('27 + 37 = 64')
}
if ((num1 === 27) && (num2 === 38)) {
    console.log('27 + 38 = 65')
}
if ((num1 === 27) && (num2 === 39)) {
    console.log('27 + 39 = 66')
}
if ((num1 === 27) && (num2 === 40)) {
    console.log('27 + 40 = 67')
}
if ((num1 === 27) && (num2 === 41)) {
    console.log('27 + 41 = 68')
}
if ((num1 === 27) && (num2 === 42)) {
    console.log('27 + 42 = 69')
}
if ((num1 === 27) && (num2 === 43)) {
    console.log('27 + 43 = 70')
}
if ((num1 === 27) && (num2 === 44)) {
    console.log('27 + 44 = 71')
}
if ((num1 === 27) && (num2 === 45)) {
    console.log('27 + 45 = 72')
}
if ((num1 === 27) && (num2 === 46)) {
    console.log('27 + 46 = 73')
}
if ((num1 === 27) && (num2 === 47)) {
    console.log('27 + 47 = 74')
}
if ((num1 === 27) && (num2 === 48)) {
    console.log('27 + 48 = 75')
}
if ((num1 === 27) && (num2 === 49)) {
    console.log('27 + 49 = 76')
}
if ((num1 === 27) && (num2 === 50)) {
    console.log('27 + 50 = 77')
}
if ((num1 === 28) && (num2 === 0)) {
    console.log('28 + 0 = 28')
}
if ((num1 === 28) && (num2 === 1)) {
    console.log('28 + 1 = 29')
}
if ((num1 === 28) && (num2 === 2)) {
    console.log('28 + 2 = 30')
}
if ((num1 === 28) && (num2 === 3)) {
    console.log('28 + 3 = 31')
}
if ((num1 === 28) && (num2 === 4)) {
    console.log('28 + 4 = 32')
}
if ((num1 === 28) && (num2 === 5)) {
    console.log('28 + 5 = 33')
}
if ((num1 === 28) && (num2 === 6)) {
    console.log('28 + 6 = 34')
}
if ((num1 === 28) && (num2 === 7)) {
    console.log('28 + 7 = 35')
}
if ((num1 === 28) && (num2 === 8)) {
    console.log('28 + 8 = 36')
}
if ((num1 === 28) && (num2 === 9)) {
    console.log('28 + 9 = 37')
}
if ((num1 === 28) && (num2 === 10)) {
    console.log('28 + 10 = 38')
}
if ((num1 === 28) && (num2 === 11)) {
    console.log('28 + 11 = 39')
}
if ((num1 === 28) && (num2 === 12)) {
    console.log('28 + 12 = 40')
}
if ((num1 === 28) && (num2 === 13)) {
    console.log('28 + 13 = 41')
}
if ((num1 === 28) && (num2 === 14)) {
    console.log('28 + 14 = 42')
}
if ((num1 === 28) && (num2 === 15)) {
    console.log('28 + 15 = 43')
}
if ((num1 === 28) && (num2 === 16)) {
    console.log('28 + 16 = 44')
}
if ((num1 === 28) && (num2 === 17)) {
    console.log('28 + 17 = 45')
}
if ((num1 === 28) && (num2 === 18)) {
    console.log('28 + 18 = 46')
}
if ((num1 === 28) && (num2 === 19)) {
    console.log('28 + 19 = 47')
}
if ((num1 === 28) && (num2 === 20)) {
    console.log('28 + 20 = 48')
}
if ((num1 === 28) && (num2 === 21)) {
    console.log('28 + 21 = 49')
}
if ((num1 === 28) && (num2 === 22)) {
    console.log('28 + 22 = 50')
}
if ((num1 === 28) && (num2 === 23)) {
    console.log('28 + 23 = 51')
}
if ((num1 === 28) && (num2 === 24)) {
    console.log('28 + 24 = 52')
}
if ((num1 === 28) && (num2 === 25)) {
    console.log('28 + 25 = 53')
}
if ((num1 === 28) && (num2 === 26)) {
    console.log('28 + 26 = 54')
}
if ((num1 === 28) && (num2 === 27)) {
    console.log('28 + 27 = 55')
}
if ((num1 === 28) && (num2 === 28)) {
    console.log('28 + 28 = 56')
}
if ((num1 === 28) && (num2 === 29)) {
    console.log('28 + 29 = 57')
}
if ((num1 === 28) && (num2 === 30)) {
    console.log('28 + 30 = 58')
}
if ((num1 === 28) && (num2 === 31)) {
    console.log('28 + 31 = 59')
}
if ((num1 === 28) && (num2 === 32)) {
    console.log('28 + 32 = 60')
}
if ((num1 === 28) && (num2 === 33)) {
    console.log('28 + 33 = 61')
}
if ((num1 === 28) && (num2 === 34)) {
    console.log('28 + 34 = 62')
}
if ((num1 === 28) && (num2 === 35)) {
    console.log('28 + 35 = 63')
}
if ((num1 === 28) && (num2 === 36)) {
    console.log('28 + 36 = 64')
}
if ((num1 === 28) && (num2 === 37)) {
    console.log('28 + 37 = 65')
}
if ((num1 === 28) && (num2 === 38)) {
    console.log('28 + 38 = 66')
}
if ((num1 === 28) && (num2 === 39)) {
    console.log('28 + 39 = 67')
}
if ((num1 === 28) && (num2 === 40)) {
    console.log('28 + 40 = 68')
}
if ((num1 === 28) && (num2 === 41)) {
    console.log('28 + 41 = 69')
}
if ((num1 === 28) && (num2 === 42)) {
    console.log('28 + 42 = 70')
}
if ((num1 === 28) && (num2 === 43)) {
    console.log('28 + 43 = 71')
}
if ((num1 === 28) && (num2 === 44)) {
    console.log('28 + 44 = 72')
}
if ((num1 === 28) && (num2 === 45)) {
    console.log('28 + 45 = 73')
}
if ((num1 === 28) && (num2 === 46)) {
    console.log('28 + 46 = 74')
}
if ((num1 === 28) && (num2 === 47)) {
    console.log('28 + 47 = 75')
}
if ((num1 === 28) && (num2 === 48)) {
    console.log('28 + 48 = 76')
}
if ((num1 === 28) && (num2 === 49)) {
    console.log('28 + 49 = 77')
}
if ((num1 === 28) && (num2 === 50)) {
    console.log('28 + 50 = 78')
}
if ((num1 === 29) && (num2 === 0)) {
    console.log('29 + 0 = 29')
}
if ((num1 === 29) && (num2 === 1)) {
    console.log('29 + 1 = 30')
}
if ((num1 === 29) && (num2 === 2)) {
    console.log('29 + 2 = 31')
}
if ((num1 === 29) && (num2 === 3)) {
    console.log('29 + 3 = 32')
}
if ((num1 === 29) && (num2 === 4)) {
    console.log('29 + 4 = 33')
}
if ((num1 === 29) && (num2 === 5)) {
    console.log('29 + 5 = 34')
}
if ((num1 === 29) && (num2 === 6)) {
    console.log('29 + 6 = 35')
}
if ((num1 === 29) && (num2 === 7)) {
    console.log('29 + 7 = 36')
}
if ((num1 === 29) && (num2 === 8)) {
    console.log('29 + 8 = 37')
}
if ((num1 === 29) && (num2 === 9)) {
    console.log('29 + 9 = 38')
}
if ((num1 === 29) && (num2 === 10)) {
    console.log('29 + 10 = 39')
}
if ((num1 === 29) && (num2 === 11)) {
    console.log('29 + 11 = 40')
}
if ((num1 === 29) && (num2 === 12)) {
    console.log('29 + 12 = 41')
}
if ((num1 === 29) && (num2 === 13)) {
    console.log('29 + 13 = 42')
}
if ((num1 === 29) && (num2 === 14)) {
    console.log('29 + 14 = 43')
}
if ((num1 === 29) && (num2 === 15)) {
    console.log('29 + 15 = 44')
}
if ((num1 === 29) && (num2 === 16)) {
    console.log('29 + 16 = 45')
}
if ((num1 === 29) && (num2 === 17)) {
    console.log('29 + 17 = 46')
}
if ((num1 === 29) && (num2 === 18)) {
    console.log('29 + 18 = 47')
}
if ((num1 === 29) && (num2 === 19)) {
    console.log('29 + 19 = 48')
}
if ((num1 === 29) && (num2 === 20)) {
    console.log('29 + 20 = 49')
}
if ((num1 === 29) && (num2 === 21)) {
    console.log('29 + 21 = 50')
}
if ((num1 === 29) && (num2 === 22)) {
    console.log('29 + 22 = 51')
}
if ((num1 === 29) && (num2 === 23)) {
    console.log('29 + 23 = 52')
}
if ((num1 === 29) && (num2 === 24)) {
    console.log('29 + 24 = 53')
}
if ((num1 === 29) && (num2 === 25)) {
    console.log('29 + 25 = 54')
}
if ((num1 === 29) && (num2 === 26)) {
    console.log('29 + 26 = 55')
}
if ((num1 === 29) && (num2 === 27)) {
    console.log('29 + 27 = 56')
}
if ((num1 === 29) && (num2 === 28)) {
    console.log('29 + 28 = 57')
}
if ((num1 === 29) && (num2 === 29)) {
    console.log('29 + 29 = 58')
}
if ((num1 === 29) && (num2 === 30)) {
    console.log('29 + 30 = 59')
}
if ((num1 === 29) && (num2 === 31)) {
    console.log('29 + 31 = 60')
}
if ((num1 === 29) && (num2 === 32)) {
    console.log('29 + 32 = 61')
}
if ((num1 === 29) && (num2 === 33)) {
    console.log('29 + 33 = 62')
}
if ((num1 === 29) && (num2 === 34)) {
    console.log('29 + 34 = 63')
}
if ((num1 === 29) && (num2 === 35)) {
    console.log('29 + 35 = 64')
}
if ((num1 === 29) && (num2 === 36)) {
    console.log('29 + 36 = 65')
}
if ((num1 === 29) && (num2 === 37)) {
    console.log('29 + 37 = 66')
}
if ((num1 === 29) && (num2 === 38)) {
    console.log('29 + 38 = 67')
}
if ((num1 === 29) && (num2 === 39)) {
    console.log('29 + 39 = 68')
}
if ((num1 === 29) && (num2 === 40)) {
    console.log('29 + 40 = 69')
}
if ((num1 === 29) && (num2 === 41)) {
    console.log('29 + 41 = 70')
}
if ((num1 === 29) && (num2 === 42)) {
    console.log('29 + 42 = 71')
}
if ((num1 === 29) && (num2 === 43)) {
    console.log('29 + 43 = 72')
}
if ((num1 === 29) && (num2 === 44)) {
    console.log('29 + 44 = 73')
}
if ((num1 === 29) && (num2 === 45)) {
    console.log('29 + 45 = 74')
}
if ((num1 === 29) && (num2 === 46)) {
    console.log('29 + 46 = 75')
}
if ((num1 === 29) && (num2 === 47)) {
    console.log('29 + 47 = 76')
}
if ((num1 === 29) && (num2 === 48)) {
    console.log('29 + 48 = 77')
}
if ((num1 === 29) && (num2 === 49)) {
    console.log('29 + 49 = 78')
}
if ((num1 === 29) && (num2 === 50)) {
    console.log('29 + 50 = 79')
}
if ((num1 === 30) && (num2 === 0)) {
    console.log('30 + 0 = 30')
}
if ((num1 === 30) && (num2 === 1)) {
    console.log('30 + 1 = 31')
}
if ((num1 === 30) && (num2 === 2)) {
    console.log('30 + 2 = 32')
}
if ((num1 === 30) && (num2 === 3)) {
    console.log('30 + 3 = 33')
}
if ((num1 === 30) && (num2 === 4)) {
    console.log('30 + 4 = 34')
}
if ((num1 === 30) && (num2 === 5)) {
    console.log('30 + 5 = 35')
}
if ((num1 === 30) && (num2 === 6)) {
    console.log('30 + 6 = 36')
}
if ((num1 === 30) && (num2 === 7)) {
    console.log('30 + 7 = 37')
}
if ((num1 === 30) && (num2 === 8)) {
    console.log('30 + 8 = 38')
}
if ((num1 === 30) && (num2 === 9)) {
    console.log('30 + 9 = 39')
}
if ((num1 === 30) && (num2 === 10)) {
    console.log('30 + 10 = 40')
}
if ((num1 === 30) && (num2 === 11)) {
    console.log('30 + 11 = 41')
}
if ((num1 === 30) && (num2 === 12)) {
    console.log('30 + 12 = 42')
}
if ((num1 === 30) && (num2 === 13)) {
    console.log('30 + 13 = 43')
}
if ((num1 === 30) && (num2 === 14)) {
    console.log('30 + 14 = 44')
}
if ((num1 === 30) && (num2 === 15)) {
    console.log('30 + 15 = 45')
}
if ((num1 === 30) && (num2 === 16)) {
    console.log('30 + 16 = 46')
}
if ((num1 === 30) && (num2 === 17)) {
    console.log('30 + 17 = 47')
}
if ((num1 === 30) && (num2 === 18)) {
    console.log('30 + 18 = 48')
}
if ((num1 === 30) && (num2 === 19)) {
    console.log('30 + 19 = 49')
}
if ((num1 === 30) && (num2 === 20)) {
    console.log('30 + 20 = 50')
}
if ((num1 === 30) && (num2 === 21)) {
    console.log('30 + 21 = 51')
}
if ((num1 === 30) && (num2 === 22)) {
    console.log('30 + 22 = 52')
}
if ((num1 === 30) && (num2 === 23)) {
    console.log('30 + 23 = 53')
}
if ((num1 === 30) && (num2 === 24)) {
    console.log('30 + 24 = 54')
}
if ((num1 === 30) && (num2 === 25)) {
    console.log('30 + 25 = 55')
}
if ((num1 === 30) && (num2 === 26)) {
    console.log('30 + 26 = 56')
}
if ((num1 === 30) && (num2 === 27)) {
    console.log('30 + 27 = 57')
}
if ((num1 === 30) && (num2 === 28)) {
    console.log('30 + 28 = 58')
}
if ((num1 === 30) && (num2 === 29)) {
    console.log('30 + 29 = 59')
}
if ((num1 === 30) && (num2 === 30)) {
    console.log('30 + 30 = 60')
}
if ((num1 === 30) && (num2 === 31)) {
    console.log('30 + 31 = 61')
}
if ((num1 === 30) && (num2 === 32)) {
    console.log('30 + 32 = 62')
}
if ((num1 === 30) && (num2 === 33)) {
    console.log('30 + 33 = 63')
}
if ((num1 === 30) && (num2 === 34)) {
    console.log('30 + 34 = 64')
}
if ((num1 === 30) && (num2 === 35)) {
    console.log('30 + 35 = 65')
}
if ((num1 === 30) && (num2 === 36)) {
    console.log('30 + 36 = 66')
}
if ((num1 === 30) && (num2 === 37)) {
    console.log('30 + 37 = 67')
}
if ((num1 === 30) && (num2 === 38)) {
    console.log('30 + 38 = 68')
}
if ((num1 === 30) && (num2 === 39)) {
    console.log('30 + 39 = 69')
}
if ((num1 === 30) && (num2 === 40)) {
    console.log('30 + 40 = 70')
}
if ((num1 === 30) && (num2 === 41)) {
    console.log('30 + 41 = 71')
}
if ((num1 === 30) && (num2 === 42)) {
    console.log('30 + 42 = 72')
}
if ((num1 === 30) && (num2 === 43)) {
    console.log('30 + 43 = 73')
}
if ((num1 === 30) && (num2 === 44)) {
    console.log('30 + 44 = 74')
}
if ((num1 === 30) && (num2 === 45)) {
    console.log('30 + 45 = 75')
}
if ((num1 === 30) && (num2 === 46)) {
    console.log('30 + 46 = 76')
}
if ((num1 === 30) && (num2 === 47)) {
    console.log('30 + 47 = 77')
}
if ((num1 === 30) && (num2 === 48)) {
    console.log('30 + 48 = 78')
}
if ((num1 === 30) && (num2 === 49)) {
    console.log('30 + 49 = 79')
}
if ((num1 === 30) && (num2 === 50)) {
    console.log('30 + 50 = 80')
}
if ((num1 === 31) && (num2 === 0)) {
    console.log('31 + 0 = 31')
}
if ((num1 === 31) && (num2 === 1)) {
    console.log('31 + 1 = 32')
}
if ((num1 === 31) && (num2 === 2)) {
    console.log('31 + 2 = 33')
}
if ((num1 === 31) && (num2 === 3)) {
    console.log('31 + 3 = 34')
}
if ((num1 === 31) && (num2 === 4)) {
    console.log('31 + 4 = 35')
}
if ((num1 === 31) && (num2 === 5)) {
    console.log('31 + 5 = 36')
}
if ((num1 === 31) && (num2 === 6)) {
    console.log('31 + 6 = 37')
}
if ((num1 === 31) && (num2 === 7)) {
    console.log('31 + 7 = 38')
}
if ((num1 === 31) && (num2 === 8)) {
    console.log('31 + 8 = 39')
}
if ((num1 === 31) && (num2 === 9)) {
    console.log('31 + 9 = 40')
}
if ((num1 === 31) && (num2 === 10)) {
    console.log('31 + 10 = 41')
}
if ((num1 === 31) && (num2 === 11)) {
    console.log('31 + 11 = 42')
}
if ((num1 === 31) && (num2 === 12)) {
    console.log('31 + 12 = 43')
}
if ((num1 === 31) && (num2 === 13)) {
    console.log('31 + 13 = 44')
}
if ((num1 === 31) && (num2 === 14)) {
    console.log('31 + 14 = 45')
}
if ((num1 === 31) && (num2 === 15)) {
    console.log('31 + 15 = 46')
}
if ((num1 === 31) && (num2 === 16)) {
    console.log('31 + 16 = 47')
}
if ((num1 === 31) && (num2 === 17)) {
    console.log('31 + 17 = 48')
}
if ((num1 === 31) && (num2 === 18)) {
    console.log('31 + 18 = 49')
}
if ((num1 === 31) && (num2 === 19)) {
    console.log('31 + 19 = 50')
}
if ((num1 === 31) && (num2 === 20)) {
    console.log('31 + 20 = 51')
}
if ((num1 === 31) && (num2 === 21)) {
    console.log('31 + 21 = 52')
}
if ((num1 === 31) && (num2 === 22)) {
    console.log('31 + 22 = 53')
}
if ((num1 === 31) && (num2 === 23)) {
    console.log('31 + 23 = 54')
}
if ((num1 === 31) && (num2 === 24)) {
    console.log('31 + 24 = 55')
}
if ((num1 === 31) && (num2 === 25)) {
    console.log('31 + 25 = 56')
}
if ((num1 === 31) && (num2 === 26)) {
    console.log('31 + 26 = 57')
}
if ((num1 === 31) && (num2 === 27)) {
    console.log('31 + 27 = 58')
}
if ((num1 === 31) && (num2 === 28)) {
    console.log('31 + 28 = 59')
}
if ((num1 === 31) && (num2 === 29)) {
    console.log('31 + 29 = 60')
}
if ((num1 === 31) && (num2 === 30)) {
    console.log('31 + 30 = 61')
}
if ((num1 === 31) && (num2 === 31)) {
    console.log('31 + 31 = 62')
}
if ((num1 === 31) && (num2 === 32)) {
    console.log('31 + 32 = 63')
}
if ((num1 === 31) && (num2 === 33)) {
    console.log('31 + 33 = 64')
}
if ((num1 === 31) && (num2 === 34)) {
    console.log('31 + 34 = 65')
}
if ((num1 === 31) && (num2 === 35)) {
    console.log('31 + 35 = 66')
}
if ((num1 === 31) && (num2 === 36)) {
    console.log('31 + 36 = 67')
}
if ((num1 === 31) && (num2 === 37)) {
    console.log('31 + 37 = 68')
}
if ((num1 === 31) && (num2 === 38)) {
    console.log('31 + 38 = 69')
}
if ((num1 === 31) && (num2 === 39)) {
    console.log('31 + 39 = 70')
}
if ((num1 === 31) && (num2 === 40)) {
    console.log('31 + 40 = 71')
}
if ((num1 === 31) && (num2 === 41)) {
    console.log('31 + 41 = 72')
}
if ((num1 === 31) && (num2 === 42)) {
    console.log('31 + 42 = 73')
}
if ((num1 === 31) && (num2 === 43)) {
    console.log('31 + 43 = 74')
}
if ((num1 === 31) && (num2 === 44)) {
    console.log('31 + 44 = 75')
}
if ((num1 === 31) && (num2 === 45)) {
    console.log('31 + 45 = 76')
}
if ((num1 === 31) && (num2 === 46)) {
    console.log('31 + 46 = 77')
}
if ((num1 === 31) && (num2 === 47)) {
    console.log('31 + 47 = 78')
}
if ((num1 === 31) && (num2 === 48)) {
    console.log('31 + 48 = 79')
}
if ((num1 === 31) && (num2 === 49)) {
    console.log('31 + 49 = 80')
}
if ((num1 === 31) && (num2 === 50)) {
    console.log('31 + 50 = 81')
}
if ((num1 === 32) && (num2 === 0)) {
    console.log('32 + 0 = 32')
}
if ((num1 === 32) && (num2 === 1)) {
    console.log('32 + 1 = 33')
}
if ((num1 === 32) && (num2 === 2)) {
    console.log('32 + 2 = 34')
}
if ((num1 === 32) && (num2 === 3)) {
    console.log('32 + 3 = 35')
}
if ((num1 === 32) && (num2 === 4)) {
    console.log('32 + 4 = 36')
}
if ((num1 === 32) && (num2 === 5)) {
    console.log('32 + 5 = 37')
}
if ((num1 === 32) && (num2 === 6)) {
    console.log('32 + 6 = 38')
}
if ((num1 === 32) && (num2 === 7)) {
    console.log('32 + 7 = 39')
}
if ((num1 === 32) && (num2 === 8)) {
    console.log('32 + 8 = 40')
}
if ((num1 === 32) && (num2 === 9)) {
    console.log('32 + 9 = 41')
}
if ((num1 === 32) && (num2 === 10)) {
    console.log('32 + 10 = 42')
}
if ((num1 === 32) && (num2 === 11)) {
    console.log('32 + 11 = 43')
}
if ((num1 === 32) && (num2 === 12)) {
    console.log('32 + 12 = 44')
}
if ((num1 === 32) && (num2 === 13)) {
    console.log('32 + 13 = 45')
}
if ((num1 === 32) && (num2 === 14)) {
    console.log('32 + 14 = 46')
}
if ((num1 === 32) && (num2 === 15)) {
    console.log('32 + 15 = 47')
}
if ((num1 === 32) && (num2 === 16)) {
    console.log('32 + 16 = 48')
}
if ((num1 === 32) && (num2 === 17)) {
    console.log('32 + 17 = 49')
}
if ((num1 === 32) && (num2 === 18)) {
    console.log('32 + 18 = 50')
}
if ((num1 === 32) && (num2 === 19)) {
    console.log('32 + 19 = 51')
}
if ((num1 === 32) && (num2 === 20)) {
    console.log('32 + 20 = 52')
}
if ((num1 === 32) && (num2 === 21)) {
    console.log('32 + 21 = 53')
}
if ((num1 === 32) && (num2 === 22)) {
    console.log('32 + 22 = 54')
}
if ((num1 === 32) && (num2 === 23)) {
    console.log('32 + 23 = 55')
}
if ((num1 === 32) && (num2 === 24)) {
    console.log('32 + 24 = 56')
}
if ((num1 === 32) && (num2 === 25)) {
    console.log('32 + 25 = 57')
}
if ((num1 === 32) && (num2 === 26)) {
    console.log('32 + 26 = 58')
}
if ((num1 === 32) && (num2 === 27)) {
    console.log('32 + 27 = 59')
}
if ((num1 === 32) && (num2 === 28)) {
    console.log('32 + 28 = 60')
}
if ((num1 === 32) && (num2 === 29)) {
    console.log('32 + 29 = 61')
}
if ((num1 === 32) && (num2 === 30)) {
    console.log('32 + 30 = 62')
}
if ((num1 === 32) && (num2 === 31)) {
    console.log('32 + 31 = 63')
}
if ((num1 === 32) && (num2 === 32)) {
    console.log('32 + 32 = 64')
}
if ((num1 === 32) && (num2 === 33)) {
    console.log('32 + 33 = 65')
}
if ((num1 === 32) && (num2 === 34)) {
    console.log('32 + 34 = 66')
}
if ((num1 === 32) && (num2 === 35)) {
    console.log('32 + 35 = 67')
}
if ((num1 === 32) && (num2 === 36)) {
    console.log('32 + 36 = 68')
}
if ((num1 === 32) && (num2 === 37)) {
    console.log('32 + 37 = 69')
}
if ((num1 === 32) && (num2 === 38)) {
    console.log('32 + 38 = 70')
}
if ((num1 === 32) && (num2 === 39)) {
    console.log('32 + 39 = 71')
}
if ((num1 === 32) && (num2 === 40)) {
    console.log('32 + 40 = 72')
}
if ((num1 === 32) && (num2 === 41)) {
    console.log('32 + 41 = 73')
}
if ((num1 === 32) && (num2 === 42)) {
    console.log('32 + 42 = 74')
}
if ((num1 === 32) && (num2 === 43)) {
    console.log('32 + 43 = 75')
}
if ((num1 === 32) && (num2 === 44)) {
    console.log('32 + 44 = 76')
}
if ((num1 === 32) && (num2 === 45)) {
    console.log('32 + 45 = 77')
}
if ((num1 === 32) && (num2 === 46)) {
    console.log('32 + 46 = 78')
}
if ((num1 === 32) && (num2 === 47)) {
    console.log('32 + 47 = 79')
}
if ((num1 === 32) && (num2 === 48)) {
    console.log('32 + 48 = 80')
}
if ((num1 === 32) && (num2 === 49)) {
    console.log('32 + 49 = 81')
}
if ((num1 === 32) && (num2 === 50)) {
    console.log('32 + 50 = 82')
}
if ((num1 === 33) && (num2 === 0)) {
    console.log('33 + 0 = 33')
}
if ((num1 === 33) && (num2 === 1)) {
    console.log('33 + 1 = 34')
}
if ((num1 === 33) && (num2 === 2)) {
    console.log('33 + 2 = 35')
}
if ((num1 === 33) && (num2 === 3)) {
    console.log('33 + 3 = 36')
}
if ((num1 === 33) && (num2 === 4)) {
    console.log('33 + 4 = 37')
}
if ((num1 === 33) && (num2 === 5)) {
    console.log('33 + 5 = 38')
}
if ((num1 === 33) && (num2 === 6)) {
    console.log('33 + 6 = 39')
}
if ((num1 === 33) && (num2 === 7)) {
    console.log('33 + 7 = 40')
}
if ((num1 === 33) && (num2 === 8)) {
    console.log('33 + 8 = 41')
}
if ((num1 === 33) && (num2 === 9)) {
    console.log('33 + 9 = 42')
}
if ((num1 === 33) && (num2 === 10)) {
    console.log('33 + 10 = 43')
}
if ((num1 === 33) && (num2 === 11)) {
    console.log('33 + 11 = 44')
}
if ((num1 === 33) && (num2 === 12)) {
    console.log('33 + 12 = 45')
}
if ((num1 === 33) && (num2 === 13)) {
    console.log('33 + 13 = 46')
}
if ((num1 === 33) && (num2 === 14)) {
    console.log('33 + 14 = 47')
}
if ((num1 === 33) && (num2 === 15)) {
    console.log('33 + 15 = 48')
}
if ((num1 === 33) && (num2 === 16)) {
    console.log('33 + 16 = 49')
}
if ((num1 === 33) && (num2 === 17)) {
    console.log('33 + 17 = 50')
}
if ((num1 === 33) && (num2 === 18)) {
    console.log('33 + 18 = 51')
}
if ((num1 === 33) && (num2 === 19)) {
    console.log('33 + 19 = 52')
}
if ((num1 === 33) && (num2 === 20)) {
    console.log('33 + 20 = 53')
}
if ((num1 === 33) && (num2 === 21)) {
    console.log('33 + 21 = 54')
}
if ((num1 === 33) && (num2 === 22)) {
    console.log('33 + 22 = 55')
}
if ((num1 === 33) && (num2 === 23)) {
    console.log('33 + 23 = 56')
}
if ((num1 === 33) && (num2 === 24)) {
    console.log('33 + 24 = 57')
}
if ((num1 === 33) && (num2 === 25)) {
    console.log('33 + 25 = 58')
}
if ((num1 === 33) && (num2 === 26)) {
    console.log('33 + 26 = 59')
}
if ((num1 === 33) && (num2 === 27)) {
    console.log('33 + 27 = 60')
}
if ((num1 === 33) && (num2 === 28)) {
    console.log('33 + 28 = 61')
}
if ((num1 === 33) && (num2 === 29)) {
    console.log('33 + 29 = 62')
}
if ((num1 === 33) && (num2 === 30)) {
    console.log('33 + 30 = 63')
}
if ((num1 === 33) && (num2 === 31)) {
    console.log('33 + 31 = 64')
}
if ((num1 === 33) && (num2 === 32)) {
    console.log('33 + 32 = 65')
}
if ((num1 === 33) && (num2 === 33)) {
    console.log('33 + 33 = 66')
}
if ((num1 === 33) && (num2 === 34)) {
    console.log('33 + 34 = 67')
}
if ((num1 === 33) && (num2 === 35)) {
    console.log('33 + 35 = 68')
}
if ((num1 === 33) && (num2 === 36)) {
    console.log('33 + 36 = 69')
}
if ((num1 === 33) && (num2 === 37)) {
    console.log('33 + 37 = 70')
}
if ((num1 === 33) && (num2 === 38)) {
    console.log('33 + 38 = 71')
}
if ((num1 === 33) && (num2 === 39)) {
    console.log('33 + 39 = 72')
}
if ((num1 === 33) && (num2 === 40)) {
    console.log('33 + 40 = 73')
}
if ((num1 === 33) && (num2 === 41)) {
    console.log('33 + 41 = 74')
}
if ((num1 === 33) && (num2 === 42)) {
    console.log('33 + 42 = 75')
}
if ((num1 === 33) && (num2 === 43)) {
    console.log('33 + 43 = 76')
}
if ((num1 === 33) && (num2 === 44)) {
    console.log('33 + 44 = 77')
}
if ((num1 === 33) && (num2 === 45)) {
    console.log('33 + 45 = 78')
}
if ((num1 === 33) && (num2 === 46)) {
    console.log('33 + 46 = 79')
}
if ((num1 === 33) && (num2 === 47)) {
    console.log('33 + 47 = 80')
}
if ((num1 === 33) && (num2 === 48)) {
    console.log('33 + 48 = 81')
}
if ((num1 === 33) && (num2 === 49)) {
    console.log('33 + 49 = 82')
}
if ((num1 === 33) && (num2 === 50)) {
    console.log('33 + 50 = 83')
}
if ((num1 === 34) && (num2 === 0)) {
    console.log('34 + 0 = 34')
}
if ((num1 === 34) && (num2 === 1)) {
    console.log('34 + 1 = 35')
}
if ((num1 === 34) && (num2 === 2)) {
    console.log('34 + 2 = 36')
}
if ((num1 === 34) && (num2 === 3)) {
    console.log('34 + 3 = 37')
}
if ((num1 === 34) && (num2 === 4)) {
    console.log('34 + 4 = 38')
}
if ((num1 === 34) && (num2 === 5)) {
    console.log('34 + 5 = 39')
}
if ((num1 === 34) && (num2 === 6)) {
    console.log('34 + 6 = 40')
}
if ((num1 === 34) && (num2 === 7)) {
    console.log('34 + 7 = 41')
}
if ((num1 === 34) && (num2 === 8)) {
    console.log('34 + 8 = 42')
}
if ((num1 === 34) && (num2 === 9)) {
    console.log('34 + 9 = 43')
}
if ((num1 === 34) && (num2 === 10)) {
    console.log('34 + 10 = 44')
}
if ((num1 === 34) && (num2 === 11)) {
    console.log('34 + 11 = 45')
}
if ((num1 === 34) && (num2 === 12)) {
    console.log('34 + 12 = 46')
}
if ((num1 === 34) && (num2 === 13)) {
    console.log('34 + 13 = 47')
}
if ((num1 === 34) && (num2 === 14)) {
    console.log('34 + 14 = 48')
}
if ((num1 === 34) && (num2 === 15)) {
    console.log('34 + 15 = 49')
}
if ((num1 === 34) && (num2 === 16)) {
    console.log('34 + 16 = 50')
}
if ((num1 === 34) && (num2 === 17)) {
    console.log('34 + 17 = 51')
}
if ((num1 === 34) && (num2 === 18)) {
    console.log('34 + 18 = 52')
}
if ((num1 === 34) && (num2 === 19)) {
    console.log('34 + 19 = 53')
}
if ((num1 === 34) && (num2 === 20)) {
    console.log('34 + 20 = 54')
}
if ((num1 === 34) && (num2 === 21)) {
    console.log('34 + 21 = 55')
}
if ((num1 === 34) && (num2 === 22)) {
    console.log('34 + 22 = 56')
}
if ((num1 === 34) && (num2 === 23)) {
    console.log('34 + 23 = 57')
}
if ((num1 === 34) && (num2 === 24)) {
    console.log('34 + 24 = 58')
}
if ((num1 === 34) && (num2 === 25)) {
    console.log('34 + 25 = 59')
}
if ((num1 === 34) && (num2 === 26)) {
    console.log('34 + 26 = 60')
}
if ((num1 === 34) && (num2 === 27)) {
    console.log('34 + 27 = 61')
}
if ((num1 === 34) && (num2 === 28)) {
    console.log('34 + 28 = 62')
}
if ((num1 === 34) && (num2 === 29)) {
    console.log('34 + 29 = 63')
}
if ((num1 === 34) && (num2 === 30)) {
    console.log('34 + 30 = 64')
}
if ((num1 === 34) && (num2 === 31)) {
    console.log('34 + 31 = 65')
}
if ((num1 === 34) && (num2 === 32)) {
    console.log('34 + 32 = 66')
}
if ((num1 === 34) && (num2 === 33)) {
    console.log('34 + 33 = 67')
}
if ((num1 === 34) && (num2 === 34)) {
    console.log('34 + 34 = 68')
}
if ((num1 === 34) && (num2 === 35)) {
    console.log('34 + 35 = 69')
}
if ((num1 === 34) && (num2 === 36)) {
    console.log('34 + 36 = 70')
}
if ((num1 === 34) && (num2 === 37)) {
    console.log('34 + 37 = 71')
}
if ((num1 === 34) && (num2 === 38)) {
    console.log('34 + 38 = 72')
}
if ((num1 === 34) && (num2 === 39)) {
    console.log('34 + 39 = 73')
}
if ((num1 === 34) && (num2 === 40)) {
    console.log('34 + 40 = 74')
}
if ((num1 === 34) && (num2 === 41)) {
    console.log('34 + 41 = 75')
}
if ((num1 === 34) && (num2 === 42)) {
    console.log('34 + 42 = 76')
}
if ((num1 === 34) && (num2 === 43)) {
    console.log('34 + 43 = 77')
}
if ((num1 === 34) && (num2 === 44)) {
    console.log('34 + 44 = 78')
}
if ((num1 === 34) && (num2 === 45)) {
    console.log('34 + 45 = 79')
}
if ((num1 === 34) && (num2 === 46)) {
    console.log('34 + 46 = 80')
}
if ((num1 === 34) && (num2 === 47)) {
    console.log('34 + 47 = 81')
}
if ((num1 === 34) && (num2 === 48)) {
    console.log('34 + 48 = 82')
}
if ((num1 === 34) && (num2 === 49)) {
    console.log('34 + 49 = 83')
}
if ((num1 === 34) && (num2 === 50)) {
    console.log('34 + 50 = 84')
}
if ((num1 === 35) && (num2 === 0)) {
    console.log('35 + 0 = 35')
}
if ((num1 === 35) && (num2 === 1)) {
    console.log('35 + 1 = 36')
}
if ((num1 === 35) && (num2 === 2)) {
    console.log('35 + 2 = 37')
}
if ((num1 === 35) && (num2 === 3)) {
    console.log('35 + 3 = 38')
}
if ((num1 === 35) && (num2 === 4)) {
    console.log('35 + 4 = 39')
}
if ((num1 === 35) && (num2 === 5)) {
    console.log('35 + 5 = 40')
}
if ((num1 === 35) && (num2 === 6)) {
    console.log('35 + 6 = 41')
}
if ((num1 === 35) && (num2 === 7)) {
    console.log('35 + 7 = 42')
}
if ((num1 === 35) && (num2 === 8)) {
    console.log('35 + 8 = 43')
}
if ((num1 === 35) && (num2 === 9)) {
    console.log('35 + 9 = 44')
}
if ((num1 === 35) && (num2 === 10)) {
    console.log('35 + 10 = 45')
}
if ((num1 === 35) && (num2 === 11)) {
    console.log('35 + 11 = 46')
}
if ((num1 === 35) && (num2 === 12)) {
    console.log('35 + 12 = 47')
}
if ((num1 === 35) && (num2 === 13)) {
    console.log('35 + 13 = 48')
}
if ((num1 === 35) && (num2 === 14)) {
    console.log('35 + 14 = 49')
}
if ((num1 === 35) && (num2 === 15)) {
    console.log('35 + 15 = 50')
}
if ((num1 === 35) && (num2 === 16)) {
    console.log('35 + 16 = 51')
}
if ((num1 === 35) && (num2 === 17)) {
    console.log('35 + 17 = 52')
}
if ((num1 === 35) && (num2 === 18)) {
    console.log('35 + 18 = 53')
}
if ((num1 === 35) && (num2 === 19)) {
    console.log('35 + 19 = 54')
}
if ((num1 === 35) && (num2 === 20)) {
    console.log('35 + 20 = 55')
}
if ((num1 === 35) && (num2 === 21)) {
    console.log('35 + 21 = 56')
}
if ((num1 === 35) && (num2 === 22)) {
    console.log('35 + 22 = 57')
}
if ((num1 === 35) && (num2 === 23)) {
    console.log('35 + 23 = 58')
}
if ((num1 === 35) && (num2 === 24)) {
    console.log('35 + 24 = 59')
}
if ((num1 === 35) && (num2 === 25)) {
    console.log('35 + 25 = 60')
}
if ((num1 === 35) && (num2 === 26)) {
    console.log('35 + 26 = 61')
}
if ((num1 === 35) && (num2 === 27)) {
    console.log('35 + 27 = 62')
}
if ((num1 === 35) && (num2 === 28)) {
    console.log('35 + 28 = 63')
}
if ((num1 === 35) && (num2 === 29)) {
    console.log('35 + 29 = 64')
}
if ((num1 === 35) && (num2 === 30)) {
    console.log('35 + 30 = 65')
}
if ((num1 === 35) && (num2 === 31)) {
    console.log('35 + 31 = 66')
}
if ((num1 === 35) && (num2 === 32)) {
    console.log('35 + 32 = 67')
}
if ((num1 === 35) && (num2 === 33)) {
    console.log('35 + 33 = 68')
}
if ((num1 === 35) && (num2 === 34)) {
    console.log('35 + 34 = 69')
}
if ((num1 === 35) && (num2 === 35)) {
    console.log('35 + 35 = 70')
}
if ((num1 === 35) && (num2 === 36)) {
    console.log('35 + 36 = 71')
}
if ((num1 === 35) && (num2 === 37)) {
    console.log('35 + 37 = 72')
}
if ((num1 === 35) && (num2 === 38)) {
    console.log('35 + 38 = 73')
}
if ((num1 === 35) && (num2 === 39)) {
    console.log('35 + 39 = 74')
}
if ((num1 === 35) && (num2 === 40)) {
    console.log('35 + 40 = 75')
}
if ((num1 === 35) && (num2 === 41)) {
    console.log('35 + 41 = 76')
}
if ((num1 === 35) && (num2 === 42)) {
    console.log('35 + 42 = 77')
}
if ((num1 === 35) && (num2 === 43)) {
    console.log('35 + 43 = 78')
}
if ((num1 === 35) && (num2 === 44)) {
    console.log('35 + 44 = 79')
}
if ((num1 === 35) && (num2 === 45)) {
    console.log('35 + 45 = 80')
}
if ((num1 === 35) && (num2 === 46)) {
    console.log('35 + 46 = 81')
}
if ((num1 === 35) && (num2 === 47)) {
    console.log('35 + 47 = 82')
}
if ((num1 === 35) && (num2 === 48)) {
    console.log('35 + 48 = 83')
}
if ((num1 === 35) && (num2 === 49)) {
    console.log('35 + 49 = 84')
}
if ((num1 === 35) && (num2 === 50)) {
    console.log('35 + 50 = 85')
}
if ((num1 === 36) && (num2 === 0)) {
    console.log('36 + 0 = 36')
}
if ((num1 === 36) && (num2 === 1)) {
    console.log('36 + 1 = 37')
}
if ((num1 === 36) && (num2 === 2)) {
    console.log('36 + 2 = 38')
}
if ((num1 === 36) && (num2 === 3)) {
    console.log('36 + 3 = 39')
}
if ((num1 === 36) && (num2 === 4)) {
    console.log('36 + 4 = 40')
}
if ((num1 === 36) && (num2 === 5)) {
    console.log('36 + 5 = 41')
}
if ((num1 === 36) && (num2 === 6)) {
    console.log('36 + 6 = 42')
}
if ((num1 === 36) && (num2 === 7)) {
    console.log('36 + 7 = 43')
}
if ((num1 === 36) && (num2 === 8)) {
    console.log('36 + 8 = 44')
}
if ((num1 === 36) && (num2 === 9)) {
    console.log('36 + 9 = 45')
}
if ((num1 === 36) && (num2 === 10)) {
    console.log('36 + 10 = 46')
}
if ((num1 === 36) && (num2 === 11)) {
    console.log('36 + 11 = 47')
}
if ((num1 === 36) && (num2 === 12)) {
    console.log('36 + 12 = 48')
}
if ((num1 === 36) && (num2 === 13)) {
    console.log('36 + 13 = 49')
}
if ((num1 === 36) && (num2 === 14)) {
    console.log('36 + 14 = 50')
}
if ((num1 === 36) && (num2 === 15)) {
    console.log('36 + 15 = 51')
}
if ((num1 === 36) && (num2 === 16)) {
    console.log('36 + 16 = 52')
}
if ((num1 === 36) && (num2 === 17)) {
    console.log('36 + 17 = 53')
}
if ((num1 === 36) && (num2 === 18)) {
    console.log('36 + 18 = 54')
}
if ((num1 === 36) && (num2 === 19)) {
    console.log('36 + 19 = 55')
}
if ((num1 === 36) && (num2 === 20)) {
    console.log('36 + 20 = 56')
}
if ((num1 === 36) && (num2 === 21)) {
    console.log('36 + 21 = 57')
}
if ((num1 === 36) && (num2 === 22)) {
    console.log('36 + 22 = 58')
}
if ((num1 === 36) && (num2 === 23)) {
    console.log('36 + 23 = 59')
}
if ((num1 === 36) && (num2 === 24)) {
    console.log('36 + 24 = 60')
}
if ((num1 === 36) && (num2 === 25)) {
    console.log('36 + 25 = 61')
}
if ((num1 === 36) && (num2 === 26)) {
    console.log('36 + 26 = 62')
}
if ((num1 === 36) && (num2 === 27)) {
    console.log('36 + 27 = 63')
}
if ((num1 === 36) && (num2 === 28)) {
    console.log('36 + 28 = 64')
}
if ((num1 === 36) && (num2 === 29)) {
    console.log('36 + 29 = 65')
}
if ((num1 === 36) && (num2 === 30)) {
    console.log('36 + 30 = 66')
}
if ((num1 === 36) && (num2 === 31)) {
    console.log('36 + 31 = 67')
}
if ((num1 === 36) && (num2 === 32)) {
    console.log('36 + 32 = 68')
}
if ((num1 === 36) && (num2 === 33)) {
    console.log('36 + 33 = 69')
}
if ((num1 === 36) && (num2 === 34)) {
    console.log('36 + 34 = 70')
}
if ((num1 === 36) && (num2 === 35)) {
    console.log('36 + 35 = 71')
}
if ((num1 === 36) && (num2 === 36)) {
    console.log('36 + 36 = 72')
}
if ((num1 === 36) && (num2 === 37)) {
    console.log('36 + 37 = 73')
}
if ((num1 === 36) && (num2 === 38)) {
    console.log('36 + 38 = 74')
}
if ((num1 === 36) && (num2 === 39)) {
    console.log('36 + 39 = 75')
}
if ((num1 === 36) && (num2 === 40)) {
    console.log('36 + 40 = 76')
}
if ((num1 === 36) && (num2 === 41)) {
    console.log('36 + 41 = 77')
}
if ((num1 === 36) && (num2 === 42)) {
    console.log('36 + 42 = 78')
}
if ((num1 === 36) && (num2 === 43)) {
    console.log('36 + 43 = 79')
}
if ((num1 === 36) && (num2 === 44)) {
    console.log('36 + 44 = 80')
}
if ((num1 === 36) && (num2 === 45)) {
    console.log('36 + 45 = 81')
}
if ((num1 === 36) && (num2 === 46)) {
    console.log('36 + 46 = 82')
}
if ((num1 === 36) && (num2 === 47)) {
    console.log('36 + 47 = 83')
}
if ((num1 === 36) && (num2 === 48)) {
    console.log('36 + 48 = 84')
}
if ((num1 === 36) && (num2 === 49)) {
    console.log('36 + 49 = 85')
}
if ((num1 === 36) && (num2 === 50)) {
    console.log('36 + 50 = 86')
}
if ((num1 === 37) && (num2 === 0)) {
    console.log('37 + 0 = 37')
}
if ((num1 === 37) && (num2 === 1)) {
    console.log('37 + 1 = 38')
}
if ((num1 === 37) && (num2 === 2)) {
    console.log('37 + 2 = 39')
}
if ((num1 === 37) && (num2 === 3)) {
    console.log('37 + 3 = 40')
}
if ((num1 === 37) && (num2 === 4)) {
    console.log('37 + 4 = 41')
}
if ((num1 === 37) && (num2 === 5)) {
    console.log('37 + 5 = 42')
}
if ((num1 === 37) && (num2 === 6)) {
    console.log('37 + 6 = 43')
}
if ((num1 === 37) && (num2 === 7)) {
    console.log('37 + 7 = 44')
}
if ((num1 === 37) && (num2 === 8)) {
    console.log('37 + 8 = 45')
}
if ((num1 === 37) && (num2 === 9)) {
    console.log('37 + 9 = 46')
}
if ((num1 === 37) && (num2 === 10)) {
    console.log('37 + 10 = 47')
}
if ((num1 === 37) && (num2 === 11)) {
    console.log('37 + 11 = 48')
}
if ((num1 === 37) && (num2 === 12)) {
    console.log('37 + 12 = 49')
}
if ((num1 === 37) && (num2 === 13)) {
    console.log('37 + 13 = 50')
}
if ((num1 === 37) && (num2 === 14)) {
    console.log('37 + 14 = 51')
}
if ((num1 === 37) && (num2 === 15)) {
    console.log('37 + 15 = 52')
}
if ((num1 === 37) && (num2 === 16)) {
    console.log('37 + 16 = 53')
}
if ((num1 === 37) && (num2 === 17)) {
    console.log('37 + 17 = 54')
}
if ((num1 === 37) && (num2 === 18)) {
    console.log('37 + 18 = 55')
}
if ((num1 === 37) && (num2 === 19)) {
    console.log('37 + 19 = 56')
}
if ((num1 === 37) && (num2 === 20)) {
    console.log('37 + 20 = 57')
}
if ((num1 === 37) && (num2 === 21)) {
    console.log('37 + 21 = 58')
}
if ((num1 === 37) && (num2 === 22)) {
    console.log('37 + 22 = 59')
}
if ((num1 === 37) && (num2 === 23)) {
    console.log('37 + 23 = 60')
}
if ((num1 === 37) && (num2 === 24)) {
    console.log('37 + 24 = 61')
}
if ((num1 === 37) && (num2 === 25)) {
    console.log('37 + 25 = 62')
}
if ((num1 === 37) && (num2 === 26)) {
    console.log('37 + 26 = 63')
}
if ((num1 === 37) && (num2 === 27)) {
    console.log('37 + 27 = 64')
}
if ((num1 === 37) && (num2 === 28)) {
    console.log('37 + 28 = 65')
}
if ((num1 === 37) && (num2 === 29)) {
    console.log('37 + 29 = 66')
}
if ((num1 === 37) && (num2 === 30)) {
    console.log('37 + 30 = 67')
}
if ((num1 === 37) && (num2 === 31)) {
    console.log('37 + 31 = 68')
}
if ((num1 === 37) && (num2 === 32)) {
    console.log('37 + 32 = 69')
}
if ((num1 === 37) && (num2 === 33)) {
    console.log('37 + 33 = 70')
}
if ((num1 === 37) && (num2 === 34)) {
    console.log('37 + 34 = 71')
}
if ((num1 === 37) && (num2 === 35)) {
    console.log('37 + 35 = 72')
}
if ((num1 === 37) && (num2 === 36)) {
    console.log('37 + 36 = 73')
}
if ((num1 === 37) && (num2 === 37)) {
    console.log('37 + 37 = 74')
}
if ((num1 === 37) && (num2 === 38)) {
    console.log('37 + 38 = 75')
}
if ((num1 === 37) && (num2 === 39)) {
    console.log('37 + 39 = 76')
}
if ((num1 === 37) && (num2 === 40)) {
    console.log('37 + 40 = 77')
}
if ((num1 === 37) && (num2 === 41)) {
    console.log('37 + 41 = 78')
}
if ((num1 === 37) && (num2 === 42)) {
    console.log('37 + 42 = 79')
}
if ((num1 === 37) && (num2 === 43)) {
    console.log('37 + 43 = 80')
}
if ((num1 === 37) && (num2 === 44)) {
    console.log('37 + 44 = 81')
}
if ((num1 === 37) && (num2 === 45)) {
    console.log('37 + 45 = 82')
}
if ((num1 === 37) && (num2 === 46)) {
    console.log('37 + 46 = 83')
}
if ((num1 === 37) && (num2 === 47)) {
    console.log('37 + 47 = 84')
}
if ((num1 === 37) && (num2 === 48)) {
    console.log('37 + 48 = 85')
}
if ((num1 === 37) && (num2 === 49)) {
    console.log('37 + 49 = 86')
}
if ((num1 === 37) && (num2 === 50)) {
    console.log('37 + 50 = 87')
}
if ((num1 === 38) && (num2 === 0)) {
    console.log('38 + 0 = 38')
}
if ((num1 === 38) && (num2 === 1)) {
    console.log('38 + 1 = 39')
}
if ((num1 === 38) && (num2 === 2)) {
    console.log('38 + 2 = 40')
}
if ((num1 === 38) && (num2 === 3)) {
    console.log('38 + 3 = 41')
}
if ((num1 === 38) && (num2 === 4)) {
    console.log('38 + 4 = 42')
}
if ((num1 === 38) && (num2 === 5)) {
    console.log('38 + 5 = 43')
}
if ((num1 === 38) && (num2 === 6)) {
    console.log('38 + 6 = 44')
}
if ((num1 === 38) && (num2 === 7)) {
    console.log('38 + 7 = 45')
}
if ((num1 === 38) && (num2 === 8)) {
    console.log('38 + 8 = 46')
}
if ((num1 === 38) && (num2 === 9)) {
    console.log('38 + 9 = 47')
}
if ((num1 === 38) && (num2 === 10)) {
    console.log('38 + 10 = 48')
}
if ((num1 === 38) && (num2 === 11)) {
    console.log('38 + 11 = 49')
}
if ((num1 === 38) && (num2 === 12)) {
    console.log('38 + 12 = 50')
}
if ((num1 === 38) && (num2 === 13)) {
    console.log('38 + 13 = 51')
}
if ((num1 === 38) && (num2 === 14)) {
    console.log('38 + 14 = 52')
}
if ((num1 === 38) && (num2 === 15)) {
    console.log('38 + 15 = 53')
}
if ((num1 === 38) && (num2 === 16)) {
    console.log('38 + 16 = 54')
}
if ((num1 === 38) && (num2 === 17)) {
    console.log('38 + 17 = 55')
}
if ((num1 === 38) && (num2 === 18)) {
    console.log('38 + 18 = 56')
}
if ((num1 === 38) && (num2 === 19)) {
    console.log('38 + 19 = 57')
}
if ((num1 === 38) && (num2 === 20)) {
    console.log('38 + 20 = 58')
}
if ((num1 === 38) && (num2 === 21)) {
    console.log('38 + 21 = 59')
}
if ((num1 === 38) && (num2 === 22)) {
    console.log('38 + 22 = 60')
}
if ((num1 === 38) && (num2 === 23)) {
    console.log('38 + 23 = 61')
}
if ((num1 === 38) && (num2 === 24)) {
    console.log('38 + 24 = 62')
}
if ((num1 === 38) && (num2 === 25)) {
    console.log('38 + 25 = 63')
}
if ((num1 === 38) && (num2 === 26)) {
    console.log('38 + 26 = 64')
}
if ((num1 === 38) && (num2 === 27)) {
    console.log('38 + 27 = 65')
}
if ((num1 === 38) && (num2 === 28)) {
    console.log('38 + 28 = 66')
}
if ((num1 === 38) && (num2 === 29)) {
    console.log('38 + 29 = 67')
}
if ((num1 === 38) && (num2 === 30)) {
    console.log('38 + 30 = 68')
}
if ((num1 === 38) && (num2 === 31)) {
    console.log('38 + 31 = 69')
}
if ((num1 === 38) && (num2 === 32)) {
    console.log('38 + 32 = 70')
}
if ((num1 === 38) && (num2 === 33)) {
    console.log('38 + 33 = 71')
}
if ((num1 === 38) && (num2 === 34)) {
    console.log('38 + 34 = 72')
}
if ((num1 === 38) && (num2 === 35)) {
    console.log('38 + 35 = 73')
}
if ((num1 === 38) && (num2 === 36)) {
    console.log('38 + 36 = 74')
}
if ((num1 === 38) && (num2 === 37)) {
    console.log('38 + 37 = 75')
}
if ((num1 === 38) && (num2 === 38)) {
    console.log('38 + 38 = 76')
}
if ((num1 === 38) && (num2 === 39)) {
    console.log('38 + 39 = 77')
}
if ((num1 === 38) && (num2 === 40)) {
    console.log('38 + 40 = 78')
}
if ((num1 === 38) && (num2 === 41)) {
    console.log('38 + 41 = 79')
}
if ((num1 === 38) && (num2 === 42)) {
    console.log('38 + 42 = 80')
}
if ((num1 === 38) && (num2 === 43)) {
    console.log('38 + 43 = 81')
}
if ((num1 === 38) && (num2 === 44)) {
    console.log('38 + 44 = 82')
}
if ((num1 === 38) && (num2 === 45)) {
    console.log('38 + 45 = 83')
}
if ((num1 === 38) && (num2 === 46)) {
    console.log('38 + 46 = 84')
}
if ((num1 === 38) && (num2 === 47)) {
    console.log('38 + 47 = 85')
}
if ((num1 === 38) && (num2 === 48)) {
    console.log('38 + 48 = 86')
}
if ((num1 === 38) && (num2 === 49)) {
    console.log('38 + 49 = 87')
}
if ((num1 === 38) && (num2 === 50)) {
    console.log('38 + 50 = 88')
}
if ((num1 === 39) && (num2 === 0)) {
    console.log('39 + 0 = 39')
}
if ((num1 === 39) && (num2 === 1)) {
    console.log('39 + 1 = 40')
}
if ((num1 === 39) && (num2 === 2)) {
    console.log('39 + 2 = 41')
}
if ((num1 === 39) && (num2 === 3)) {
    console.log('39 + 3 = 42')
}
if ((num1 === 39) && (num2 === 4)) {
    console.log('39 + 4 = 43')
}
if ((num1 === 39) && (num2 === 5)) {
    console.log('39 + 5 = 44')
}
if ((num1 === 39) && (num2 === 6)) {
    console.log('39 + 6 = 45')
}
if ((num1 === 39) && (num2 === 7)) {
    console.log('39 + 7 = 46')
}
if ((num1 === 39) && (num2 === 8)) {
    console.log('39 + 8 = 47')
}
if ((num1 === 39) && (num2 === 9)) {
    console.log('39 + 9 = 48')
}
if ((num1 === 39) && (num2 === 10)) {
    console.log('39 + 10 = 49')
}
if ((num1 === 39) && (num2 === 11)) {
    console.log('39 + 11 = 50')
}
if ((num1 === 39) && (num2 === 12)) {
    console.log('39 + 12 = 51')
}
if ((num1 === 39) && (num2 === 13)) {
    console.log('39 + 13 = 52')
}
if ((num1 === 39) && (num2 === 14)) {
    console.log('39 + 14 = 53')
}
if ((num1 === 39) && (num2 === 15)) {
    console.log('39 + 15 = 54')
}
if ((num1 === 39) && (num2 === 16)) {
    console.log('39 + 16 = 55')
}
if ((num1 === 39) && (num2 === 17)) {
    console.log('39 + 17 = 56')
}
if ((num1 === 39) && (num2 === 18)) {
    console.log('39 + 18 = 57')
}
if ((num1 === 39) && (num2 === 19)) {
    console.log('39 + 19 = 58')
}
if ((num1 === 39) && (num2 === 20)) {
    console.log('39 + 20 = 59')
}
if ((num1 === 39) && (num2 === 21)) {
    console.log('39 + 21 = 60')
}
if ((num1 === 39) && (num2 === 22)) {
    console.log('39 + 22 = 61')
}
if ((num1 === 39) && (num2 === 23)) {
    console.log('39 + 23 = 62')
}
if ((num1 === 39) && (num2 === 24)) {
    console.log('39 + 24 = 63')
}
if ((num1 === 39) && (num2 === 25)) {
    console.log('39 + 25 = 64')
}
if ((num1 === 39) && (num2 === 26)) {
    console.log('39 + 26 = 65')
}
if ((num1 === 39) && (num2 === 27)) {
    console.log('39 + 27 = 66')
}
if ((num1 === 39) && (num2 === 28)) {
    console.log('39 + 28 = 67')
}
if ((num1 === 39) && (num2 === 29)) {
    console.log('39 + 29 = 68')
}
if ((num1 === 39) && (num2 === 30)) {
    console.log('39 + 30 = 69')
}
if ((num1 === 39) && (num2 === 31)) {
    console.log('39 + 31 = 70')
}
if ((num1 === 39) && (num2 === 32)) {
    console.log('39 + 32 = 71')
}
if ((num1 === 39) && (num2 === 33)) {
    console.log('39 + 33 = 72')
}
if ((num1 === 39) && (num2 === 34)) {
    console.log('39 + 34 = 73')
}
if ((num1 === 39) && (num2 === 35)) {
    console.log('39 + 35 = 74')
}
if ((num1 === 39) && (num2 === 36)) {
    console.log('39 + 36 = 75')
}
if ((num1 === 39) && (num2 === 37)) {
    console.log('39 + 37 = 76')
}
if ((num1 === 39) && (num2 === 38)) {
    console.log('39 + 38 = 77')
}
if ((num1 === 39) && (num2 === 39)) {
    console.log('39 + 39 = 78')
}
if ((num1 === 39) && (num2 === 40)) {
    console.log('39 + 40 = 79')
}
if ((num1 === 39) && (num2 === 41)) {
    console.log('39 + 41 = 80')
}
if ((num1 === 39) && (num2 === 42)) {
    console.log('39 + 42 = 81')
}
if ((num1 === 39) && (num2 === 43)) {
    console.log('39 + 43 = 82')
}
if ((num1 === 39) && (num2 === 44)) {
    console.log('39 + 44 = 83')
}
if ((num1 === 39) && (num2 === 45)) {
    console.log('39 + 45 = 84')
}
if ((num1 === 39) && (num2 === 46)) {
    console.log('39 + 46 = 85')
}
if ((num1 === 39) && (num2 === 47)) {
    console.log('39 + 47 = 86')
}
if ((num1 === 39) && (num2 === 48)) {
    console.log('39 + 48 = 87')
}
if ((num1 === 39) && (num2 === 49)) {
    console.log('39 + 49 = 88')
}
if ((num1 === 39) && (num2 === 50)) {
    console.log('39 + 50 = 89')
}
if ((num1 === 40) && (num2 === 0)) {
    console.log('40 + 0 = 40')
}
if ((num1 === 40) && (num2 === 1)) {
    console.log('40 + 1 = 41')
}
if ((num1 === 40) && (num2 === 2)) {
    console.log('40 + 2 = 42')
}
if ((num1 === 40) && (num2 === 3)) {
    console.log('40 + 3 = 43')
}
if ((num1 === 40) && (num2 === 4)) {
    console.log('40 + 4 = 44')
}
if ((num1 === 40) && (num2 === 5)) {
    console.log('40 + 5 = 45')
}
if ((num1 === 40) && (num2 === 6)) {
    console.log('40 + 6 = 46')
}
if ((num1 === 40) && (num2 === 7)) {
    console.log('40 + 7 = 47')
}
if ((num1 === 40) && (num2 === 8)) {
    console.log('40 + 8 = 48')
}
if ((num1 === 40) && (num2 === 9)) {
    console.log('40 + 9 = 49')
}
if ((num1 === 40) && (num2 === 10)) {
    console.log('40 + 10 = 50')
}
if ((num1 === 40) && (num2 === 11)) {
    console.log('40 + 11 = 51')
}
if ((num1 === 40) && (num2 === 12)) {
    console.log('40 + 12 = 52')
}
if ((num1 === 40) && (num2 === 13)) {
    console.log('40 + 13 = 53')
}
if ((num1 === 40) && (num2 === 14)) {
    console.log('40 + 14 = 54')
}
if ((num1 === 40) && (num2 === 15)) {
    console.log('40 + 15 = 55')
}
if ((num1 === 40) && (num2 === 16)) {
    console.log('40 + 16 = 56')
}
if ((num1 === 40) && (num2 === 17)) {
    console.log('40 + 17 = 57')
}
if ((num1 === 40) && (num2 === 18)) {
    console.log('40 + 18 = 58')
}
if ((num1 === 40) && (num2 === 19)) {
    console.log('40 + 19 = 59')
}
if ((num1 === 40) && (num2 === 20)) {
    console.log('40 + 20 = 60')
}
if ((num1 === 40) && (num2 === 21)) {
    console.log('40 + 21 = 61')
}
if ((num1 === 40) && (num2 === 22)) {
    console.log('40 + 22 = 62')
}
if ((num1 === 40) && (num2 === 23)) {
    console.log('40 + 23 = 63')
}
if ((num1 === 40) && (num2 === 24)) {
    console.log('40 + 24 = 64')
}
if ((num1 === 40) && (num2 === 25)) {
    console.log('40 + 25 = 65')
}
if ((num1 === 40) && (num2 === 26)) {
    console.log('40 + 26 = 66')
}
if ((num1 === 40) && (num2 === 27)) {
    console.log('40 + 27 = 67')
}
if ((num1 === 40) && (num2 === 28)) {
    console.log('40 + 28 = 68')
}
if ((num1 === 40) && (num2 === 29)) {
    console.log('40 + 29 = 69')
}
if ((num1 === 40) && (num2 === 30)) {
    console.log('40 + 30 = 70')
}
if ((num1 === 40) && (num2 === 31)) {
    console.log('40 + 31 = 71')
}
if ((num1 === 40) && (num2 === 32)) {
    console.log('40 + 32 = 72')
}
if ((num1 === 40) && (num2 === 33)) {
    console.log('40 + 33 = 73')
}
if ((num1 === 40) && (num2 === 34)) {
    console.log('40 + 34 = 74')
}
if ((num1 === 40) && (num2 === 35)) {
    console.log('40 + 35 = 75')
}
if ((num1 === 40) && (num2 === 36)) {
    console.log('40 + 36 = 76')
}
if ((num1 === 40) && (num2 === 37)) {
    console.log('40 + 37 = 77')
}
if ((num1 === 40) && (num2 === 38)) {
    console.log('40 + 38 = 78')
}
if ((num1 === 40) && (num2 === 39)) {
    console.log('40 + 39 = 79')
}
if ((num1 === 40) && (num2 === 40)) {
    console.log('40 + 40 = 80')
}
if ((num1 === 40) && (num2 === 41)) {
    console.log('40 + 41 = 81')
}
if ((num1 === 40) && (num2 === 42)) {
    console.log('40 + 42 = 82')
}
if ((num1 === 40) && (num2 === 43)) {
    console.log('40 + 43 = 83')
}
if ((num1 === 40) && (num2 === 44)) {
    console.log('40 + 44 = 84')
}
if ((num1 === 40) && (num2 === 45)) {
    console.log('40 + 45 = 85')
}
if ((num1 === 40) && (num2 === 46)) {
    console.log('40 + 46 = 86')
}
if ((num1 === 40) && (num2 === 47)) {
    console.log('40 + 47 = 87')
}
if ((num1 === 40) && (num2 === 48)) {
    console.log('40 + 48 = 88')
}
if ((num1 === 40) && (num2 === 49)) {
    console.log('40 + 49 = 89')
}
if ((num1 === 40) && (num2 === 50)) {
    console.log('40 + 50 = 90')
}
if ((num1 === 41) && (num2 === 0)) {
    console.log('41 + 0 = 41')
}
if ((num1 === 41) && (num2 === 1)) {
    console.log('41 + 1 = 42')
}
if ((num1 === 41) && (num2 === 2)) {
    console.log('41 + 2 = 43')
}
if ((num1 === 41) && (num2 === 3)) {
    console.log('41 + 3 = 44')
}
if ((num1 === 41) && (num2 === 4)) {
    console.log('41 + 4 = 45')
}
if ((num1 === 41) && (num2 === 5)) {
    console.log('41 + 5 = 46')
}
if ((num1 === 41) && (num2 === 6)) {
    console.log('41 + 6 = 47')
}
if ((num1 === 41) && (num2 === 7)) {
    console.log('41 + 7 = 48')
}
if ((num1 === 41) && (num2 === 8)) {
    console.log('41 + 8 = 49')
}
if ((num1 === 41) && (num2 === 9)) {
    console.log('41 + 9 = 50')
}
if ((num1 === 41) && (num2 === 10)) {
    console.log('41 + 10 = 51')
}
if ((num1 === 41) && (num2 === 11)) {
    console.log('41 + 11 = 52')
}
if ((num1 === 41) && (num2 === 12)) {
    console.log('41 + 12 = 53')
}
if ((num1 === 41) && (num2 === 13)) {
    console.log('41 + 13 = 54')
}
if ((num1 === 41) && (num2 === 14)) {
    console.log('41 + 14 = 55')
}
if ((num1 === 41) && (num2 === 15)) {
    console.log('41 + 15 = 56')
}
if ((num1 === 41) && (num2 === 16)) {
    console.log('41 + 16 = 57')
}
if ((num1 === 41) && (num2 === 17)) {
    console.log('41 + 17 = 58')
}
if ((num1 === 41) && (num2 === 18)) {
    console.log('41 + 18 = 59')
}
if ((num1 === 41) && (num2 === 19)) {
    console.log('41 + 19 = 60')
}
if ((num1 === 41) && (num2 === 20)) {
    console.log('41 + 20 = 61')
}
if ((num1 === 41) && (num2 === 21)) {
    console.log('41 + 21 = 62')
}
if ((num1 === 41) && (num2 === 22)) {
    console.log('41 + 22 = 63')
}
if ((num1 === 41) && (num2 === 23)) {
    console.log('41 + 23 = 64')
}
if ((num1 === 41) && (num2 === 24)) {
    console.log('41 + 24 = 65')
}
if ((num1 === 41) && (num2 === 25)) {
    console.log('41 + 25 = 66')
}
if ((num1 === 41) && (num2 === 26)) {
    console.log('41 + 26 = 67')
}
if ((num1 === 41) && (num2 === 27)) {
    console.log('41 + 27 = 68')
}
if ((num1 === 41) && (num2 === 28)) {
    console.log('41 + 28 = 69')
}
if ((num1 === 41) && (num2 === 29)) {
    console.log('41 + 29 = 70')
}
if ((num1 === 41) && (num2 === 30)) {
    console.log('41 + 30 = 71')
}
if ((num1 === 41) && (num2 === 31)) {
    console.log('41 + 31 = 72')
}
if ((num1 === 41) && (num2 === 32)) {
    console.log('41 + 32 = 73')
}
if ((num1 === 41) && (num2 === 33)) {
    console.log('41 + 33 = 74')
}
if ((num1 === 41) && (num2 === 34)) {
    console.log('41 + 34 = 75')
}
if ((num1 === 41) && (num2 === 35)) {
    console.log('41 + 35 = 76')
}
if ((num1 === 41) && (num2 === 36)) {
    console.log('41 + 36 = 77')
}
if ((num1 === 41) && (num2 === 37)) {
    console.log('41 + 37 = 78')
}
if ((num1 === 41) && (num2 === 38)) {
    console.log('41 + 38 = 79')
}
if ((num1 === 41) && (num2 === 39)) {
    console.log('41 + 39 = 80')
}
if ((num1 === 41) && (num2 === 40)) {
    console.log('41 + 40 = 81')
}
if ((num1 === 41) && (num2 === 41)) {
    console.log('41 + 41 = 82')
}
if ((num1 === 41) && (num2 === 42)) {
    console.log('41 + 42 = 83')
}
if ((num1 === 41) && (num2 === 43)) {
    console.log('41 + 43 = 84')
}
if ((num1 === 41) && (num2 === 44)) {
    console.log('41 + 44 = 85')
}
if ((num1 === 41) && (num2 === 45)) {
    console.log('41 + 45 = 86')
}
if ((num1 === 41) && (num2 === 46)) {
    console.log('41 + 46 = 87')
}
if ((num1 === 41) && (num2 === 47)) {
    console.log('41 + 47 = 88')
}
if ((num1 === 41) && (num2 === 48)) {
    console.log('41 + 48 = 89')
}
if ((num1 === 41) && (num2 === 49)) {
    console.log('41 + 49 = 90')
}
if ((num1 === 41) && (num2 === 50)) {
    console.log('41 + 50 = 91')
}
if ((num1 === 42) && (num2 === 0)) {
    console.log('42 + 0 = 42')
}
if ((num1 === 42) && (num2 === 1)) {
    console.log('42 + 1 = 43')
}
if ((num1 === 42) && (num2 === 2)) {
    console.log('42 + 2 = 44')
}
if ((num1 === 42) && (num2 === 3)) {
    console.log('42 + 3 = 45')
}
if ((num1 === 42) && (num2 === 4)) {
    console.log('42 + 4 = 46')
}
if ((num1 === 42) && (num2 === 5)) {
    console.log('42 + 5 = 47')
}
if ((num1 === 42) && (num2 === 6)) {
    console.log('42 + 6 = 48')
}
if ((num1 === 42) && (num2 === 7)) {
    console.log('42 + 7 = 49')
}
if ((num1 === 42) && (num2 === 8)) {
    console.log('42 + 8 = 50')
}
if ((num1 === 42) && (num2 === 9)) {
    console.log('42 + 9 = 51')
}
if ((num1 === 42) && (num2 === 10)) {
    console.log('42 + 10 = 52')
}
if ((num1 === 42) && (num2 === 11)) {
    console.log('42 + 11 = 53')
}
if ((num1 === 42) && (num2 === 12)) {
    console.log('42 + 12 = 54')
}
if ((num1 === 42) && (num2 === 13)) {
    console.log('42 + 13 = 55')
}
if ((num1 === 42) && (num2 === 14)) {
    console.log('42 + 14 = 56')
}
if ((num1 === 42) && (num2 === 15)) {
    console.log('42 + 15 = 57')
}
if ((num1 === 42) && (num2 === 16)) {
    console.log('42 + 16 = 58')
}
if ((num1 === 42) && (num2 === 17)) {
    console.log('42 + 17 = 59')
}
if ((num1 === 42) && (num2 === 18)) {
    console.log('42 + 18 = 60')
}
if ((num1 === 42) && (num2 === 19)) {
    console.log('42 + 19 = 61')
}
if ((num1 === 42) && (num2 === 20)) {
    console.log('42 + 20 = 62')
}
if ((num1 === 42) && (num2 === 21)) {
    console.log('42 + 21 = 63')
}
if ((num1 === 42) && (num2 === 22)) {
    console.log('42 + 22 = 64')
}
if ((num1 === 42) && (num2 === 23)) {
    console.log('42 + 23 = 65')
}
if ((num1 === 42) && (num2 === 24)) {
    console.log('42 + 24 = 66')
}
if ((num1 === 42) && (num2 === 25)) {
    console.log('42 + 25 = 67')
}
if ((num1 === 42) && (num2 === 26)) {
    console.log('42 + 26 = 68')
}
if ((num1 === 42) && (num2 === 27)) {
    console.log('42 + 27 = 69')
}
if ((num1 === 42) && (num2 === 28)) {
    console.log('42 + 28 = 70')
}
if ((num1 === 42) && (num2 === 29)) {
    console.log('42 + 29 = 71')
}
if ((num1 === 42) && (num2 === 30)) {
    console.log('42 + 30 = 72')
}
if ((num1 === 42) && (num2 === 31)) {
    console.log('42 + 31 = 73')
}
if ((num1 === 42) && (num2 === 32)) {
    console.log('42 + 32 = 74')
}
if ((num1 === 42) && (num2 === 33)) {
    console.log('42 + 33 = 75')
}
if ((num1 === 42) && (num2 === 34)) {
    console.log('42 + 34 = 76')
}
if ((num1 === 42) && (num2 === 35)) {
    console.log('42 + 35 = 77')
}
if ((num1 === 42) && (num2 === 36)) {
    console.log('42 + 36 = 78')
}
if ((num1 === 42) && (num2 === 37)) {
    console.log('42 + 37 = 79')
}
if ((num1 === 42) && (num2 === 38)) {
    console.log('42 + 38 = 80')
}
if ((num1 === 42) && (num2 === 39)) {
    console.log('42 + 39 = 81')
}
if ((num1 === 42) && (num2 === 40)) {
    console.log('42 + 40 = 82')
}
if ((num1 === 42) && (num2 === 41)) {
    console.log('42 + 41 = 83')
}
if ((num1 === 42) && (num2 === 42)) {
    console.log('42 + 42 = 84')
}
if ((num1 === 42) && (num2 === 43)) {
    console.log('42 + 43 = 85')
}
if ((num1 === 42) && (num2 === 44)) {
    console.log('42 + 44 = 86')
}
if ((num1 === 42) && (num2 === 45)) {
    console.log('42 + 45 = 87')
}
if ((num1 === 42) && (num2 === 46)) {
    console.log('42 + 46 = 88')
}
if ((num1 === 42) && (num2 === 47)) {
    console.log('42 + 47 = 89')
}
if ((num1 === 42) && (num2 === 48)) {
    console.log('42 + 48 = 90')
}
if ((num1 === 42) && (num2 === 49)) {
    console.log('42 + 49 = 91')
}
if ((num1 === 42) && (num2 === 50)) {
    console.log('42 + 50 = 92')
}
if ((num1 === 43) && (num2 === 0)) {
    console.log('43 + 0 = 43')
}
if ((num1 === 43) && (num2 === 1)) {
    console.log('43 + 1 = 44')
}
if ((num1 === 43) && (num2 === 2)) {
    console.log('43 + 2 = 45')
}
if ((num1 === 43) && (num2 === 3)) {
    console.log('43 + 3 = 46')
}
if ((num1 === 43) && (num2 === 4)) {
    console.log('43 + 4 = 47')
}
if ((num1 === 43) && (num2 === 5)) {
    console.log('43 + 5 = 48')
}
if ((num1 === 43) && (num2 === 6)) {
    console.log('43 + 6 = 49')
}
if ((num1 === 43) && (num2 === 7)) {
    console.log('43 + 7 = 50')
}
if ((num1 === 43) && (num2 === 8)) {
    console.log('43 + 8 = 51')
}
if ((num1 === 43) && (num2 === 9)) {
    console.log('43 + 9 = 52')
}
if ((num1 === 43) && (num2 === 10)) {
    console.log('43 + 10 = 53')
}
if ((num1 === 43) && (num2 === 11)) {
    console.log('43 + 11 = 54')
}
if ((num1 === 43) && (num2 === 12)) {
    console.log('43 + 12 = 55')
}
if ((num1 === 43) && (num2 === 13)) {
    console.log('43 + 13 = 56')
}
if ((num1 === 43) && (num2 === 14)) {
    console.log('43 + 14 = 57')
}
if ((num1 === 43) && (num2 === 15)) {
    console.log('43 + 15 = 58')
}
if ((num1 === 43) && (num2 === 16)) {
    console.log('43 + 16 = 59')
}
if ((num1 === 43) && (num2 === 17)) {
    console.log('43 + 17 = 60')
}
if ((num1 === 43) && (num2 === 18)) {
    console.log('43 + 18 = 61')
}
if ((num1 === 43) && (num2 === 19)) {
    console.log('43 + 19 = 62')
}
if ((num1 === 43) && (num2 === 20)) {
    console.log('43 + 20 = 63')
}
if ((num1 === 43) && (num2 === 21)) {
    console.log('43 + 21 = 64')
}
if ((num1 === 43) && (num2 === 22)) {
    console.log('43 + 22 = 65')
}
if ((num1 === 43) && (num2 === 23)) {
    console.log('43 + 23 = 66')
}
if ((num1 === 43) && (num2 === 24)) {
    console.log('43 + 24 = 67')
}
if ((num1 === 43) && (num2 === 25)) {
    console.log('43 + 25 = 68')
}
if ((num1 === 43) && (num2 === 26)) {
    console.log('43 + 26 = 69')
}
if ((num1 === 43) && (num2 === 27)) {
    console.log('43 + 27 = 70')
}
if ((num1 === 43) && (num2 === 28)) {
    console.log('43 + 28 = 71')
}
if ((num1 === 43) && (num2 === 29)) {
    console.log('43 + 29 = 72')
}
if ((num1 === 43) && (num2 === 30)) {
    console.log('43 + 30 = 73')
}
if ((num1 === 43) && (num2 === 31)) {
    console.log('43 + 31 = 74')
}
if ((num1 === 43) && (num2 === 32)) {
    console.log('43 + 32 = 75')
}
if ((num1 === 43) && (num2 === 33)) {
    console.log('43 + 33 = 76')
}
if ((num1 === 43) && (num2 === 34)) {
    console.log('43 + 34 = 77')
}
if ((num1 === 43) && (num2 === 35)) {
    console.log('43 + 35 = 78')
}
if ((num1 === 43) && (num2 === 36)) {
    console.log('43 + 36 = 79')
}
if ((num1 === 43) && (num2 === 37)) {
    console.log('43 + 37 = 80')
}
if ((num1 === 43) && (num2 === 38)) {
    console.log('43 + 38 = 81')
}
if ((num1 === 43) && (num2 === 39)) {
    console.log('43 + 39 = 82')
}
if ((num1 === 43) && (num2 === 40)) {
    console.log('43 + 40 = 83')
}
if ((num1 === 43) && (num2 === 41)) {
    console.log('43 + 41 = 84')
}
if ((num1 === 43) && (num2 === 42)) {
    console.log('43 + 42 = 85')
}
if ((num1 === 43) && (num2 === 43)) {
    console.log('43 + 43 = 86')
}
if ((num1 === 43) && (num2 === 44)) {
    console.log('43 + 44 = 87')
}
if ((num1 === 43) && (num2 === 45)) {
    console.log('43 + 45 = 88')
}
if ((num1 === 43) && (num2 === 46)) {
    console.log('43 + 46 = 89')
}
if ((num1 === 43) && (num2 === 47)) {
    console.log('43 + 47 = 90')
}
if ((num1 === 43) && (num2 === 48)) {
    console.log('43 + 48 = 91')
}
if ((num1 === 43) && (num2 === 49)) {
    console.log('43 + 49 = 92')
}
if ((num1 === 43) && (num2 === 50)) {
    console.log('43 + 50 = 93')
}
if ((num1 === 44) && (num2 === 0)) {
    console.log('44 + 0 = 44')
}
if ((num1 === 44) && (num2 === 1)) {
    console.log('44 + 1 = 45')
}
if ((num1 === 44) && (num2 === 2)) {
    console.log('44 + 2 = 46')
}
if ((num1 === 44) && (num2 === 3)) {
    console.log('44 + 3 = 47')
}
if ((num1 === 44) && (num2 === 4)) {
    console.log('44 + 4 = 48')
}
if ((num1 === 44) && (num2 === 5)) {
    console.log('44 + 5 = 49')
}
if ((num1 === 44) && (num2 === 6)) {
    console.log('44 + 6 = 50')
}
if ((num1 === 44) && (num2 === 7)) {
    console.log('44 + 7 = 51')
}
if ((num1 === 44) && (num2 === 8)) {
    console.log('44 + 8 = 52')
}
if ((num1 === 44) && (num2 === 9)) {
    console.log('44 + 9 = 53')
}
if ((num1 === 44) && (num2 === 10)) {
    console.log('44 + 10 = 54')
}
if ((num1 === 44) && (num2 === 11)) {
    console.log('44 + 11 = 55')
}
if ((num1 === 44) && (num2 === 12)) {
    console.log('44 + 12 = 56')
}
if ((num1 === 44) && (num2 === 13)) {
    console.log('44 + 13 = 57')
}
if ((num1 === 44) && (num2 === 14)) {
    console.log('44 + 14 = 58')
}
if ((num1 === 44) && (num2 === 15)) {
    console.log('44 + 15 = 59')
}
if ((num1 === 44) && (num2 === 16)) {
    console.log('44 + 16 = 60')
}
if ((num1 === 44) && (num2 === 17)) {
    console.log('44 + 17 = 61')
}
if ((num1 === 44) && (num2 === 18)) {
    console.log('44 + 18 = 62')
}
if ((num1 === 44) && (num2 === 19)) {
    console.log('44 + 19 = 63')
}
if ((num1 === 44) && (num2 === 20)) {
    console.log('44 + 20 = 64')
}
if ((num1 === 44) && (num2 === 21)) {
    console.log('44 + 21 = 65')
}
if ((num1 === 44) && (num2 === 22)) {
    console.log('44 + 22 = 66')
}
if ((num1 === 44) && (num2 === 23)) {
    console.log('44 + 23 = 67')
}
if ((num1 === 44) && (num2 === 24)) {
    console.log('44 + 24 = 68')
}
if ((num1 === 44) && (num2 === 25)) {
    console.log('44 + 25 = 69')
}
if ((num1 === 44) && (num2 === 26)) {
    console.log('44 + 26 = 70')
}
if ((num1 === 44) && (num2 === 27)) {
    console.log('44 + 27 = 71')
}
if ((num1 === 44) && (num2 === 28)) {
    console.log('44 + 28 = 72')
}
if ((num1 === 44) && (num2 === 29)) {
    console.log('44 + 29 = 73')
}
if ((num1 === 44) && (num2 === 30)) {
    console.log('44 + 30 = 74')
}
if ((num1 === 44) && (num2 === 31)) {
    console.log('44 + 31 = 75')
}
if ((num1 === 44) && (num2 === 32)) {
    console.log('44 + 32 = 76')
}
if ((num1 === 44) && (num2 === 33)) {
    console.log('44 + 33 = 77')
}
if ((num1 === 44) && (num2 === 34)) {
    console.log('44 + 34 = 78')
}
if ((num1 === 44) && (num2 === 35)) {
    console.log('44 + 35 = 79')
}
if ((num1 === 44) && (num2 === 36)) {
    console.log('44 + 36 = 80')
}
if ((num1 === 44) && (num2 === 37)) {
    console.log('44 + 37 = 81')
}
if ((num1 === 44) && (num2 === 38)) {
    console.log('44 + 38 = 82')
}
if ((num1 === 44) && (num2 === 39)) {
    console.log('44 + 39 = 83')
}
if ((num1 === 44) && (num2 === 40)) {
    console.log('44 + 40 = 84')
}
if ((num1 === 44) && (num2 === 41)) {
    console.log('44 + 41 = 85')
}
if ((num1 === 44) && (num2 === 42)) {
    console.log('44 + 42 = 86')
}
if ((num1 === 44) && (num2 === 43)) {
    console.log('44 + 43 = 87')
}
if ((num1 === 44) && (num2 === 44)) {
    console.log('44 + 44 = 88')
}
if ((num1 === 44) && (num2 === 45)) {
    console.log('44 + 45 = 89')
}
if ((num1 === 44) && (num2 === 46)) {
    console.log('44 + 46 = 90')
}
if ((num1 === 44) && (num2 === 47)) {
    console.log('44 + 47 = 91')
}
if ((num1 === 44) && (num2 === 48)) {
    console.log('44 + 48 = 92')
}
if ((num1 === 44) && (num2 === 49)) {
    console.log('44 + 49 = 93')
}
if ((num1 === 44) && (num2 === 50)) {
    console.log('44 + 50 = 94')
}
if ((num1 === 45) && (num2 === 0)) {
    console.log('45 + 0 = 45')
}
if ((num1 === 45) && (num2 === 1)) {
    console.log('45 + 1 = 46')
}
if ((num1 === 45) && (num2 === 2)) {
    console.log('45 + 2 = 47')
}
if ((num1 === 45) && (num2 === 3)) {
    console.log('45 + 3 = 48')
}
if ((num1 === 45) && (num2 === 4)) {
    console.log('45 + 4 = 49')
}
if ((num1 === 45) && (num2 === 5)) {
    console.log('45 + 5 = 50')
}
if ((num1 === 45) && (num2 === 6)) {
    console.log('45 + 6 = 51')
}
if ((num1 === 45) && (num2 === 7)) {
    console.log('45 + 7 = 52')
}
if ((num1 === 45) && (num2 === 8)) {
    console.log('45 + 8 = 53')
}
if ((num1 === 45) && (num2 === 9)) {
    console.log('45 + 9 = 54')
}
if ((num1 === 45) && (num2 === 10)) {
    console.log('45 + 10 = 55')
}
if ((num1 === 45) && (num2 === 11)) {
    console.log('45 + 11 = 56')
}
if ((num1 === 45) && (num2 === 12)) {
    console.log('45 + 12 = 57')
}
if ((num1 === 45) && (num2 === 13)) {
    console.log('45 + 13 = 58')
}
if ((num1 === 45) && (num2 === 14)) {
    console.log('45 + 14 = 59')
}
if ((num1 === 45) && (num2 === 15)) {
    console.log('45 + 15 = 60')
}
if ((num1 === 45) && (num2 === 16)) {
    console.log('45 + 16 = 61')
}
if ((num1 === 45) && (num2 === 17)) {
    console.log('45 + 17 = 62')
}
if ((num1 === 45) && (num2 === 18)) {
    console.log('45 + 18 = 63')
}
if ((num1 === 45) && (num2 === 19)) {
    console.log('45 + 19 = 64')
}
if ((num1 === 45) && (num2 === 20)) {
    console.log('45 + 20 = 65')
}
if ((num1 === 45) && (num2 === 21)) {
    console.log('45 + 21 = 66')
}
if ((num1 === 45) && (num2 === 22)) {
    console.log('45 + 22 = 67')
}
if ((num1 === 45) && (num2 === 23)) {
    console.log('45 + 23 = 68')
}
if ((num1 === 45) && (num2 === 24)) {
    console.log('45 + 24 = 69')
}
if ((num1 === 45) && (num2 === 25)) {
    console.log('45 + 25 = 70')
}
if ((num1 === 45) && (num2 === 26)) {
    console.log('45 + 26 = 71')
}
if ((num1 === 45) && (num2 === 27)) {
    console.log('45 + 27 = 72')
}
if ((num1 === 45) && (num2 === 28)) {
    console.log('45 + 28 = 73')
}
if ((num1 === 45) && (num2 === 29)) {
    console.log('45 + 29 = 74')
}
if ((num1 === 45) && (num2 === 30)) {
    console.log('45 + 30 = 75')
}
if ((num1 === 45) && (num2 === 31)) {
    console.log('45 + 31 = 76')
}
if ((num1 === 45) && (num2 === 32)) {
    console.log('45 + 32 = 77')
}
if ((num1 === 45) && (num2 === 33)) {
    console.log('45 + 33 = 78')
}
if ((num1 === 45) && (num2 === 34)) {
    console.log('45 + 34 = 79')
}
if ((num1 === 45) && (num2 === 35)) {
    console.log('45 + 35 = 80')
}
if ((num1 === 45) && (num2 === 36)) {
    console.log('45 + 36 = 81')
}
if ((num1 === 45) && (num2 === 37)) {
    console.log('45 + 37 = 82')
}
if ((num1 === 45) && (num2 === 38)) {
    console.log('45 + 38 = 83')
}
if ((num1 === 45) && (num2 === 39)) {
    console.log('45 + 39 = 84')
}
if ((num1 === 45) && (num2 === 40)) {
    console.log('45 + 40 = 85')
}
if ((num1 === 45) && (num2 === 41)) {
    console.log('45 + 41 = 86')
}
if ((num1 === 45) && (num2 === 42)) {
    console.log('45 + 42 = 87')
}
if ((num1 === 45) && (num2 === 43)) {
    console.log('45 + 43 = 88')
}
if ((num1 === 45) && (num2 === 44)) {
    console.log('45 + 44 = 89')
}
if ((num1 === 45) && (num2 === 45)) {
    console.log('45 + 45 = 90')
}
if ((num1 === 45) && (num2 === 46)) {
    console.log('45 + 46 = 91')
}
if ((num1 === 45) && (num2 === 47)) {
    console.log('45 + 47 = 92')
}
if ((num1 === 45) && (num2 === 48)) {
    console.log('45 + 48 = 93')
}
if ((num1 === 45) && (num2 === 49)) {
    console.log('45 + 49 = 94')
}
if ((num1 === 45) && (num2 === 50)) {
    console.log('45 + 50 = 95')
}
if ((num1 === 46) && (num2 === 0)) {
    console.log('46 + 0 = 46')
}
if ((num1 === 46) && (num2 === 1)) {
    console.log('46 + 1 = 47')
}
if ((num1 === 46) && (num2 === 2)) {
    console.log('46 + 2 = 48')
}
if ((num1 === 46) && (num2 === 3)) {
    console.log('46 + 3 = 49')
}
if ((num1 === 46) && (num2 === 4)) {
    console.log('46 + 4 = 50')
}
if ((num1 === 46) && (num2 === 5)) {
    console.log('46 + 5 = 51')
}
if ((num1 === 46) && (num2 === 6)) {
    console.log('46 + 6 = 52')
}
if ((num1 === 46) && (num2 === 7)) {
    console.log('46 + 7 = 53')
}
if ((num1 === 46) && (num2 === 8)) {
    console.log('46 + 8 = 54')
}
if ((num1 === 46) && (num2 === 9)) {
    console.log('46 + 9 = 55')
}
if ((num1 === 46) && (num2 === 10)) {
    console.log('46 + 10 = 56')
}
if ((num1 === 46) && (num2 === 11)) {
    console.log('46 + 11 = 57')
}
if ((num1 === 46) && (num2 === 12)) {
    console.log('46 + 12 = 58')
}
if ((num1 === 46) && (num2 === 13)) {
    console.log('46 + 13 = 59')
}
if ((num1 === 46) && (num2 === 14)) {
    console.log('46 + 14 = 60')
}
if ((num1 === 46) && (num2 === 15)) {
    console.log('46 + 15 = 61')
}
if ((num1 === 46) && (num2 === 16)) {
    console.log('46 + 16 = 62')
}
if ((num1 === 46) && (num2 === 17)) {
    console.log('46 + 17 = 63')
}
if ((num1 === 46) && (num2 === 18)) {
    console.log('46 + 18 = 64')
}
if ((num1 === 46) && (num2 === 19)) {
    console.log('46 + 19 = 65')
}
if ((num1 === 46) && (num2 === 20)) {
    console.log('46 + 20 = 66')
}
if ((num1 === 46) && (num2 === 21)) {
    console.log('46 + 21 = 67')
}
if ((num1 === 46) && (num2 === 22)) {
    console.log('46 + 22 = 68')
}
if ((num1 === 46) && (num2 === 23)) {
    console.log('46 + 23 = 69')
}
if ((num1 === 46) && (num2 === 24)) {
    console.log('46 + 24 = 70')
}
if ((num1 === 46) && (num2 === 25)) {
    console.log('46 + 25 = 71')
}
if ((num1 === 46) && (num2 === 26)) {
    console.log('46 + 26 = 72')
}
if ((num1 === 46) && (num2 === 27)) {
    console.log('46 + 27 = 73')
}
if ((num1 === 46) && (num2 === 28)) {
    console.log('46 + 28 = 74')
}
if ((num1 === 46) && (num2 === 29)) {
    console.log('46 + 29 = 75')
}
if ((num1 === 46) && (num2 === 30)) {
    console.log('46 + 30 = 76')
}
if ((num1 === 46) && (num2 === 31)) {
    console.log('46 + 31 = 77')
}
if ((num1 === 46) && (num2 === 32)) {
    console.log('46 + 32 = 78')
}
if ((num1 === 46) && (num2 === 33)) {
    console.log('46 + 33 = 79')
}
if ((num1 === 46) && (num2 === 34)) {
    console.log('46 + 34 = 80')
}
if ((num1 === 46) && (num2 === 35)) {
    console.log('46 + 35 = 81')
}
if ((num1 === 46) && (num2 === 36)) {
    console.log('46 + 36 = 82')
}
if ((num1 === 46) && (num2 === 37)) {
    console.log('46 + 37 = 83')
}
if ((num1 === 46) && (num2 === 38)) {
    console.log('46 + 38 = 84')
}
if ((num1 === 46) && (num2 === 39)) {
    console.log('46 + 39 = 85')
}
if ((num1 === 46) && (num2 === 40)) {
    console.log('46 + 40 = 86')
}
if ((num1 === 46) && (num2 === 41)) {
    console.log('46 + 41 = 87')
}
if ((num1 === 46) && (num2 === 42)) {
    console.log('46 + 42 = 88')
}
if ((num1 === 46) && (num2 === 43)) {
    console.log('46 + 43 = 89')
}
if ((num1 === 46) && (num2 === 44)) {
    console.log('46 + 44 = 90')
}
if ((num1 === 46) && (num2 === 45)) {
    console.log('46 + 45 = 91')
}
if ((num1 === 46) && (num2 === 46)) {
    console.log('46 + 46 = 92')
}
if ((num1 === 46) && (num2 === 47)) {
    console.log('46 + 47 = 93')
}
if ((num1 === 46) && (num2 === 48)) {
    console.log('46 + 48 = 94')
}
if ((num1 === 46) && (num2 === 49)) {
    console.log('46 + 49 = 95')
}
if ((num1 === 46) && (num2 === 50)) {
    console.log('46 + 50 = 96')
}
if ((num1 === 47) && (num2 === 0)) {
    console.log('47 + 0 = 47')
}
if ((num1 === 47) && (num2 === 1)) {
    console.log('47 + 1 = 48')
}
if ((num1 === 47) && (num2 === 2)) {
    console.log('47 + 2 = 49')
}
if ((num1 === 47) && (num2 === 3)) {
    console.log('47 + 3 = 50')
}
if ((num1 === 47) && (num2 === 4)) {
    console.log('47 + 4 = 51')
}
if ((num1 === 47) && (num2 === 5)) {
    console.log('47 + 5 = 52')
}
if ((num1 === 47) && (num2 === 6)) {
    console.log('47 + 6 = 53')
}
if ((num1 === 47) && (num2 === 7)) {
    console.log('47 + 7 = 54')
}
if ((num1 === 47) && (num2 === 8)) {
    console.log('47 + 8 = 55')
}
if ((num1 === 47) && (num2 === 9)) {
    console.log('47 + 9 = 56')
}
if ((num1 === 47) && (num2 === 10)) {
    console.log('47 + 10 = 57')
}
if ((num1 === 47) && (num2 === 11)) {
    console.log('47 + 11 = 58')
}
if ((num1 === 47) && (num2 === 12)) {
    console.log('47 + 12 = 59')
}
if ((num1 === 47) && (num2 === 13)) {
    console.log('47 + 13 = 60')
}
if ((num1 === 47) && (num2 === 14)) {
    console.log('47 + 14 = 61')
}
if ((num1 === 47) && (num2 === 15)) {
    console.log('47 + 15 = 62')
}
if ((num1 === 47) && (num2 === 16)) {
    console.log('47 + 16 = 63')
}
if ((num1 === 47) && (num2 === 17)) {
    console.log('47 + 17 = 64')
}
if ((num1 === 47) && (num2 === 18)) {
    console.log('47 + 18 = 65')
}
if ((num1 === 47) && (num2 === 19)) {
    console.log('47 + 19 = 66')
}
if ((num1 === 47) && (num2 === 20)) {
    console.log('47 + 20 = 67')
}
if ((num1 === 47) && (num2 === 21)) {
    console.log('47 + 21 = 68')
}
if ((num1 === 47) && (num2 === 22)) {
    console.log('47 + 22 = 69')
}
if ((num1 === 47) && (num2 === 23)) {
    console.log('47 + 23 = 70')
}
if ((num1 === 47) && (num2 === 24)) {
    console.log('47 + 24 = 71')
}
if ((num1 === 47) && (num2 === 25)) {
    console.log('47 + 25 = 72')
}
if ((num1 === 47) && (num2 === 26)) {
    console.log('47 + 26 = 73')
}
if ((num1 === 47) && (num2 === 27)) {
    console.log('47 + 27 = 74')
}
if ((num1 === 47) && (num2 === 28)) {
    console.log('47 + 28 = 75')
}
if ((num1 === 47) && (num2 === 29)) {
    console.log('47 + 29 = 76')
}
if ((num1 === 47) && (num2 === 30)) {
    console.log('47 + 30 = 77')
}
if ((num1 === 47) && (num2 === 31)) {
    console.log('47 + 31 = 78')
}
if ((num1 === 47) && (num2 === 32)) {
    console.log('47 + 32 = 79')
}
if ((num1 === 47) && (num2 === 33)) {
    console.log('47 + 33 = 80')
}
if ((num1 === 47) && (num2 === 34)) {
    console.log('47 + 34 = 81')
}
if ((num1 === 47) && (num2 === 35)) {
    console.log('47 + 35 = 82')
}
if ((num1 === 47) && (num2 === 36)) {
    console.log('47 + 36 = 83')
}
if ((num1 === 47) && (num2 === 37)) {
    console.log('47 + 37 = 84')
}
if ((num1 === 47) && (num2 === 38)) {
    console.log('47 + 38 = 85')
}
if ((num1 === 47) && (num2 === 39)) {
    console.log('47 + 39 = 86')
}
if ((num1 === 47) && (num2 === 40)) {
    console.log('47 + 40 = 87')
}
if ((num1 === 47) && (num2 === 41)) {
    console.log('47 + 41 = 88')
}
if ((num1 === 47) && (num2 === 42)) {
    console.log('47 + 42 = 89')
}
if ((num1 === 47) && (num2 === 43)) {
    console.log('47 + 43 = 90')
}
if ((num1 === 47) && (num2 === 44)) {
    console.log('47 + 44 = 91')
}
if ((num1 === 47) && (num2 === 45)) {
    console.log('47 + 45 = 92')
}
if ((num1 === 47) && (num2 === 46)) {
    console.log('47 + 46 = 93')
}
if ((num1 === 47) && (num2 === 47)) {
    console.log('47 + 47 = 94')
}
if ((num1 === 47) && (num2 === 48)) {
    console.log('47 + 48 = 95')
}
if ((num1 === 47) && (num2 === 49)) {
    console.log('47 + 49 = 96')
}
if ((num1 === 47) && (num2 === 50)) {
    console.log('47 + 50 = 97')
}
if ((num1 === 48) && (num2 === 0)) {
    console.log('48 + 0 = 48')
}
if ((num1 === 48) && (num2 === 1)) {
    console.log('48 + 1 = 49')
}
if ((num1 === 48) && (num2 === 2)) {
    console.log('48 + 2 = 50')
}
if ((num1 === 48) && (num2 === 3)) {
    console.log('48 + 3 = 51')
}
if ((num1 === 48) && (num2 === 4)) {
    console.log('48 + 4 = 52')
}
if ((num1 === 48) && (num2 === 5)) {
    console.log('48 + 5 = 53')
}
if ((num1 === 48) && (num2 === 6)) {
    console.log('48 + 6 = 54')
}
if ((num1 === 48) && (num2 === 7)) {
    console.log('48 + 7 = 55')
}
if ((num1 === 48) && (num2 === 8)) {
    console.log('48 + 8 = 56')
}
if ((num1 === 48) && (num2 === 9)) {
    console.log('48 + 9 = 57')
}
if ((num1 === 48) && (num2 === 10)) {
    console.log('48 + 10 = 58')
}
if ((num1 === 48) && (num2 === 11)) {
    console.log('48 + 11 = 59')
}
if ((num1 === 48) && (num2 === 12)) {
    console.log('48 + 12 = 60')
}
if ((num1 === 48) && (num2 === 13)) {
    console.log('48 + 13 = 61')
}
if ((num1 === 48) && (num2 === 14)) {
    console.log('48 + 14 = 62')
}
if ((num1 === 48) && (num2 === 15)) {
    console.log('48 + 15 = 63')
}
if ((num1 === 48) && (num2 === 16)) {
    console.log('48 + 16 = 64')
}
if ((num1 === 48) && (num2 === 17)) {
    console.log('48 + 17 = 65')
}
if ((num1 === 48) && (num2 === 18)) {
    console.log('48 + 18 = 66')
}
if ((num1 === 48) && (num2 === 19)) {
    console.log('48 + 19 = 67')
}
if ((num1 === 48) && (num2 === 20)) {
    console.log('48 + 20 = 68')
}
if ((num1 === 48) && (num2 === 21)) {
    console.log('48 + 21 = 69')
}
if ((num1 === 48) && (num2 === 22)) {
    console.log('48 + 22 = 70')
}
if ((num1 === 48) && (num2 === 23)) {
    console.log('48 + 23 = 71')
}
if ((num1 === 48) && (num2 === 24)) {
    console.log('48 + 24 = 72')
}
if ((num1 === 48) && (num2 === 25)) {
    console.log('48 + 25 = 73')
}
if ((num1 === 48) && (num2 === 26)) {
    console.log('48 + 26 = 74')
}
if ((num1 === 48) && (num2 === 27)) {
    console.log('48 + 27 = 75')
}
if ((num1 === 48) && (num2 === 28)) {
    console.log('48 + 28 = 76')
}
if ((num1 === 48) && (num2 === 29)) {
    console.log('48 + 29 = 77')
}
if ((num1 === 48) && (num2 === 30)) {
    console.log('48 + 30 = 78')
}
if ((num1 === 48) && (num2 === 31)) {
    console.log('48 + 31 = 79')
}
if ((num1 === 48) && (num2 === 32)) {
    console.log('48 + 32 = 80')
}
if ((num1 === 48) && (num2 === 33)) {
    console.log('48 + 33 = 81')
}
if ((num1 === 48) && (num2 === 34)) {
    console.log('48 + 34 = 82')
}
if ((num1 === 48) && (num2 === 35)) {
    console.log('48 + 35 = 83')
}
if ((num1 === 48) && (num2 === 36)) {
    console.log('48 + 36 = 84')
}
if ((num1 === 48) && (num2 === 37)) {
    console.log('48 + 37 = 85')
}
if ((num1 === 48) && (num2 === 38)) {
    console.log('48 + 38 = 86')
}
if ((num1 === 48) && (num2 === 39)) {
    console.log('48 + 39 = 87')
}
if ((num1 === 48) && (num2 === 40)) {
    console.log('48 + 40 = 88')
}
if ((num1 === 48) && (num2 === 41)) {
    console.log('48 + 41 = 89')
}
if ((num1 === 48) && (num2 === 42)) {
    console.log('48 + 42 = 90')
}
if ((num1 === 48) && (num2 === 43)) {
    console.log('48 + 43 = 91')
}
if ((num1 === 48) && (num2 === 44)) {
    console.log('48 + 44 = 92')
}
if ((num1 === 48) && (num2 === 45)) {
    console.log('48 + 45 = 93')
}
if ((num1 === 48) && (num2 === 46)) {
    console.log('48 + 46 = 94')
}
if ((num1 === 48) && (num2 === 47)) {
    console.log('48 + 47 = 95')
}
if ((num1 === 48) && (num2 === 48)) {
    console.log('48 + 48 = 96')
}
if ((num1 === 48) && (num2 === 49)) {
    console.log('48 + 49 = 97')
}
if ((num1 === 48) && (num2 === 50)) {
    console.log('48 + 50 = 98')
}
if ((num1 === 49) && (num2 === 0)) {
    console.log('49 + 0 = 49')
}
if ((num1 === 49) && (num2 === 1)) {
    console.log('49 + 1 = 50')
}
if ((num1 === 49) && (num2 === 2)) {
    console.log('49 + 2 = 51')
}
if ((num1 === 49) && (num2 === 3)) {
    console.log('49 + 3 = 52')
}
if ((num1 === 49) && (num2 === 4)) {
    console.log('49 + 4 = 53')
}
if ((num1 === 49) && (num2 === 5)) {
    console.log('49 + 5 = 54')
}
if ((num1 === 49) && (num2 === 6)) {
    console.log('49 + 6 = 55')
}
if ((num1 === 49) && (num2 === 7)) {
    console.log('49 + 7 = 56')
}
if ((num1 === 49) && (num2 === 8)) {
    console.log('49 + 8 = 57')
}
if ((num1 === 49) && (num2 === 9)) {
    console.log('49 + 9 = 58')
}
if ((num1 === 49) && (num2 === 10)) {
    console.log('49 + 10 = 59')
}
if ((num1 === 49) && (num2 === 11)) {
    console.log('49 + 11 = 60')
}
if ((num1 === 49) && (num2 === 12)) {
    console.log('49 + 12 = 61')
}
if ((num1 === 49) && (num2 === 13)) {
    console.log('49 + 13 = 62')
}
if ((num1 === 49) && (num2 === 14)) {
    console.log('49 + 14 = 63')
}
if ((num1 === 49) && (num2 === 15)) {
    console.log('49 + 15 = 64')
}
if ((num1 === 49) && (num2 === 16)) {
    console.log('49 + 16 = 65')
}
if ((num1 === 49) && (num2 === 17)) {
    console.log('49 + 17 = 66')
}
if ((num1 === 49) && (num2 === 18)) {
    console.log('49 + 18 = 67')
}
if ((num1 === 49) && (num2 === 19)) {
    console.log('49 + 19 = 68')
}
if ((num1 === 49) && (num2 === 20)) {
    console.log('49 + 20 = 69')
}
if ((num1 === 49) && (num2 === 21)) {
    console.log('49 + 21 = 70')
}
if ((num1 === 49) && (num2 === 22)) {
    console.log('49 + 22 = 71')
}
if ((num1 === 49) && (num2 === 23)) {
    console.log('49 + 23 = 72')
}
if ((num1 === 49) && (num2 === 24)) {
    console.log('49 + 24 = 73')
}
if ((num1 === 49) && (num2 === 25)) {
    console.log('49 + 25 = 74')
}
if ((num1 === 49) && (num2 === 26)) {
    console.log('49 + 26 = 75')
}
if ((num1 === 49) && (num2 === 27)) {
    console.log('49 + 27 = 76')
}
if ((num1 === 49) && (num2 === 28)) {
    console.log('49 + 28 = 77')
}
if ((num1 === 49) && (num2 === 29)) {
    console.log('49 + 29 = 78')
}
if ((num1 === 49) && (num2 === 30)) {
    console.log('49 + 30 = 79')
}
if ((num1 === 49) && (num2 === 31)) {
    console.log('49 + 31 = 80')
}
if ((num1 === 49) && (num2 === 32)) {
    console.log('49 + 32 = 81')
}
if ((num1 === 49) && (num2 === 33)) {
    console.log('49 + 33 = 82')
}
if ((num1 === 49) && (num2 === 34)) {
    console.log('49 + 34 = 83')
}
if ((num1 === 49) && (num2 === 35)) {
    console.log('49 + 35 = 84')
}
if ((num1 === 49) && (num2 === 36)) {
    console.log('49 + 36 = 85')
}
if ((num1 === 49) && (num2 === 37)) {
    console.log('49 + 37 = 86')
}
if ((num1 === 49) && (num2 === 38)) {
    console.log('49 + 38 = 87')
}
if ((num1 === 49) && (num2 === 39)) {
    console.log('49 + 39 = 88')
}
if ((num1 === 49) && (num2 === 40)) {
    console.log('49 + 40 = 89')
}
if ((num1 === 49) && (num2 === 41)) {
    console.log('49 + 41 = 90')
}
if ((num1 === 49) && (num2 === 42)) {
    console.log('49 + 42 = 91')
}
if ((num1 === 49) && (num2 === 43)) {
    console.log('49 + 43 = 92')
}
if ((num1 === 49) && (num2 === 44)) {
    console.log('49 + 44 = 93')
}
if ((num1 === 49) && (num2 === 45)) {
    console.log('49 + 45 = 94')
}
if ((num1 === 49) && (num2 === 46)) {
    console.log('49 + 46 = 95')
}
if ((num1 === 49) && (num2 === 47)) {
    console.log('49 + 47 = 96')
}
if ((num1 === 49) && (num2 === 48)) {
    console.log('49 + 48 = 97')
}
if ((num1 === 49) && (num2 === 49)) {
    console.log('49 + 49 = 98')
}
if ((num1 === 49) && (num2 === 50)) {
    console.log('49 + 50 = 99')
}
if ((num1 === 50) && (num2 === 0)) {
    console.log('50 + 0 = 50')
}
if ((num1 === 50) && (num2 === 1)) {
    console.log('50 + 1 = 51')
}
if ((num1 === 50) && (num2 === 2)) {
    console.log('50 + 2 = 52')
}
if ((num1 === 50) && (num2 === 3)) {
    console.log('50 + 3 = 53')
}
if ((num1 === 50) && (num2 === 4)) {
    console.log('50 + 4 = 54')
}
if ((num1 === 50) && (num2 === 5)) {
    console.log('50 + 5 = 55')
}
if ((num1 === 50) && (num2 === 6)) {
    console.log('50 + 6 = 56')
}
if ((num1 === 50) && (num2 === 7)) {
    console.log('50 + 7 = 57')
}
if ((num1 === 50) && (num2 === 8)) {
    console.log('50 + 8 = 58')
}
if ((num1 === 50) && (num2 === 9)) {
    console.log('50 + 9 = 59')
}
if ((num1 === 50) && (num2 === 10)) {
    console.log('50 + 10 = 60')
}
if ((num1 === 50) && (num2 === 11)) {
    console.log('50 + 11 = 61')
}
if ((num1 === 50) && (num2 === 12)) {
    console.log('50 + 12 = 62')
}
if ((num1 === 50) && (num2 === 13)) {
    console.log('50 + 13 = 63')
}
if ((num1 === 50) && (num2 === 14)) {
    console.log('50 + 14 = 64')
}
if ((num1 === 50) && (num2 === 15)) {
    console.log('50 + 15 = 65')
}
if ((num1 === 50) && (num2 === 16)) {
    console.log('50 + 16 = 66')
}
if ((num1 === 50) && (num2 === 17)) {
    console.log('50 + 17 = 67')
}
if ((num1 === 50) && (num2 === 18)) {
    console.log('50 + 18 = 68')
}
if ((num1 === 50) && (num2 === 19)) {
    console.log('50 + 19 = 69')
}
if ((num1 === 50) && (num2 === 20)) {
    console.log('50 + 20 = 70')
}
if ((num1 === 50) && (num2 === 21)) {
    console.log('50 + 21 = 71')
}
if ((num1 === 50) && (num2 === 22)) {
    console.log('50 + 22 = 72')
}
if ((num1 === 50) && (num2 === 23)) {
    console.log('50 + 23 = 73')
}
if ((num1 === 50) && (num2 === 24)) {
    console.log('50 + 24 = 74')
}
if ((num1 === 50) && (num2 === 25)) {
    console.log('50 + 25 = 75')
}
if ((num1 === 50) && (num2 === 26)) {
    console.log('50 + 26 = 76')
}
if ((num1 === 50) && (num2 === 27)) {
    console.log('50 + 27 = 77')
}
if ((num1 === 50) && (num2 === 28)) {
    console.log('50 + 28 = 78')
}
if ((num1 === 50) && (num2 === 29)) {
    console.log('50 + 29 = 79')
}
if ((num1 === 50) && (num2 === 30)) {
    console.log('50 + 30 = 80')
}
if ((num1 === 50) && (num2 === 31)) {
    console.log('50 + 31 = 81')
}
if ((num1 === 50) && (num2 === 32)) {
    console.log('50 + 32 = 82')
}
if ((num1 === 50) && (num2 === 33)) {
    console.log('50 + 33 = 83')
}
if ((num1 === 50) && (num2 === 34)) {
    console.log('50 + 34 = 84')
}
if ((num1 === 50) && (num2 === 35)) {
    console.log('50 + 35 = 85')
}
if ((num1 === 50) && (num2 === 36)) {
    console.log('50 + 36 = 86')
}
if ((num1 === 50) && (num2 === 37)) {
    console.log('50 + 37 = 87')
}
if ((num1 === 50) && (num2 === 38)) {
    console.log('50 + 38 = 88')
}
if ((num1 === 50) && (num2 === 39)) {
    console.log('50 + 39 = 89')
}
if ((num1 === 50) && (num2 === 40)) {
    console.log('50 + 40 = 90')
}
if ((num1 === 50) && (num2 === 41)) {
    console.log('50 + 41 = 91')
}
if ((num1 === 50) && (num2 === 42)) {
    console.log('50 + 42 = 92')
}
if ((num1 === 50) && (num2 === 43)) {
    console.log('50 + 43 = 93')
}
if ((num1 === 50) && (num2 === 44)) {
    console.log('50 + 44 = 94')
}
if ((num1 === 50) && (num2 === 45)) {
    console.log('50 + 45 = 95')
}
if ((num1 === 50) && (num2 === 46)) {
    console.log('50 + 46 = 96')
}
if ((num1 === 50) && (num2 === 47)) {
    console.log('50 + 47 = 97')
}
if ((num1 === 50) && (num2 === 48)) {
    console.log('50 + 48 = 98')
}
if ((num1 === 50) && (num2 === 49)) {
    console.log('50 + 49 = 99')
}
if ((num1 === 50) && (num2 === 50)) {
    console.log('50 + 50 = 100')
}